<?php 

// CONFIGURAR AQUI EL NOMBRE DEL NEGOCIO
define('NAME_NEGOCIO', 'DOARENSPOS');

define('MENSAJE_WHATSAPP', 'Su comprobante de pago electrónico ha sido generado correctamente, puede revisarlo en el siguiente enlace:');

//configuracion del logo print 
define('L_DIMENSION','25'); // dimenciona en largo como alto //50
define('L_CENTER', '23'); // DE IZQUIERDA A DERECHA PARA PODER CENTRARL LA IMAGEN //10
define('L_ESPACIO', '23'); // DARA EL ESPACIO ENTRE EL LOGO Y EL NOMBRE COMERCIAL //25
define('L_FORMATO' , 'png'); // png, jpg, gif
// define();


//constants
define('HASH_GENERAL_KEY', 'MixitUp200');
define('HASH_PASSWORD_KEY', 'catsFLYhigh2000miles');


define('DB_TYPE', 'mysql');
define('DB_HOST', 'mysql-demorestaurante.alwaysdata.net');
define('DB_NAME', 'demorestaurante_1');
define('DB_USER', '411708');
define('DB_PASS', '89711966M@rt1n3z');



define('DB_CHARSET', 'utf8');

define('API_TOKEN', '');

//path
define('URL', 'https://demorestaurante.alwaysdata.net/');
define('LIBS', 'libs/');
//SI CAMBIA LA URL, TAMBIEN CAMBIAR EN EL .HTACCES

?>