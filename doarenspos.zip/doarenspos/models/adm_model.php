<?php

class Adm_Model extends Model
{
	public function __construct()
	{
		parent::__construct();
	}

	public function run()
	{
		if($_POST["mozoident"]){
			$du = $this->db->prepare("SELECT * FROM tm_usuario WHERE 
			id_rol = '5' AND contrasena = :password AND estado = 'a'");
			$du->execute(array(
				':password' => base64_encode($_POST['password'])
			));
		}else{
			$du = $this->db->prepare("SELECT * FROM tm_usuario WHERE 
			usuario = :usuario AND contrasena = :password AND estado = 'a' AND id_rol=1");
			$du->execute(array(
				':usuario' => $_POST['usuario'],
				':password' => base64_encode($_POST['password'])
			));
		}

		
		$data_u = $du->fetch();
		
		$count_u =  $du->rowCount();
		if ($count_u > 0) {
			//datos de usuario
			Session::init();
			Session::set('loggedIn', true);
			Session::set('loggedInSede', true);//false o true
			Session::set('rol', $data_u['id_rol']);
			Session::set('usuid', $data_u['id_usu']);
			Session::set('areaid', $data_u['id_areap']);
			Session::set('nombres', $data_u['nombres']);
			Session::set('apellidos', $data_u['ape_paterno'].' '.$data_u['ape_materno']);
			Session::set('imagen', $data_u['imagen']);

			Session::set('cod_seg_form', 'sst221223');

			//datos de empresa
			//$de = $this->db->prepare("SELECT * FROM tm_empresa");
			//$de->execute();
			//$data_e = $de->fetch();
			Session::set('ruc', '00');
			Session::set('raz_soc', '00');
			Session::set('sunat', '0');
			Session::set('modo', '3');

			//datos de sistema
			//$ds = $this->db->prepare("SELECT * FROM tm_configuracion");
			//$ds->execute();
			//$data_s = $ds->fetch();
			Session::set('zona_hor', 'America/Lima');
			Session::set('moneda', 'S/');
			Session::set('igv', (18 / 100));
			Session::set('tribAcr', 'RUC');
			Session::set('tribCar', 11);
			Session::set('diAcr', 'DNI');
			Session::set('diCar', 8);
			Session::set('impAcr', 'IGV');
			Session::set('monAcr', 'Soles');
			Session::set('pc_name', 'ADMIN-PC');
			Session::set('pc_ip', '192.168');
			Session::set('print_com', 0);
			Session::set('print_pre', 0);
			Session::set('print_cpe', 0); // funcion imprimir cpe 
			Session::set('cod_seg', '123456'); //funcion codigo de seguridad 
			Session::set('opc_01', 0);
			Session::set('opc_02', 0);
			Session::set('opc_03', 1);

			/* modulo de bloqueo  */
			if($data_u['id_rol'] == 1){
				Session::set('bloqueo', '0');
				Session::set('bloqueo_id', '0');
			}else{
				Session::set('bloqueo', '0'); 
				Session::set('bloqueo_id', '0'); 
			}

			// si cumple apertura
			if($data_u['id_rol'] == 1 OR $data_u['id_rol'] == 2 OR $data_u['id_rol'] == 3){
				/*$da = $this->db->prepare("SELECT * FROM tm_aper_cierre WHERE id_usu = ? AND estado = 'a'");
				$da->execute(array($data_u['id_usu']));
				$data_a = $da->fetch();
				$count_a =  $da->rowCount();
				if ($count_a > 0) {
					Session::set('aperturaIn', true);
					Session::set('apcid', $data_a['id_apc']);
				} else {
					Session::set('aperturaIn', false);
				}*/
				Session::set('aperturaIn', false);

				//Condicionar a que el administrador no visualice el tablero
				if($data_u['id_rol'] == 3){
					print_r(json_encode(3));
				} else {
					print_r(json_encode(1));
				}
				
			} elseif($data_u['id_rol'] == 4){
				Session::set('aperturaIn', true);
				print_r(json_encode(2));
			} elseif($data_u['id_rol'] == 5){
				Session::set('aperturaIn', true);
				print_r(json_encode(3));
			}
			elseif($data_u['id_rol'] == 6){
				print_r(json_encode(5));
			} 			
		} else {
			//header('location: ../login');
			print_r(json_encode(4));
		}
		
		
	}

	public function empresalist()
    {
        try
        {   
			$stm = $this->db->prepare("SELECT * FROM tm_empresa");
            $stm->execute();
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;    
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }


	
}