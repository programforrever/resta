<?php Session::init(); ?>
<?php

class Produccion_Model extends Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function mesas_list()
    {
        try
        {   
            $id_areap = Session::get('areaid');
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 

            $consulta = "call sp_cocina_me(:idemp,:idsede,:id_areap,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_areap' => $id_areap,
                ':estado' => 'b'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
            // Función de comparación para ordenar por ID en orden descendente
            /*function compareByIdDesc($a, $b) {
                return $b->id_pedido - $a->id_pedido;
            }*/
            usort($c, function($a, $b) {
                return strtotime($b->fecha_pedido) - strtotime($a->fecha_pedido);
            });
            //print_r($c);
            // Ordenar la lista de pedidos
            //usort($c, 'compareByIdDesc');
            return $c;   
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function mostrador_list()
    {
        try
        {        
            $id_areap = Session::get('areaid');
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 

            $consulta = "call sp_cocina_mo(:idemp,:idsede,:id_areap,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_areap' => $id_areap,
                ':estado' => 'b'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
            // Función de comparación para ordenar por ID en orden descendente
            //print_r($c);
            /*function compareByIdDesc($a, $b) {
                return $b->id_pedido - $a->id_pedido;
            }*/

            usort($c, function($a, $b) {
                return strtotime($b->fecha_pedido) - strtotime($a->fecha_pedido);
            });
             

            // Ordenar la lista de pedidos
            //usort($c, 'compareByIdDesc');
            return $c;     
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function delivery_list()
    {
        try
        {        
            $id_areap = Session::get('areaid');
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');

            $consulta = "call sp_cocina_de(:idemp,:idsede,:id_areap,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_areap' => $id_areap,
                ':estado' => 'b'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
            // Función de comparación para ordenar por ID en orden descendente
            /*function compareByIdDesc($a, $b) {
                return $b->id_pedido - $a->id_pedido;
            }
            print_r($c);
            // Ordenar la lista de pedidos
            usort($c, 'compareByIdDesc');*/
            usort($c, function($a, $b) {
                return strtotime($b->fecha_pedido) - strtotime($a->fecha_pedido);
            });
            // Filtrar por estados diferentes de 'c'
            $c = array_filter($c, function ($pedido) {
                return $pedido->estado_pedido !== 'c';
            });

            return $c;        
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function agrupacion_platos_list()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');         
            $id_areap = Session::get('areaid');

            $consulta1 = "call sp_cocina_me(:idemp,:idsede,:id_areap,:estado);";
            $arrayParam1 =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_areap' => $id_areap,
                ':estado' => 'b'
            );
            $st1 = $this->db->prepare($consulta1);
            $st1->execute($arrayParam1);
            $a = $st1->fetchAll(PDO::FETCH_OBJ);
            $st1->closeCursor();

            $consulta2 = "call sp_cocina_mo(:idemp,:idsede,:id_areap,:estado);";
            $arrayParam2 =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_areap' => $id_areap,
                ':estado' => 'b'
            );
            $st2 = $this->db->prepare($consulta2);
            $st2->execute($arrayParam2);
            $b = $st2->fetchAll(PDO::FETCH_OBJ);
            $st2->closeCursor();

            $consulta3 = "call sp_cocina_de(:idemp,:idsede,:id_areap,:estado);";
            $arrayParam3 =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_areap' => $id_areap,
                ':estado' => 'b'
            );
            $st3 = $this->db->prepare($consulta3);
            $st3->execute($arrayParam3);
            $c = $st3->fetchAll(PDO::FETCH_OBJ);

            $consulta_array = array_merge($a, $b, $c);

             // Crear un nuevo array para agrupar los pedidos por el nombre del pedido
            $agrupados = [];

            foreach ($consulta_array as $pedido) {
                $id_pres = $pedido->id_pres;
                $nombre_prod = $pedido->nombre_prod;
                $pres_prod = $pedido->pres_prod;
                if (!array_key_exists($id_pres, $agrupados)) {
                    $agrupados[$id_pres] = [];
                }

                if($pedido->tipo_atencion == "3" && $pedido->estado_pedido == 'c'){
                    //$agrupados[$nombre_prod][] = $pedido;
                    $no ="0";
                }else{
                    $agrupados[$id_pres]['id_pres'] = $id_pres;
                    $agrupados[$id_pres]['nombre_pro'] = $nombre_prod;
                    $agrupados[$id_pres]['pres_prod'] = $pres_prod;
                    $agrupados[$id_pres]['items'][] = $pedido;
                }
                
            }
            return $agrupados;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }


    public function agrupacion_pedidos_list()
    {
        try
        {        
            $id_areap = Session::get('areaid');
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');

            $consulta1 = "call sp_cocina_me(:idemp,:idsede,:id_areap,:estado);";
            $arrayParam1 =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_areap' => $id_areap,
                ':estado' => 'b'
            );
            $st1 = $this->db->prepare($consulta1);
            $st1->execute($arrayParam1);
            $a = $st1->fetchAll(PDO::FETCH_OBJ);
            $st1->closeCursor();

            $consulta2 = "call sp_cocina_mo(:idemp,:idsede,:id_areap,:estado);";
            $arrayParam2 =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_areap' => $id_areap,
                ':estado' => 'b'
            );
            $st2 = $this->db->prepare($consulta2);
            $st2->execute($arrayParam2);
            $b = $st2->fetchAll(PDO::FETCH_OBJ);
            $st2->closeCursor();

            $consulta3 = "call sp_cocina_de(:idemp,:idsede,:id_areap,:estado);";
            $arrayParam3 =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_areap' => $id_areap,
                ':estado' => 'b'
            );
            $st3 = $this->db->prepare($consulta3);
            $st3->execute($arrayParam3);
            $c = $st3->fetchAll(PDO::FETCH_OBJ);

            $consulta_array = array_merge($a, $b, $c);

              // Crear un nuevo array para agrupar los pedidos por el id del pedido
            $agrupados = [];

            foreach ($consulta_array as $pedido) {
                $id_pedido = $pedido->id_pedido;

                if($pedido->tipo_atencion != "3" && $pedido->estado_pedido != 'c'){
                    if (!array_key_exists($id_pedido, $agrupados)) {
                        $agrupados[$id_pedido] = [];
                    }
    
                        $agrupados[$id_pedido]['id_pedido'] = $id_pedido;
                        $agrupados[$id_pedido]['tipo_atencion'] = $pedido->tipo_atencion;
                        $agrupados[$id_pedido]['nro_mesa'] = $pedido->nro_mesa;
                        $agrupados[$id_pedido]['desc_salon'] = $pedido->desc_salon;
                        $agrupados[$id_pedido]['items'][] = $pedido;

                }

            }

            return $agrupados;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function preparacion($data)
    {
        try
        {   
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");
            $sql = "UPDATE tm_detalle_pedido SET estado = 'b', fecha_envio = ? WHERE id_pedido = ? AND id_pres = ? AND fecha_pedido = ?";
            $this->db->prepare($sql)
              ->execute(array(
                $fecha,
                $data['cod_ped'],
                $data['cod_prod'],
                $data['fecha_p']
                ));
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function atendido($data)
    {
        try
        {   
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");
            $sql = "UPDATE tm_detalle_pedido SET estado = 'c', fecha_envio = ? WHERE id_pedido = ? AND id_pres = ? AND fecha_pedido = ?";
            $this->db->prepare($sql)
              ->execute(array(
                $fecha,
                $data['cod_ped'],
                $data['cod_prod'],
                $data['fecha_p']
                ));
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function nombre_produccion()
    {
        try
        {   
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $areaid = Session::get('areaid');
            $stm = $this->db->prepare("SELECT nombre AS nombre_prod FROM tm_area_prod WHERE id_areap = ? AND idemp = ?;");
            $stm->execute(array($areaid,$idemp));
            $c = $stm->fetch(PDO::FETCH_OBJ);

            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
}