<?php

class Login_Model extends Model
{
	public function __construct()
	{
		parent::__construct();
	}

	public function run()
	{
		if($_POST["mozoident"]){
			$du = $this->db->prepare("SELECT * FROM tm_usuario WHERE 
			id_rol = '5' AND contrasena = :password AND estado = 'a' AND idEmpresa=:idEmpresa");
			$du->execute(array(
				':password' => base64_encode($_POST['password']),
				':idEmpresa' => $_POST['idempresa']
			));
		}else{
			$du = $this->db->prepare("SELECT * FROM tm_usuario WHERE 
			usuario = :usuario AND contrasena = :password AND estado = 'a' AND idEmpresa=:idEmpresa");
			$du->execute(array(
				':usuario' => $_POST['usuario'],
				':password' => base64_encode($_POST['password']),
				':idEmpresa' => $_POST['idempresa']
			));
		}

		
		$data_u = $du->fetch();
		
		$count_u =  $du->rowCount();
		if ($count_u > 0) {
			//datos de usuario
			Session::init();
			Session::set('loggedIn', true);
			Session::set('loggedInSede', false);//false o true
			Session::set('rol', $data_u['id_rol']);
			Session::set('usuid', $data_u['id_usu']);
			Session::set('areaid', $data_u['id_areap']);
			Session::set('nombres', $data_u['nombres']);
			Session::set('apellidos', $data_u['ape_paterno'].' '.$data_u['ape_materno']);
			Session::set('imagen', $data_u['imagen']);
			Session::set('idemp', $data_u['idEmpresa']);

			//datos de empresa
			$de = $this->db->prepare("SELECT * FROM tm_empresa WHERE id_de = ?");
			$de->execute(array($data_u['idEmpresa']));
			$data_e = $de->fetch();
			Session::set('ruc', $data_e['ruc']);
			Session::set('raz_soc', $data_e['nombre_comercial']);
			Session::set('sunat', $data_e['sunat']);
			Session::set('modo', $data_e['modo']);
			Session::set('logoemp', $data_e['logo']);
			Session::set('optimproces', $data_e['optimiproceso']);
			Session::set('email', $data_e['email']);
			Session::set('crt_plan', $data_e['crt_plan']);
			Session::set('crt_sede', $data_e['crt_sede']);
			Session::set('crt_usuarios', $data_e['crt_usuarios']);
			Session::set('namelandi', $data_e['namesubdominio']);

			$ds = $this->db->prepare("SELECT * FROM tm_configuracion WHERE idemp = ? AND principal = 1");
			$ds->execute(array($_POST['idempresa']));
			$data_s = $ds->fetch();
			Session::set('zona_hor', $data_s['zona_hora']);
			Session::set('moneda', $data_s['mon_val']);
			Session::set('igv', ($data_s['imp_val'] / 100));
			//Session::set('igv_fact', $data['imp_val']);
			Session::set('imp_icbper', $data_s['icbper']);
			Session::set('tribAcr', $data_s['trib_acr']);
			Session::set('tribCar', $data_s['trib_car']);
			Session::set('diAcr', $data_s['di_acr']);
			Session::set('diCar', $data_s['di_car']);
			Session::set('impAcr', $data_s['imp_acr']);
			Session::set('monAcr', $data_s['mon_acr']);
			Session::set('bloq', $data_s['bloqueo']);
			/* modulo de bloqueo  */
			Session::set('bloqueo', $data_s['bloqueo']); 
			Session::set('bloqueo_id', $data_s['bloqueo']); 
			//}

			// si cumple apertura
			if($data_u['id_rol'] == 1 OR $data_u['id_rol'] == 2 OR $data_u['id_rol'] == 3){
				$idemp=Session::get('idemp');

				//Condicionar a que el administrador no visualice el tablero
				if($data_u['id_rol'] == 3){
					if(Session::get('bloq') == 0){
						print_r(json_encode(3));
					}else{
						print_r(json_encode(7));
					}
				} else {
					if(Session::get('bloq') == 0){
						print_r(json_encode(1));
					}else{
						print_r(json_encode(7));
					}
				}
				
			} elseif($data_u['id_rol'] == 4){
				if(Session::get('bloq') == 0){
					Session::set('aperturaIn', true);
					print_r(json_encode(2));
				}else{
					print_r(json_encode(7));
				}
			} elseif($data_u['id_rol'] == 5){
				if(Session::get('bloq') == 0){
					Session::set('aperturaIn', true);
					print_r(json_encode(3));
				}else{
					print_r(json_encode(7));
				}
			}
			elseif($data_u['id_rol'] == 6){
				if(Session::get('bloq') == 0){
					print_r(json_encode(5));
				}else{
					print_r(json_encode(7));
				}
			} 			
		} else {
			//header('location: ../login');
			print_r(json_encode(4));
		}
		
		
	}

	public function planes_modulo()
    {
		try{
			$crt_plan=Session::get('crt_plan');
			$estado = "a";
            $ds = $this->db->prepare("SELECT descripcion FROM tm_modulos WHERE id_plan = ? AND estado = ? ");
			$ds->execute(array($crt_plan,$estado));
			$data_s = $ds->fetchAll();

			$allData=array();
			foreach($data_s as $fila){ 
				$allData[$fila['descripcion']] = $fila['descripcion']; 
			}

			$_SESSION['planesmodu']=$allData;

		}catch(Exception $e)
        {
            die($e->getMessage());
        }
	}

	public function emprelistruc($data)
    {
        try
        {   
			$stm = $this->db->prepare("SELECT * FROM tm_empresa WHERE ruc = ?");
            $stm->execute(array($data['ruc']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;    
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

	//lista las sedes por empresa y usuario
	public function sede_list($id)
    {
        try
        {
			$idusu=Session::get('usuid');
            $stm = $this->db->prepare("SELECT * FROM tm_sedes ts
			INNER JOIN tm_sede_usuario tsu ON ts.id_sede = tsu.id_sede
			WHERE id_usu = ? and id_empresa = ?");
            $stm->execute(array($idusu,$id));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

	//tras elejir la sede, esta funcion nos permite ingresar al sistema
	public function select_sede_id($data)
    {
        try
        {
			$idemp=Session::get('idemp');
            $du = $this->db->prepare("SELECT * FROM tm_sedes WHERE id_empresa = ? and id_sede = ?");
			$du->execute(array($idemp, $data["sede"]));

			$data_u = $du->fetch();
		
			$count_u =  $du->rowCount();
		if ($count_u > 0) {
			//datos de usuario
			Session::init();
			Session::set('loggedInSede', true);//false o true
			Session::set('sede_id', $data_u['id_sede']);
			Session::set('nombre_sede', $data_u['nombre']);

            $idsede=Session::get('sede_id');
			$dsc = $this->db->prepare("SELECT * FROM tm_configuracion WHERE idemp = ? AND idsede = ?");
			$dsc->execute(array($idemp,$idsede));
			$data_sc = $dsc->fetch();
			Session::set('pc_name', $data_sc['pc_name']);
			Session::set('pc_ip', $data_sc['pc_ip']);
			Session::set('print_com', $data_sc['print_com']);
			Session::set('print_pre', $data_sc['print_pre']);
			Session::set('print_cpe', $data_sc['print_cpe']); // funcion imprimir cpe 
			Session::set('cod_seg', $data_sc['cod_seg']); //funcion codigo de seguridad 
			Session::set('opc_01', $data_sc['opc_01']);
			Session::set('opc_02', $data_sc['opc_02']);
			Session::set('opc_03', $data_sc['opc_03']);
			Session::set('enlace_qr', $data_sc['enlace_qr']);
            Session::set('msg_impre', $data_sc['msg_impre']);
			Session::set('img_promocion', $data_sc['img_promocion']);
			//Session::set('print_com_catg', $data_sc['print_com_catg']);
			Session::set('print_com_2', $data_sc['print_com_2']);

			if(Session::get('rol')==1 OR Session::get('rol')==2 OR Session::get('rol')== 3){
				//Session::set('usuid', $data_u['id_usu']);
				$idusu = Session::get('usuid');
				$idemp=Session::get('idemp');
				$idsede=Session::get('sede_id');
				$consulta = "call sp_get_caja_aper(:idemp,:idsede,:id_usu,:id_apc,:fecha_i,:fecha_f,:estado);";
				$arrayParam =  array(
					':idemp' => $idemp,
					':idsede' => $idsede,
					':id_usu' => $idusu,
					':id_apc' =>  '%',
					':fecha_i' => '%',
					':fecha_f' => '%',
					':estado' => 'a'
				);
				$da = $this->db->prepare($consulta);
				$da->execute($arrayParam);
				$data_a = $da->fetch(PDO::FETCH_OBJ);
				$count_a =  $da->rowCount();
				$da->closeCursor();
				if ($count_a > 0) {
					Session::set('aperturaIn', true);
					Session::set('apcid', $data_a->id_apc);
					Session::set('namecaja', $data_a->desc_caja);
				} else {
					Session::set('aperturaIn', false);
				}
				print_r(json_encode(1));

			} elseif(Session::get('rol') == 4){
				print_r(json_encode(2));
			} elseif(Session::get('rol') == 5){
				print_r(json_encode(3));
			}
			elseif(Session::get('rol') == 6){
				print_r(json_encode(5));
			}
			
		} else {
			//header('location: ../login');
			print_r(json_encode(4));
		}
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

}