<?php Session::init(); ?>
<?php

class Credito_Model extends Model
{
	public function __construct()
	{
		parent::__construct();
	}
	
    public function credito_compra_list()
    {
        try
        {
            $ifecha = date('Y-m-d',strtotime($_POST['ifecha']));
            $ffecha = date('Y-m-d',strtotime($_POST['ffecha']));
            $id_prov = $_POST['id_prov'];
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $stm = $this->db->prepare("SELECT cc.id_credito,cc.id_compra,sum(cc.total) AS total,cc.interes,cc.fecha,vc.id_prov,
            CONCAT(vc.serie_doc,'-',vc.num_doc) AS numero,td.descripcion AS desc_td,tp.razon_social AS desc_prov 
            FROM tm_compra_credito AS cc 
            JOIN tm_compra AS vc ON cc.id_compra = vc.id_compra
            JOIN tm_tipo_doc AS td ON vc.id_tipo_doc = td.id_tipo_doc
            JOIN tm_proveedor AS tp ON vc.id_prov = tp.id_prov
            WHERE (vc.fecha_c >= ? AND vc.fecha_c <= ?) AND vc.id_prov like ? AND cc.idemp = ? AND cc.idsede = ? 
            group by cc.total 
            ORDER BY cc.fecha ASC");
            $stm->execute(array($ifecha,$ffecha,$id_prov,$idemp,$idsede));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Amortizado'} = $this->db->query("SELECT IFNULL(SUM(cc.total),0) AS total FROM tm_compra_credito cc LEFT JOIN tm_credito_detalle cd ON  cc.id_credito = cd.id_credito where estado ='a' AND cc.id_compra = ".$d->id_compra)
                    ->fetch(PDO::FETCH_OBJ);
            }
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function credito_detalle_list(){
        try
        {
            $ifecha = date('Y-m-d',strtotime($_POST['ifecha']));
            $ffecha = date('Y-m-d',strtotime($_POST['ffecha']));
            $id_prov = $_POST['id_prov'];
            $id_comp = $_POST['id_comp'];
            $stm = $this->db->prepare("SELECT cc.id_credito,cc.id_compra,cc.total ,cc.interes,cc.fecha,vc.id_prov,cc.estado, 
            CONCAT(vc.serie_doc,'-',vc.num_doc) AS numero,td.descripcion AS desc_td,tp.razon_social AS desc_prov 
            FROM tm_compra_credito AS cc 
            JOIN tm_compra AS vc ON cc.id_compra = vc.id_compra
            JOIN tm_tipo_doc AS td ON vc.id_tipo_doc = td.id_tipo_doc
            JOIN tm_proveedor AS tp ON vc.id_prov = tp.id_prov
            WHERE (vc.fecha_c >= ? AND vc.fecha_c <= ?) AND vc.id_prov like ? and cc.id_compra = ?");
            $stm->execute(array($ifecha,$ffecha,$id_prov, $id_comp));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Amortizado'} = $this->db->query("SELECT IFNULL(SUM(importe),0) AS total FROM tm_credito_detalle WHERE id_credito = ".$d->id_credito)
                    ->fetch(PDO::FETCH_OBJ);
            }
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Proveedores()
    {
        try
        {  
            $idemp=Session::get('idemp');
            //$idsede=Session::get('sede_id');    
            return $this->db->selectAll('SELECT id_prov,ruc,razon_social FROM tm_proveedor WHERE idemp='.$idemp);
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function credito_compra_det()
    {
        try
        {
            $stm = $this->db->prepare("SELECT * FROM tm_credito_detalle WHERE id_credito = ?");
            $stm->execute(array($_POST['id_credito']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Usuario'} = $this->db->query("SELECT CONCAT(ape_paterno,' ',ape_materno,' ',nombres) AS nombre FROM tm_usuario WHERE id_usu = ".$d->id_usu)
                    ->fetch(PDO::FETCH_OBJ);
            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function credito_compra_cuota_list($data)
    {
        try
        {
            $stm = $this->db->prepare("SELECT cc.id_credito,cc.id_compra,cc.total,cc.interes,cc.fecha,vc.id_prov,
            CONCAT(vc.serie_doc,'-',vc.num_doc) AS numero,td.descripcion AS desc_td,tp.razon_social AS desc_prov 
            FROM tm_compra_credito AS cc 
            JOIN tm_compra AS vc ON cc.id_compra = vc.id_compra
            JOIN tm_tipo_doc AS td ON vc.id_tipo_doc = td.id_tipo_doc
            JOIN tm_proveedor AS tp ON vc.id_prov = tp.id_prov 
            WHERE cc.id_credito like ?");
            $stm->execute(array($data['id_credito']));
            $c = $stm->fetch(PDO::FETCH_OBJ);

            $c->{'Amortizado'} = $this->db->query("SELECT IFNULL(SUM(importe),0) AS total FROM tm_credito_detalle WHERE id_credito = ".$c->id_credito)
                    ->fetch(PDO::FETCH_OBJ);

            $data = array("data" => $c);
            $json = json_encode($data);
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function credito_compra_cuota_pago($data)
    {
        try 
        {
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");
            $id_usu = Session::get('usuid');
            $id_apc = Session::get('apcid');
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $montoegreso=0.00;
            if($data['monto_egreso']!=""){
                $montoegreso=$data['monto_egreso'];
            }
            $consulta = "call usp_comprasCreditoCuotas( :flag, :id_credito, :id_usu, :id_apc, :importe, :fecha, :egreso, :monto_egreso, :monto_amortizado, :total_credito, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 1,
                ':id_credito' =>  $data['id_credito'],
                ':id_usu' =>  $id_usu,
                ':id_apc' => $id_apc,
                ':importe' =>  $data['importe'],
                ':fecha' =>  $fecha,
                ':egreso' =>  $data['egreso'],
                ':monto_egreso' => $montoegreso,
                ':monto_amortizado' => $data['monto_amortizado'],
                ':total_credito' => $data['total_credito'],
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
        }
        catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

}