<?php Session::init(); ?>
<?php

class Landing_Model extends Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function landing_data()
    {
        $namelandi=Session::get('namelandi');
        $idemp=Session::get('idemp');
        $idsede=Session::get('sede_id');

        $sql_select_land;
        //
        $sql_landing = $this->db->selectOne("SELECT * FROM tm_landing WHERE idemp =".$idemp);

        if ($sql_landing==false){
            $sql = "INSERT INTO tm_landing(descripcion,estado,pedidominimo,idemp,idsede) VALUES (?,?,?,?,?)";
            $this->db->prepare($sql)->execute(array($namelandi,'a',15,$idemp,$idsede));
            $id = $this->db->lastInsertId();

            $sql_select_land = $this->db->selectOne('SELECT * FROM tm_landing WHERE id_landing=:id_landing', 
            array('id_landing' => $id));
        }else{
            $id = $sql_landing['id_landing'];
            $sql_select_land = $this->db->selectOne('SELECT * FROM tm_landing WHERE id_landing=:id_landing', 
            array('id_landing' => $id));
        }

        return $sql_select_land;
    }

    public function landing_harario_atencion_list()//
    {
        try
        {
            $stm = $this->db->prepare("SELECT * FROM horarioatencion WHERE id_landing = ? order by idhorario asc");
            $stm->execute(array($_POST['id_landing']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function landingActive($data)
    {
        try 
        {
            $res = 0;
            $sql ="UPDATE tm_landing SET estado = ? WHERE id_landing = ?";
            $resultado = $this->db->prepare($sql)->execute(array($data['active'],$data['id_landing']));
            if($resultado){
                $res=2;
            }
            return $res;


        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function landingCantMinima($data)
    {
        try 
        {
            $res = 0;
            $sql ="UPDATE tm_landing SET pedidominimo = ? WHERE id_landing = ?";
            $resultado = $this->db->prepare($sql)->execute(array($data['cantminima'],$data['id_landing']));
            if($resultado){
                $res=2;
            }
            return $res;


        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function landing_horaatenci_list()
    {
        try
        {
            $stm = $this->db->prepare("SELECT * FROM horarioatencion WHERE idhorario=?");
            $stm->execute(array($_POST['id']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function landinghorarioatencionupdate($data)
    {
        try 
        {
            $res = 0;
            $sql ="UPDATE horarioatencion SET nombredia = ?, apertura = ?, cierre = ? WHERE idhorario = ?";
            $resultado = $this->db->prepare($sql)->execute(array($data['nombredia'],$data['apertura'],$data['cierre'],$data['idhorario']));
            if($resultado){
                $res=2;
            }
            return $res;


        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function addlandinghorario($data)//
    {
        try 
        {

            $res = 0;
            $resultado;
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $nombredia=$data['nombredia'];
            //select count(id_landing) from horarioatencion where nombredia = "Martes" AND idemp = 18;
            $sql_count_horario = $this->db->selectOne("SELECT nombredia FROM horarioatencion WHERE idemp = ".$idemp." AND nombredia LIKE '".$nombredia."'");

            if (!$sql_count_horario){
                $sql = "INSERT INTO horarioatencion SET id_landing = ?, nombredia  = ?, apertura = ?, cierre = ?, idemp = ?, idsede = ?";
                $resultado = $this->db->prepare($sql)->execute(array($data['id_landing'],$data['nombredia'],$data['apertura'],$data['cierre'], $idemp, $idsede));
                if ($resultado){
                    $res=1;
                }else{
                    $res=0;
                }
            }else{
                $res = 3;
            }

            return $res;


        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }


}


?>