<?php

class Cliente_Model extends Model {

	public function __construct() {
		parent::__construct();
	}
	
    public function cliente_list($data)
    {
        try
        {   
            $idemp = Session::get('idemp');
   
            $consulta = "call sp_get_clientes(:idemp,:id_cliente,:tipo_cliente,:estado,:buscar);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':id_cliente' => '%',
                ':tipo_cliente' => $data['tipo_cliente'],
                ':estado' => '%',
                ':buscar' => '%'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function cliente_datos($data)
    {
        try 
        {
            $idemp = Session::get('idemp');
            $stm = $this->db->prepare("SELECT * FROM tm_cliente WHERE id_cliente = ? AND idemp = ?");
            $stm->execute(array($data['id_cliente'],$idemp));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function cliente_crud_create($data)
    {
        try 
        {
            $idemp = Session::get('idemp');
            $idsede = Session::get('sede_id');
            $correo = "--";
            $referencia = "--";
            $telefono = "999999999";
            if($data['telefono'] != ""){
                $telefono =$data['telefono'];
            }
            if($data['correo'] != ""){
                $correo =$data['correo'];
            }
            if($data['referencia'] != ""){
                $referencia =$data['referencia'];
            }
            $consulta = "call usp_restRegCliente( :flag, @a, :tipo_cliente, :dni, :ruc, :nombres, :razon_social, :telefono, :fecha_nac, :correo, :direccion, :referencia, :idemp, :idsede);";
                $arrayParam =  array(
                    ':flag' => 1,
                    ':tipo_cliente' => $data['tipo_cliente'],
                    ':dni' => $data['dni'],
                    ':ruc' => $data['ruc'],
                    ':nombres' => $data['nombres'],
                    ':razon_social' => $data['razon_social'],
                    ':telefono' => $telefono,
                    ':fecha_nac' => date('Y-m-d',strtotime($data['fecha_nac'])),
                    ':correo' => $correo,
                    ':direccion' => $data['direccion'],
                    ':referencia' => $referencia,
                    ':idemp' => $idemp,
                    ':idsede' => $idsede
                  );
                $st = $this->db->prepare($consulta);
                $st->execute($arrayParam);
                $row = $st->fetch(PDO::FETCH_ASSOC);
                return $row;
            } catch (Exception $e) 
            {
                die($e->getMessage());
            }
    }

    public function cliente_crud_update($data)
    {
        try 
        {
            $idemp = Session::get('idemp');
            $idsede = Session::get('sede_id');
            $correo = "--";
            $referencia = "--";
            $telefono = "999999999";
            if($data['telefono'] != ""){
                $telefono =$data['telefono'];
            }
            if($data['correo'] != ""){
                $correo =$data['correo'];
            }
            if($data['referencia'] != ""){
                $referencia =$data['referencia'];
            }
            $consulta = "call usp_restRegCliente( :flag, :id_cliente, :tipo_cliente, :dni, :ruc, :nombres, :razon_social, :telefono, :fecha_nac, :correo, :direccion, :referencia, :idemp, :idsede);";
                $arrayParam =  array(
                    ':flag' => 2,
                    ':id_cliente' => $data['id_cliente'],
                    ':tipo_cliente' => $data['tipo_cliente'],
                    ':dni' => $data['dni'],
                    ':ruc' => $data['ruc'],
                    ':nombres' => $data['nombres'],
                    ':razon_social' => $data['razon_social'],
                    ':telefono' => $telefono,
                    ':fecha_nac' => date('Y-m-d',strtotime($data['fecha_nac'])),
                    ':correo' => $correo,
                    ':direccion' => $data['direccion'],
                    ':referencia' => $referencia,
                    ':idemp' => $idemp,
                    ':idsede' => $idsede
                );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }

    public function cliente_ventas($data)
    {
        try
        {  
            $idemp = Session::get('idemp');
            $idsede = Session::get('sede_id');
            $consulta2 = "call sp_get_ventas_con(:idemp,:idsede,:fecha_i,:fecha_f,:id_vent,:id_cli);";
            $arrayParam2 =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':fecha_i' => '%',
                ':fecha_f' => '%',
                ':id_vent' => '%',
                ':id_cli' => $data['id_cliente']

            );
            $stm = $this->db->prepare($consulta2);
            $stm->execute($arrayParam2);
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $stm->closeCursor();

            //filtrar por estado
            $c = array_filter($c, function ($vent_con) {
                return $vent_con->estado == 'a';
            });

            // Reindexar el array
            $c = array_values($c);

            foreach($c as $k => $d)
            {
                $c[$k]->{'monto_total'} = number_format( $d->pago_efe + $d->pago_tar, 2, '.', '');
            }

            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function cliente_estado($data)
    {
        try 
        {
            $idemp = Session::get('idemp');
            $sql = "UPDATE tm_cliente SET estado = ? WHERE id_cliente = ? AND idemp = ?";
            $this->db->prepare($sql)
                ->execute(array($data['estado'],$data['id_cliente'],$idemp));
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function cliente_delete($data)
    {
        try 
        {
            $idemp = Session::get('idemp');
            $idsede = Session::get('sede_id');
            $consulta = "SELECT count(*) AS total FROM tm_venta WHERE id_cliente = :id_cliente";
            $result = $this->db->prepare($consulta);
            $result->bindParam(':id_cliente',$data['id_cliente'],PDO::PARAM_INT);
            $result->execute();
                if($result->fetchColumn()==0){
                    $stm = $this->db->prepare("DELETE FROM tm_cliente WHERE id_cliente = ? AND idemp = ?");          
                    $stm->execute(array($data['id_cliente'],$idemp));
                    return 1;
                }else{
                    return 0;
                }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

}