<?php Session::init(); ?>
<?php

class AjusteAdmin_Model extends Model
{
	public function __construct()
	{
		parent::__construct();
	}

    public function Rol()
    {
        try
        {      
            return $this->db->selectAll('SELECT * FROM tm_rol WHERE id_rol <> 1');
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Impresora()
    {
        try
        {      
            return $this->db->selectAll('SELECT * FROM tm_impresora WHERE estado = "a"');
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    /***INICIO MODULO MULTIEMPRESA */
    /*public function empresa_list()
    {
        try
        {
            $stm = $this->db->prepare("SELECT * FROM tm_empresa WHERE ruc LIKE ?");
            $stm->execute(array($_POST['ruc']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }*/

    public function usuario_estado_password($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $stm = $this->db->prepare("SELECT * FROM tm_usuario WHERE contrasena = ? AND idEmpresa = ?");
            $stm->execute(array(base64_encode($data['pass']),$idemp));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function empresa_list_data($id)
    {
        return $this->db->selectOne('SELECT e.id_de,e.ruc,e.razon_social,e.nombre_comercial,e.direccion_comercial,e.direccion_fiscal,e.ubigeo,e.departamento,e.provincia,
        e.distrito,e.sunat,e.modo,e.logo,e.celular,e.email,e.namesubdominio,e.urlapi,e.passentorno,e.optimiproceso,e.crt_plan,e.crt_sede,u.id_usu,u.usuario,u.contrasena,u.estado FROM tm_empresa e
        INNER JOIN tm_usuario u ON e.email = u.email WHERE e.id_de=:id_de AND u.idEmpresa=:id_de', 
            array(':id_de' => $id));
    }

//LISTADO DE TODAS LAS EMPRESAS
    public function empresa_list()/*datosistema_data*/
    {
        try
        {
            //CAMBIAR EL LEFT POR EL INNER
            $stm = $this->db->prepare("SELECT * FROM tm_empresa 
            INNER JOIN tm_configuracion ON id_de =idemp WHERE principal = 1 AND ruc LIKE ? ORDER BY id_de DESC");

            $stm->execute(array($_POST['ruc']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function sedeempresa_crud_create($data)
    {
        try
        {
            $envres= "0";
            $sql = "INSERT INTO tm_sedes(id_empresa, nombre, direccion, departamento, provincia, distrito, estado) VALUES (?,?,?,?,?,?,?);";
            $resp = $this->db->prepare($sql)->execute(array($data['id_empresa'],$data['nombre'],$data['direccion'],$data['departamento'],$data['provincia'],$data['distrito'],$data['estado']));

            if($resp){
                $envres = "1";
            }
            return $envres;
            
        }catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function sedeempresa_crud_update($data)
    {
        try
        {
            $envres= "0";
            $sql2 = "UPDATE tm_sedes SET nombre = ?, direccion = ?, departamento= ?, provincia = ?, distrito= ? , estado = ? WHERE id_sede = ?";
            $resp = $this->db->prepare($sql2)->execute(array($data['nombre'],$data['direccion'],$data['departamento'],$data['provincia'],$data['distrito'],$data['estado'],$data['id_sede']));

            if($resp){
                $envres = "2";
            }
            return $envres;
            
        }catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function empresa_sede_list()
    {
        try
        {
            $stm = $this->db->prepare("SELECT * FROM tm_sedes WHERE id_empresa = ? and id_sede LIKE ?");
            $stm->execute(array($_POST['id_empresa'], $_POST['id_sedes']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function empresa_sede_list_select($id)
    {
        try
        {
            return $this->db->selectAll('SELECT * FROM tm_sedes WHERE id_empresa = :id_empresa',array('id_empresa' => $id));

        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function crudsede_usuario($data){
        try{
            $res=1;
            $sedes = $data['sedes'];
            foreach ($sedes as $x => $valor){
                $sql = "INSERT INTO tm_sede_usuario(id_sede,id_usu) VALUES (?,?)";
                $this->db->prepare($sql)->execute(array($valor, $data['id_usu']));
            }
            return $res;
        }catch(Exception $e){
            die($e->getMessage());
        }

    }

    public function update_sede_usuario($data){
        try{
            $res=1;
            $sql1 ="DELETE FROM tm_sede_usuario WHERE id_usu = ?";
            $resq = $this->db->prepare($sql1)->execute(array($data['id_usu']));

            $sedes = $data['sedes'];
            foreach ($sedes as $x => $valor){
                $sql = "INSERT INTO tm_sede_usuario(id_sede,id_usu) VALUES (?,?)";
                $this->db->prepare($sql)->execute(array($valor, $data['id_usu']));
            }
            return $res;

        }catch(Exception $e){
            die($e->getMessage());
        }

    }

    /****FIN MODULO MULTIEMPRESA */
    /* INICIO MODULO EMPRESA */

	public function datosempresa_data()
    {
        try
        {    
            $stm = $this->db->prepare("SELECT * FROM tm_empresa WHERE id_de=?");
            $stm->execute(array($_POST['id_de']));
            $c = $stm->fetch(PDO::FETCH_OBJ);
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function modo_produccion($data){
        try{
            $response = 0;
            $sql = "UPDATE tm_empresa SET modo = ? WHERE id_de = ?";
            $resultado = $this->db->prepare($sql)->execute(array($data['modoval'],$data['idEmpresa']));
            if ($resultado){
                $response =1;
            }else{
                $response = 0;
            }
            return $response;
        }catch(Exception $e){
            die($e->getMessage());
        }
    }

    public function permiso_proceso($data){
        try{
            $response = 0;
            $sql = "UPDATE tm_empresa SET optimiproceso = ? WHERE id_de = ?";
            $resultado = $this->db->prepare($sql)->execute(array($data['optimiproceso'],$data['idEmpresa']));
            if ($resultado){
                $response =1;
            }else{
                $response = 0;
            }
            return $response;
        }catch(Exception $e){
            die($e->getMessage());
        }
    }

    public function crt_usuario_multiples($data){
        try{
            $response = 0;
            $sql = "UPDATE tm_empresa SET crt_usuarios = ? WHERE id_de = ?";
            $resultado = $this->db->prepare($sql)->execute(array($data['crt_usu'],$data['idEmpresa']));
            if ($resultado){
                $response =1;
            }else{
                $response = 0;
            }
            return $response;
        }catch(Exception $e){
            die($e->getMessage());
        }
    }

    public function bloq_plataforma($data){
        try{
            $response = 0;
            $sql = "UPDATE tm_configuracion SET bloqueo = ? WHERE idemp = ? AND principal = 1";
            $resultado = $this->db->prepare($sql)->execute(array($data['bloqval'],$data['idEmpresa']));
            if ($resultado){
                $response =1;
            }else{
                $response = 0;
            }
            return $response;
        }catch(Exception $e){
            die($e->getMessage());
        }
    }


    public function datosempresa_crud($data)
    {
        try 
        {       
            $imagen=0;           
            if($data['usuid'] == 1){

                if( !empty( $_FILES['imagen']['name'] ) ){
                    switch ($_FILES['imagen']['type']) 
                    { 
                        case 'image/jpeg': 
                        $ext = "jpg"; 
                        break;
                        case 'image/gif': 
                        $ext = "gif"; 
                        break; 
                        case 'image/png': 
                        $ext = "png"; 
                        break;
                    }
                    //$imagen = 'logoprint.'.$ext;
                    $imagen = date('ymdhis').'.'.$ext;
                    move_uploaded_file ($_FILES['imagen']['tmp_name'], 'public/images/logosemp/'.$imagen);
                    //$data['logo'] =  $imagen;
                } else {
                    $imagen = $data['imagen'];
        
                }
                    // subir certifico pfx 
                if(!empty( $_FILES['file_certificado']['name'] )){
        
                    $directoriobeta         = 'api_fact/UBL21/archivos_xml_sunat/certificados/beta/'.$data['ruc'];
                    $directorioproduccion   = 'api_fact/UBL21/archivos_xml_sunat/certificados/produccion/'.$data['ruc'];
        
                    if (!file_exists($directorioproduccion)) {
                        mkdir($directorioproduccion, 0777, true);
                        $urlsproduccion = 'api_fact/UBL21/archivos_xml_sunat/certificados/produccion/'.$data['ruc'].'/'.$data['ruc'].'.pfx';
                        if(move_uploaded_file($_FILES['file_certificado']['tmp_name'], $urlsproduccion)){
                            $cpeproduccion ='api_fact/UBL21/archivos_xml_sunat/cpe_xml/produccion/'.$data['ruc'];
                                mkdir($cpeproduccion, 0777, true);
                                mkdir($directoriobeta, 0777, true);
                            $urlsbeta = 'api_fact/UBL21/archivos_xml_sunat/certificados/beta/'.$data['ruc'].'/'.$data['ruc'].'.pfx';
                            if(copy($urlsproduccion, $urlsbeta)){
                                $cpebeta ='api_fact/UBL21/archivos_xml_sunat/cpe_xml/beta/'.$data['ruc'];
                                mkdir($cpebeta, 0777, true);
                            }
                        }
                    }   
                }
                $cod = 0;

                $consulta = "call usp_resgClienteEmp(:ruc,:razon_social,:nombre_comercial,:direccion_comercial,
                :direccion_fiscal,:ubigeo,:departamento,:provincia,:distrito,:sunat,
                :modo,:optimiproceso,:logo,:celular,:email,:namesubdominio,:urlapi,:passentorno,:usuario,:passusu,:crt_plan,:crt_sede);";
                $arrayParam =  array(
                    ':ruc' => $data['ruc'],
                    ':razon_social' => $data['razon_social'],
                    ':nombre_comercial' => $data['nombre_comercial'],
                    ':direccion_comercial' => $data['direccion_fiscal'],
                    ':direccion_fiscal' => $data['direccion_fiscal'],
                    ':ubigeo' => $data['ubigeo'],
                    ':departamento' => $data['departamento'],
                    ':provincia' => $data['provincia'],
                    ':distrito' => $data['distrito'],
                    ':sunat' => 0,
                    ':modo' => 3,
                    ':optimiproceso' => 3,
                    ':logo' => $imagen,
                    ':celular' => $data['celular'],
                    ':email' => $data['Correo_emp'],
                    ':namesubdominio' => $data['nombre_subdominio'],
                    ':urlapi' => utf8_encode($data['url_api']),
                    ':passentorno' => utf8_encode($data['passwor_api']),
                    ':usuario' => $data['usuario_emp'],
                    ':passusu' => base64_encode($data['password_emp']),
                    ':crt_plan' => $data['plan'],
                    ':crt_sede' => $data['hidden_crt_sede'],
                );
                $st = $this->db->prepare($consulta);
                $st->execute($arrayParam);
                while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                    $cod =  $row['cod'];
                };

                return $cod;

            }

        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }


    public function datosempresa_crud_update($data)
    {
        try 
        {    
            $imagen=0;           
            if( !empty( $_FILES['imagen']['name'] ) ){
                switch ($_FILES['imagen']['type']) 
                { 
                    case 'image/jpeg': 
                    $ext = "jpg"; 
                    break;
                    case 'image/gif': 
                    $ext = "gif"; 
                    break; 
                    case 'image/png': 
                    $ext = "png"; 
                    break;
                }
                //$imagen = 'logoprint.'.$ext;
                $imagen = date('ymdhis').'.'.$ext;
                move_uploaded_file ($_FILES['imagen']['tmp_name'], 'public/images/logosemp/'.$imagen);
                    //$data['logo'] =  $imagen;
            } else {
                $imagen = $data['imagen'];
            }

                    // subir certifico pfx 
                if(!empty( $_FILES['file_certificado']['name'] )){
        
                    $directoriobeta         = 'api_fact/UBL21/archivos_xml_sunat/certificados/beta/'.$data['ruc'];
                    $directorioproduccion   = 'api_fact/UBL21/archivos_xml_sunat/certificados/produccion/'.$data['ruc'];
        
                    if (!file_exists($directorioproduccion)) {
                        mkdir($directorioproduccion, 0777, true);
                        $urlsproduccion = 'api_fact/UBL21/archivos_xml_sunat/certificados/produccion/'.$data['ruc'].'/'.$data['ruc'].'.pfx';
                        if(move_uploaded_file($_FILES['file_certificado']['tmp_name'], $urlsproduccion)){
                            $cpeproduccion ='api_fact/UBL21/archivos_xml_sunat/cpe_xml/produccion/'.$data['ruc'];
                                mkdir($cpeproduccion, 0777, true);
                                mkdir($directoriobeta, 0777, true);
                            $urlsbeta = 'api_fact/UBL21/archivos_xml_sunat/certificados/beta/'.$data['ruc'].'/'.$data['ruc'].'.pfx';
                            if(copy($urlsproduccion, $urlsbeta)){
                                $cpebeta ='api_fact/UBL21/archivos_xml_sunat/cpe_xml/beta/'.$data['ruc'];
                                mkdir($cpebeta, 0777, true);
                            }
                        }
                    }   
                }
            $cod = 0;

            $consulta = "call usp_updateClienteEmp(:idemp,:idusu,:ruc,:razon_social,:nombre_comercial,
                :direccion_fiscal,:ubigeo,:departamento,:provincia,:distrito,
                :logo,:celular,:email,:namesubdominio,:urlapi,:passentorno,:usuario,:passusu,:crt_plan,:crt_sede);";
            $arrayParam =  array(
                ':idemp' => $data['idempresa'],
                ':idusu' => $data['idusuario'],
                ':ruc' => $data['ruc'],
                ':razon_social' => $data['razon_social'],
                ':nombre_comercial' => $data['nombre_comercial'],
                ':direccion_fiscal' => $data['direccion_fiscal'],
                ':ubigeo' => $data['ubigeo'],
                ':departamento' => $data['departamento'],
                ':provincia' => $data['provincia'],
                ':distrito' => $data['distrito'],
                ':logo' => $imagen,
                ':celular' => $data['celular'],
                ':email' => $data['Correo_emp'],
                ':namesubdominio' => $data['nombre_subdominio'],
                ':urlapi' => utf8_encode($data['url_api']),
                ':passentorno' => utf8_encode($data['passwor_api']),
                ':usuario' => $data['usuario_emp'],
                ':passusu' => base64_encode($data['password_emp']),
                ':crt_plan' => $data['plan'],
                ':crt_sede' => $data['hidden_crt_sede'],
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                $cod = $row['cod'];
            };

            return $cod;

        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function create_dominio_landing($data)
    {
        try
        {
            $operacion=1;
            $rutaapi="";
            $hidden_carta_digital=$data['hidden_carta_digital'];
            //OBTENIENDO RUTA DEL API LANDING
            $api_landing = $this->db->selectOne("SELECT * FROM tm_apis WHERE id_api = 1");
            if ($api_landing) {
                $rutaapi = $api_landing['rutaApi'];
            }
            $res = "";
            $url = $rutaapi.'fldn='.$data['nombredominio'].'&ope='.$operacion;
            $json = file_get_contents($url);
            if($json != false){
                $datos = json_decode($json,true);
                if($datos['carpeta']!="carpeta ya existe"){
                    $sql2 = "UPDATE tm_empresa SET namesubdominio = ?, estado_landing = ?, crt_carta_digital = ?, crt_auto_servicio = ? WHERE id_de = ?";
                    $resp = $this->db->prepare($sql2)->execute(array($data['nombredominio'],$data['hidden_estado_dominio'],$hidden_carta_digital,$data['hidden_auto_servicio'],$data['id_emp']));

                    $sql ="UPDATE tm_landing SET descripcion = ? WHERE idemp = ?";
                    $resultado = $this->db->prepare($sql)->execute(array($data['nombredominio'],$data['id_emp']));

                    $res = "1";
                }else{
                    $res = "3";
                }
            }else{
                $res = "0";
            }
 
            return $res;            
        }catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function update_dominio_landing($data)
    {
        try
        {
            $res = "";

            $rutaapi="";
            //OBTENIENDO RUTA DEL API LANDING
            $api_landing = $this->db->selectOne("SELECT * FROM tm_apis WHERE id_api = 1");
            if ($api_landing) {
                $rutaapi = $api_landing['rutaApi'];
            }

            //HACER UN SELECT PARA OBTENER EL NOMBRE ACTUAL DEL DOMINIO DE LA EMPRESA
            $sql_tm_empresa = $this->db->selectOne("SELECT namesubdominio, estado_landing FROM tm_empresa WHERE id_de = ".$data['id_emp']);
                                       
            if ($sql_tm_empresa) {
                $namesubdominio = $sql_tm_empresa['namesubdominio'];//$data['nombredominio']
                $url = $rutaapi.'fldn='.$data['nombredominio'].'&ope=2'.'&fldele='.$namesubdominio;
                $json = file_get_contents($url);
                $datos = json_decode($json,true);
                //api devuelve resultado

                if($datos['carpeta']=="borrado exitosamente"){
                    $res = "2";//retorna 2 para mandar a registrar
                    
                }else{
                    $res = "4";//error al borrar el directorio
                }
            }

            return $res;            
        }catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }
    
    public function dominio_list_idemp($data)
    {
        try
        {      
            $stm = $this->db->prepare("SELECT namesubdominio,estado_landing,crt_carta_digital,crt_auto_servicio FROM tm_empresa  where id_de = ?");
            $stm->execute(array($data['id_emp']));            
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }


    public function datosistema_crud($data)
    {
        try 
        {
            $sql = "UPDATE tm_configuracion SET zona_hora = ?,trib_acr = ?,trib_car = ?,di_acr = ?,di_car = ?,imp_acr = ?,imp_val = ?,mon_acr = ?,mon_val = ?,pc_name = ?,pc_ip = ?,print_com = ?,print_pre = ?,print_cpe = ?,cod_seg = ?, opc_01 = ?";
            $this->db->prepare($sql)->execute(array($data['zona_hora'],$data['trib_acr'],$data['trib_car'],$data['di_acr'],$data['di_car'],$data['imp_acr'],$data['imp_val'],$data['mon_acr'],$data['mon_val'],$data['pc_name'],$data['pc_ip'],$data['print_com'],$data['print_pre'],$data['print_cpe'],$data['cod_seg'],$data['opc_01']));

            /* ACTUALIZAR DATOS */
            Session::set('moneda', $data['mon_val']);
            Session::set('igv', $data['imp_val']);
            Session::set('tribAcr', $data['trib_acr']);
            Session::set('tribCar', $data['trib_car']);
            Session::set('diAcr', $data['di_acr']);
            Session::set('diCar', $data['di_car']);
            Session::set('impAcr', $data['imp_acr']);
            Session::set('monAcr', $data['mon_acr']);
            Session::set('zona_hor', $data['zona_hora']);
            Session::set('pc_name', $data['pc_name']);
            Session::set('pc_ip', $data['pc_ip']);
            Session::set('print_com', $data['print_com']);
            Session::set('print_pre', $data['print_pre']);
            Session::set('print_cpe', $data['print_cpe']); //funcion impresion directa 
            Session::set('cod_seg', $data['cod_seg']); //funcion codigo de seguridad 
            Session::set('opc_01', $data['opc_01']); //funcion codigo de seguridad 

        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function anularlogo()
    {
        try
        {    
            $stm = $this->db->prepare("UPDATE tm_empresa SET logo = NULL WHERE tm_empresa.id_de = 1");
            $stm->execute();
            // return $c;
            if($stm){
                return '1';
            }
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    /********APIS DEL SISTEMA DNI, RUC, LANDING***********/

    public function apis_list()
    {
        try
        {
            $stm = $this->db->prepare(" SELECT * FROM tm_apis WHERE id_api like ? AND estado like ? ORDER BY id_api DESC");
            $stm->execute(array($_POST['id_api'],$_POST['estado']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    /*public function api_crud_create($data)
    {
        try 
        {
            $res = 0;
            $sql ="UPDATE tm_apis SET nombreAPI = ?, rutaApi=? ,token = ?, estado = ? WHERE id_api = ?";
            $resultado = $this->db->prepare($sql)->execute(array($data['nombreAPI'],$data['rutaApi'],$data['token'],$data['estado'],$data['id_api']));
            if ($resultado){
                $res=2;
            }
            return $res;
    
    
        } catch (Exception $e) 
        {
                die($e->getMessage());
        }
    }*/
    
    public function api_crud_update($data)
    {
        try 
        {
            $res = 0;
            $sql ="UPDATE tm_apis SET nombreAPI = ?, rutaApi=? ,token = ?, estado = ? WHERE id_api = ?";
            $resultado = $this->db->prepare($sql)->execute(array($data['nombreAPI'],$data['rutaApi'],$data['token'],$data['estado'],$data['id_api']));
            if ($resultado){
                $res=2;
            }
            return $res;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }
    
    /* ===========FIN API============*/
    /*INICIO MODULO PLANES */

    public function plan_crud_create($data)
    {
        try 
        {

            $res = 0;
            $sql = "INSERT INTO tm_plan SET descripcion  = ?, estado  = ?";
            $resultado = $this->db->prepare($sql)->execute(array($data['descripcion'],$data['estado']));

            if ($resultado){
                $res=1;
            }
            return $res;
        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    public function plan_crud_update($data)
    {
        try 
        {
            $res = 0;
            $sql = "UPDATE tm_plan SET descripcion  = ?, estado  = ? WHERE id_plan = ?";
            $resultado = $this->db->prepare($sql)->execute(array($data['descripcion'],$data['estado'],$data['id_plan']));

            if ($resultado){
                $res=2;
            }
            return $res;
        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    public function plan_list()
    {
        try
        {

            $stm = $this->db->prepare("SELECT * FROM tm_plan ORDER BY id_plan ASC");
            $stm->execute();
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function plan_delete($data)
    {
        try 
        {
            $res = 0;
            $id_plan = $data['id_plan'];
            //$sql_modulo = $this->db->selectOne("SELECT count(*) FROM tm_modulos WHERE id_plan = $id_plan");

            $ds = $this->db->prepare("SELECT count(*) as filt FROM tm_modulos WHERE id_plan = ?");
			$ds->execute(array($id_plan));
			$data_s = $ds->fetch();

            if ($data_s['filt'] == 0){
                $sql = "DELETE FROM  tm_plan WHERE id_plan = ?";
                $result = $this->db->prepare($sql)->execute(array($id_plan));
    
                if ($result){
                    $res = 1;
                }
            }else{
                $res = 2;
            }

            
            return $res;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function modulo_plan_crud_create($data)
    {
        try 
        {
            $res = 0;
            $id_plan = $data['id_plan'];
            $sql_modulo = $this->db->selectOne("SELECT * FROM tm_modulos WHERE id_plan = $id_plan AND descripcion LIKE '".$data['n_modulo']."'");

            if ($sql_modulo==false){
                $sql = "INSERT INTO tm_modulos SET id_plan = ?, descripcion  = ?, estado  = ?";
                $resultado = $this->db->prepare($sql)->execute(array($data['id_plan'],$data['n_modulo'],$data['estado']));
                if ($resultado){
                    $res=1;
                }
            }else{
                $res = 3;
            }
            
            return $res;
        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    public function modulo_plan_crud_update($data)
    {
        try 
        {
            $res = 0;
            $id_plan = $data['id_plan'];
            $estado = $data['estado'];
            $sql_modulo = $this->db->selectOne("SELECT * FROM tm_modulos WHERE id_plan = $id_plan AND estado = '$estado' AND descripcion LIKE '".$data['n_modulo']."'");

            if ($sql_modulo==false){
                $sql = "UPDATE tm_modulos SET descripcion  = ?, estado  = ? WHERE id_modulo = ?";
                $resultado = $this->db->prepare($sql)->execute(array($data['n_modulo'],$data['estado'],$data['id_modulo']));
                if ($resultado){
                    $res=2;
                }
            }else{
                $res = 3;
            }
           
            return $res;
        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    public function modulo_list()
    {
        try
        {
            $stm = $this->db->prepare("SELECT * FROM tm_modulos WHERE id_plan like ?");
            $stm->execute(array($_POST['id_plan']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Plan'} = $this->db->query("SELECT descripcion FROM tm_plan WHERE id_plan = ".$d->id_plan)
                ->fetch(PDO::FETCH_OBJ);
            }
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function plan()
    {
        try
        {   
            return $this->db->selectAll('SELECT * FROM tm_plan WHERE estado = "a"');
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }


    /*FIN MODULO PLANES */

    /***FORMATEAR SISTEMA***/

    function formatear_sistema()
    {
        try
        {
            $consulta = "call sp_limpiezaDatos();";
            $stm = $this->db->prepare($consulta);
            $stm->execute();

        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    
    }

}