<?php Session::init(); ?>
<?php

class Inventario_Model extends Model
{
	public function __construct()
	{
		parent::__construct();
	}

    public function Responsable()
    {
        try
        {
            $idemp=Session::get('idemp');     
            return $this->db->selectAll('SELECT * FROM tm_usuario WHERE id_usu <> 1 AND idEmpresa = ' . $idemp);
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
	
    /* AJUSTE DE STOCK */
    public function ajuste_list()
    {
        try
        {
            $ifecha = date('Y-m-d',strtotime($_POST['ifecha']));
            $ffecha = date('Y-m-d',strtotime($_POST['ffecha']));

            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 

            $stm = $this->db->prepare("SELECT i.*,IF(i.id_tipo=3,'ENTRADA','SALIDA') AS tipo, CONCAT(u.nombres,' ',u.ape_paterno,' ',u.ape_materno) AS responsable FROM tm_inventario_entsal AS i INNER JOIN tm_usuario AS u ON i.id_responsable = u.id_usu WHERE ((DATE_FORMAT(i.fecha,'%Y-%m-%d')) >= ? AND (DATE_FORMAT(i.fecha,'%Y-%m-%d')) <= ?) AND idemp = ? AND idsede = ?");
            $stm->execute(array($ifecha,$ffecha,$idemp,$idsede));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function ajuste_crud_create($data)
    {
        try 
        {
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");
            $cadena = $data['cadena'];
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            /* Registramos */
            $sql = "INSERT INTO tm_inventario_entsal(id_tipo,id_usu,id_responsable,motivo,fecha,idemp,idsede) VALUES (?,?,?,?,?,?,?);";
            $this->db->prepare($sql)
                      ->execute(
                        array(
                            $data['id_tipo'],
                            Session::get('usuid'),
                            $data['id_responsable'],
                            $data["motivo"],
                            $fecha,
                            $idemp,
                            $idsede
                        ));

            /* El ultimo ID que se ha generado */
            $id = $this->db->lastInsertId();
            
            /* Recorremos el detalle para insertar */
            foreach($data['items'] as $d)
            {
                $sql = "INSERT INTO tm_inventario (id_tipo_ope,id_ope,id_tipo_ins,id_ins,cos_uni,cant,fecha_r,idemp,idsede) 
                        VALUES (?,?,?,?,?,?,?,?,?)";
                
                $this->db->prepare($sql)
                ->execute(
                    array(
                        $data['id_tipo'],
                        $id,
                        $d['id_tipo_ins_insumo'],
                        $d['id_ins_insumo'],
                        $d['precio_insumo'],
                        $d['cantidad_insumo'],
                        $fecha,
                        $idemp,
                        $idsede
                    ));    
                
            }
            
            return true;
        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    public function ajuste_det($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $stm = $this->db->prepare("SELECT * FROM tm_inventario WHERE id_tipo_ope = ? AND id_ope = ? AND idemp = ? AND idsede = ?");
            $stm->execute(array($data['id_tipo'], $data['id_es'],$idemp,$idsede));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $consulta = "call sp_get_insprod(:idemp,:idsede,:id_tipo_ins,:id_ins,:cadena);";
                $arrayParam =  array(
                    ':idemp' => $idemp,
                    ':idsede' => '%',
                    ':id_tipo_ins' => $d->id_tipo_ins,
                    ':id_ins' => $d->id_ins,
                    ':cadena'=>'%'
                );
                $st1 = $this->db->prepare($consulta);
                $st1->execute($arrayParam);
                $c[$k]->{'Producto'} = $st1->fetch(PDO::FETCH_OBJ);
                $st1->closeCursor();
                
            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function ajuste_delete($data)
    {
        try 
        {
            $consulta = "call usp_invESAnular( :flag, :id_es, :id_tipo);";
            $arrayParam =  array(
                ':flag' => 1,
                ':id_es' => $data['id_es'],
                ':id_tipo' => $data['id_tipo']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $row = $st->fetch(PDO::FETCH_ASSOC);
            return $row;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function ajuste_insumo_buscar($data)
    {
        try
        {        
            $cadena = $data['cadena'];
            $idemp=Session::get('idemp');
            
            $consulta = "call sp_get_insprod(:idemp,:idsede,:id_tipo_ins,:id_ins,:cadena);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => '%',
                ':id_tipo_ins' => '%',
                ':id_ins' => '%',
                ':cadena'=>'%'.$cadena.'%'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
            // Filtrar por estados diferentes de 'c'
            $c = array_filter($c, function ($insprod) {
                return $insprod->est_b == 'a' && $insprod->est_c == 'a' && ($insprod->crt_stock == '1' || $insprod->ins_rec == '1');
            });

            // Función de comparación para ordenar alfabéticamente por el nombre del producto (ASC)
            function compararPorNombreASC($a, $b) {
                return strcmp($a->ins_nom, $b->ins_nom);
            }
            // Ordenar la lista de pedidos
            usort($c, 'compararPorNombreASC');

            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function control_stock_pedido($data)
    {
        try {

            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call sp_get_stock(:idemp,:idsede,:id_ins,:id_tipo_ins);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_ins' => $data['id_pres'],
                ':id_tipo_ins' => $data['id_tipo_ins']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetch(PDO::FETCH_OBJ);

            return $c;
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }


    public function combomedida($data)
    {
        try
        {   
            $stmm = $this->db->prepare("SELECT * FROM tm_tipo_medida WHERE grupo = ? OR grupo = ?");
            $stmm->execute(array($data['va1'],$data['va2']));
            $var = $stmm->fetchAll(PDO::FETCH_ASSOC);
            foreach($var as $v){
                echo '<option value="'.$v['id_med'].'">'.$v['descripcion'].'</option>';
            }
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    /* STOCK */
    public function stock_list($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $tipo_ins=$data['tipo_ins'];

            $consulta = "call sp_get_stock(:idemp,:idsede,:id_ins,:id_tipo_ins);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_ins' => "%",
                ':id_tipo_ins' => '%'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);

            if($data['stock_min']=="0"){
                $c = array_filter($c, function ($inven) {
                    return $inven->debajo_stock !== "1";
                });
            }

            if($data['tipo_ins']=="1"){
                $c = array_filter($c, function ($inven) {
                    return $inven->id_tipo_ins === "1";
                });
            }else if($data['tipo_ins']=="1"){
                $c = array_filter($c, function ($inven) {
                    return $inven->id_tipo_ins !== "1";
                });
            }

            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    /* KARDEX VALORIZADO */
    public function kardex_list()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $tipo_ip = $_POST['tipo_ip'];
            $id_ip = $_POST['id_ip'];
            $ifecha = date('Y-m-d',strtotime($_POST['ifecha']));
            $ffecha = date('Y-m-d',strtotime($_POST['ffecha']));

            $stm = $this->db->prepare("SELECT id_inv,id_tipo_ope,id_ope,id_tipo_ins,id_ins,cos_uni,cant,fecha_r,estado,
                    IF(id_tipo_ope = 1 OR id_tipo_ope = 3,FORMAT(cant,6),0) AS cantidad_entrada, 
                    IF(id_tipo_ope = 1 OR id_tipo_ope = 3,cos_uni,0) AS costo_entrada, 
                    IF(id_tipo_ope = 1 OR id_tipo_ope = 3,(cant*cos_uni),0) AS total_entrada, 
                    IF(id_tipo_ope = 2 OR id_tipo_ope = 4,FORMAT(cant,6),0) AS cantidad_salida, 
                    IF(id_tipo_ope = 2 OR id_tipo_ope = 4,cos_uni,'-') AS costo_salida, 
                    IF(id_tipo_ope = 2 OR id_tipo_ope = 4,(cant*cos_uni),0) AS total_salida
                FROM tm_inventario WHERE idemp = ? AND idsede=? AND id_tipo_ins = ? AND id_ins = ? AND (date(fecha_r) >= ? AND date(fecha_r) <= ?)");
            $stm->execute(array($idemp,$idsede,$tipo_ip,$id_ip,$ifecha,$ffecha));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Precio'} = $this->db->query("SELECT ROUND(AVG(cos_uni),2) AS cos_pro FROM tm_inventario WHERE id_tipo_ins = ".$d->id_tipo_ins." AND id_ins = ".$d->id_ins)
                    ->fetch(PDO::FETCH_OBJ);

                if($d->id_tipo_ins == 1){
                    $c[$k]->{'Medida'} = $this->db->query("SELECT m.descripcion AS ins_med FROM tm_insumo i JOIN tm_tipo_medida m ON i.id_med = m.id_med WHERE id_ins = ".$d->id_ins)
                       ->fetch(PDO::FETCH_OBJ);
                }else{
                    $c[$k]->{'Medida'} = array("ins_med"=>"UNIDAD");
                }

                $consulta = "call sp_get_inventario(:idemp,:idsede,:id_ins,:id_tipo_ins);";
                $arrayParam =  array(
                    ':idemp' => $idemp,
                    ':idsede' => $idsede,
                    ':id_ins' => $id_ip,
                    ':id_tipo_ins' => $tipo_ip
                );
                $st = $this->db->prepare($consulta);
                $st->execute($arrayParam);

                $c[$k]->{'Stock'} = $st->fetch(PDO::FETCH_OBJ);
                $st->closeCursor();

                if($d->id_tipo_ope == 1){
                    $c[$k]->{'Comp'} = $this->db->query("SELECT c.serie_doc AS ser_doc,c.num_doc AS nro_doc,td.descripcion AS desc_td FROM tm_compra AS c JOIN tm_tipo_doc AS td ON c.id_tipo_doc = td.id_tipo_doc WHERE c.id_compra = ".$d->id_ope)
                    ->fetch(PDO::FETCH_OBJ);
                } else if($d->id_tipo_ope == 2){
                    $c[$k]->{'Comp'} = $this->db->query("SELECT v.serie_doc AS ser_doc,v.nro_doc,td.descripcion AS desc_td FROM tm_venta AS v JOIN tm_tipo_doc AS td ON v.id_tipo_doc = td.id_tipo_doc WHERE v.id_venta = ".$d->id_ope)
                    ->fetch(PDO::FETCH_OBJ);
                } else if($d->id_tipo_ope == 3 OR $d->id_tipo_ope == 4){
                    $c[$k]->{'Comp'} = $this->db->query("SELECT i.motivo, CONCAT(u.nombres,' ',u.ape_paterno,' ',u.ape_materno) AS responsable FROM tm_inventario_entsal AS i INNER JOIN tm_usuario AS u ON i.id_responsable = u.id_usu WHERE i.id_es = ".$d->id_ope)
                    ->fetch(PDO::FETCH_OBJ);
                }
            }
            
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function ComboInsumoProducto($data)
    {
        try
        {   
            $idemp=Session::get('idemp');
            $consulta = "call sp_get_insprod(:idemp,:idsede,:id_tipo_ins,:id_ins,:cadena);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => '%',
                ':id_tipo_ins' => $data['id_tipo_ins'],
                ':id_ins' => '%',
                ':cadena'=>'%'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $var=$st->fetchAll(PDO::FETCH_ASSOC);

            $var = array_filter($var, function ($insprod) {
                return $insprod['est_b'] == 'a' && $insprod['est_c'] == 'a';
            });

            foreach($var as $v){
                echo '<option value="'.$v['id_ins'].'">'.$v['ins_cod'].' | '.$v['ins_cat'].' | '.$v['ins_nom'].'</option>';
            }
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
}