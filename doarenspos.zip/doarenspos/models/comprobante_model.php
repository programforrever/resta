<?php

class Comprobante_Model extends Model
{
    public function __construct()
    {
        parent::__construct();
    }

  
    public function get_crt_imp_bol($cod_ven){
        try{

            $stm = $this->db->prepare("SELECT count(tpp.crt_icbper) AS crt_icbper FROM tm_venta tv
            JOIN tm_detalle_pedido tdp ON tv.id_pedido = tdp.id_pedido 
            JOIN tm_producto_pres tpp ON tdp.id_pres = tpp.id_pres
            WHERE tv.id_venta = " .$cod_ven. " AND  tpp.crt_icbper = 1");
            $stm->execute();
            $c = $stm->fetch(PDO::FETCH_OBJ);
            return $c;

        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }


    public function venta_all_imp_($data)
    {
        try
        { 
            $consulta2 = "call sp_get_ventas_con(:idemp,:idsede,:fecha_i,:fecha_f,:id_vent,:id_cli);";
            $arrayParam2 =  array(
                ':idemp' => '%',
                ':idsede' => '%',
                ':fecha_i' => '%',
                ':fecha_f' => '%',
                ':id_vent' => $data,
                ':id_cli' => '%'

            );
            $stm = $this->db->prepare($consulta2);
            $stm->execute($arrayParam2);
            $c = $stm->fetch(PDO::FETCH_OBJ);
            $stm->closeCursor();

            $c->{'Empresa'} = $this->db->query("SELECT * FROM tm_empresa WHERE id_de =".$c->idemp)
                ->fetch(PDO::FETCH_OBJ);
            $c->{'Sede'} = $this->db->query("SELECT CONCAT(direccion, ', ', departamento,' - ',provincia,' - ',distrito) AS direccion FROM tm_sedes WHERE id_empresa =".$c->idemp  . " AND id_sede=". $c->idsede)
                ->fetch(PDO::FETCH_OBJ);
            $c->{'Cliente'} = $this->db->query("SELECT id_cliente,CASE WHEN tipo_cliente = 1 THEN nombres WHEN tipo_cliente = 2 THEN razon_social END AS nombrecliente,tipo_cliente,dni,ruc,telefono,direccion FROM tm_cliente WHERE id_cliente = " . $c->id_cli)
                ->fetch(PDO::FETCH_OBJ);
            //Obteniendo el nombre del cliente en para llevar y delivery
            $c->{'Clientepedido'} = $this->db->query("SELECT nomb_cliente FROM tm_pedido_llevar WHERE id_pedido =" . $c->id_ped)
                ->fetch(PDO::FETCH_OBJ);
            $c->{'Pedido'} = $this->db->query("SELECT cm.descripcion AS desc_salon, m.nro_mesa FROM tm_pedido_mesa AS tpm JOIN tm_mesa AS m ON tpm.id_mesa = m.id_mesa JOIN tm_salon AS cm ON m.id_salon = cm.id_salon WHERE m.id_mesa <> 0 AND tpm.id_pedido = ".$c->id_ped)
                ->fetch(PDO::FETCH_OBJ);
            
            $c->{'Mozo'} = $this->db->query("SELECT CONCAT(tu.nombres, ' ', tu.ape_paterno) AS nombre_mozo FROM tm_pedido_mesa AS pm INNER JOIN tm_usuario AS tu ON pm.id_mozo = tu.id_usu  WHERE pm.id_pedido = " . $c->id_ped)
                ->fetch(PDO::FETCH_OBJ);
            $c->{'Cajero'} = $this->db->query("SELECT CONCAT(tu.ape_paterno,' ', tu.ape_materno,' ',tu.nombres) AS cajero FROM tm_aper_cierre AS tc INNER JOIN tm_usuario AS tu ON tc.id_usu = tu.id_usu WHERE tc.id_apc =" . $c->id_apc)
                ->fetch(PDO::FETCH_OBJ);

            $c->{'Detalle'} = $this->db->query("SELECT tdv.id_prod,pp.cod_prod AS codigo_producto, 
                CONCAT(p.nombre,' ',if(tdv.crt_mod_prod = 1, tdv.nom_prod_pres,pp.presentacion)) AS nombre_producto, 
                IF(pp.impuesto='1','10','20') AS codigo_afectacion, 
                CAST(tdv.cantidad AS DECIMAL(7,2)) AS cantidad, 
                IF(pp.impuesto='1',ROUND((tdv.precio/(1 + $c->igv)),6),tdv.precio) AS valor_unitario,
                tdv.precio AS precio_unitario,
                IF(pp.impuesto='1',ROUND((tdv.precio/(1 + $c->igv))*tdv.cantidad,2),
                ROUND(tdv.precio*tdv.cantidad,2)) AS valor_venta,
                IF(pp.impuesto='1',ROUND((tdv.precio/(1 + $c->igv)*tdv.cantidad) * $c->igv,2),0) AS total_igv,
                pp.crt_icbper AS crt_icbper
                FROM tm_detalle_venta AS tdv 
                JOIN tm_venta AS v ON tdv.id_venta = v.id_venta
                JOIN tm_producto_pres AS pp ON tdv.id_prod = pp.id_pres
                JOIN tm_producto AS p ON pp.id_prod = p.id_prod
                WHERE v.id_tipo_doc  IN ('1','2','3') AND tdv.precio > 0 AND tdv.id_venta =".$data)
                    ->fetchAll(PDO::FETCH_OBJ);

            $c->{'Medio_pago'} = $this->db->query("SELECT tvp.id_venta,tvp.id_tipo_pago,ttp.descripcion,tvp.cant_pago FROM tm_venta_pago AS tvp JOIN tm_tipo_pago AS ttp ON tvp. id_tipo_pago = ttp.id_tipo_pago WHERE tvp.id_venta = " . $data)
                ->fetchAll(PDO::FETCH_OBJ);

            $c->{'DetaTopico'} = $this->db->query("SELECT id_pres,SUM(cantidad) AS cantidad, precio, detatopico, SUM(precioTopico) AS precioTopico FROM tm_detalle_pedido WHERE id_pedido = " . $c->id_ped." AND estado <> 'z' GROUP BY id_pres")
                ->fetchAll(PDO::FETCH_OBJ);
            
            $c->{'Impresora'} = $this->db->query("SELECT * FROM tm_impresora WHERE id_imp LIKE '%' and estado = 'a' AND impr_caja='a'  AND idemp=".$c->idemp . " AND idsede=".$c->idsede)
                ->fetch(PDO::FETCH_OBJ);

            $c->{'Configuracion'} = $this->db->query("SELECT pc_name,enlace_qr,msg_impre FROM tm_configuracion WHERE idemp=".$c->idemp . " AND idsede=".$c->idsede)
                ->fetch(PDO::FETCH_OBJ);
            
            $c->{'imp_icbper'} = $this->db->query("SELECT icbper FROM tm_configuracion WHERE principal = 1 AND idemp=".$c->idemp . " AND idsede=".$c->idsede)
                ->fetch(PDO::FETCH_OBJ);

            //$c->{'enlace_qr'} = Session::get('enlace_qr');
            //$c->{'msg_impre'} = Session::get('msg_impre');
            //$c->{'imp_icbper'} = Session::get('imp_icbper');
            
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    
}