<?php Session::init(); ?>
<?php

class Venta_Model extends Model
{
    public function __construct()
    {
        parent::__construct();
    }
    
    public function Salon()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 
            return $this->db->selectAll('SELECT * FROM tm_salon WHERE estado <> "i" AND idemp =' . $idemp . ' AND  idsede =' .$idsede);
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function area_produc($data)
    {
        try
        {
            $id_area = $data;
            $stm = $this->db->prepare("SELECT nombre FROM tm_area_prod WHERE estado <> 'i' AND id_areap = ?");
            $stm->execute(array($id_area));
            $c = $stm->fetch(PDO::FETCH_OBJ);
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Mozo()
    {
        try
        {   
            $idemp=Session::get('idemp');
            return $this->db->selectAll('SELECT id_usu,nombres,ape_paterno,ape_materno FROM tm_usuario WHERE id_rol = 5 AND estado = "a" AND idEmpresa =' . $idemp .' ORDER BY id_usu ASC');
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Repartidor()
    {
        try
        { 
            $idemp=Session::get('idemp');  
            return $this->db->selectAll('SELECT * FROM tm_usuario WHERE id_rol = 6 AND estado = "a" AND idEmpresa =' . $idemp);
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function TipoDocumento()
    {
        try
        {   
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 
            return $this->db->selectAll('SELECT ts.id_tipo_doc,td.descripcion FROM tm_tipo_doc as td
            inner join tm_series as ts on td.id_tipo_doc = ts.id_tipo_doc 
            WHERE ts.estado = "a" AND ts.idemp =' . $idemp .'  AND ts.idsede = '. $idsede . ' ORDER BY CASE td.descripcion WHEN "NOTA DE VENTA" THEN 1 WHEN "BOLETA DE VENTA" THEN 2 ELSE 4 END');//Lunarejo->ya se puso el orden a la descripcion

        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function TipoPago()
    {
        try
        {
            $idemp=Session::get('idemp');
  
            return $this->db->selectAll('SELECT * FROM (SELECT * FROM tm_tipo_pago WHERE estado = "a" ORDER BY id_tipo_pago ASC LIMIT 3) T1
            UNION SELECT * FROM (SELECT * FROM tm_tipo_pago WHERE idemp = '. $idemp .' AND estado = "a") T2;');

        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Personal()
    {
        try
        {
            $idemp=Session::get('idemp');      
            return $this->db->selectAll("SELECT * FROM tm_usuario WHERE id_usu <> 1 AND idEmpresa = ".$idemp." AND estado = 'a' GROUP BY dni");
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function mesa_list()
    {
        try
        {   
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            
            $consulta = "call sp_get_listar_mesas(:idemp,:idsede);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);

            $data = array("mesa" => $c);
            return $data;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function mostrador_list($data)
    {
        try
        {   
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date('Y-m-d');

            if($data['estado'] == 'd'){
                $filtro_fecha = " AND DATE_FORMAT(p.fecha_pedido,'%Y-%m-%d') = '".$fecha;
            }else{
                $filtro_fecha = "";
            }
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 

            $stm = $this->db->prepare("SELECT tp.*,p.fecha_pedido,p.estado,DATE(p.fecha_pedido) AS fecha FROM tm_pedido AS p INNER JOIN tm_pedido_llevar AS tp ON p.id_pedido = tp.id_pedido WHERE p.idemp = ? AND p.idsede = ? AND p.estado = ? ".$filtro_fecha." ORDER BY p.fecha_pedido DESC");
            $stm->execute(array($idemp,$idsede,$data['estado']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Total'} = $this->db->query("SELECT IFNULL(SUM(precio*cant)+SUM(precioTopico),0) AS total FROM tm_detalle_pedido WHERE estado <> 'z' AND id_pedido = " . $d->id_pedido)
                    ->fetch(PDO::FETCH_OBJ);
            }            
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function mostrador_list_c($data)
    {
        try
        {   
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date('Y-m-d');

            if($data['estado'] == 'd'){
                $filtro_fecha = " AND DATE_FORMAT(p.fecha_pedido,'%Y-%m-%d') = '".$fecha."' ORDER BY p.fecha_pedido DESC";
            }else{
                $filtro_fecha = "ORDER BY p.fecha_pedido DESC";
            }

            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 

            if(Session::get('rol') == 5){

                $stm = $this->db->prepare("SELECT tp.*,p.fecha_pedido,p.estado,DATE(p.fecha_pedido) AS fecha, v.id_venta, v.id_pago, IFNULL((v.total+v.comision_delivery-v.descuento_monto),0) AS total FROM tm_pedido AS p INNER JOIN tm_pedido_llevar AS tp ON p.id_pedido = tp.id_pedido INNER JOIN tm_venta AS v ON p.id_pedido = v.id_pedido WHERE p.estado = ? AND p.idemp = ? AND p.idsede = ? ".$filtro_fecha);
                $stm->execute(array($data['estado'],$idemp,$idsede));
                $c = $stm->fetchAll(PDO::FETCH_OBJ);

            } else {

                $stm = $this->db->prepare("SELECT tp.*,p.fecha_pedido,p.estado,DATE(p.fecha_pedido) AS fecha, v.id_venta, v.id_pago, IFNULL((v.total+v.comision_delivery-v.descuento_monto),0) AS total FROM tm_pedido AS p INNER JOIN tm_pedido_llevar AS tp ON p.id_pedido = tp.id_pedido INNER JOIN tm_venta AS v ON p.id_pedido = v.id_pedido WHERE v.id_apc = ? AND p.estado = ? AND p.idemp = ? AND p.idsede = ? ".$filtro_fecha);
                $stm->execute(array(Session::get('apcid'),$data['estado'],$idemp,$idsede));
                $c = $stm->fetchAll(PDO::FETCH_OBJ);

            }

            foreach($c as $k => $d)
            {

                $c[$k]->{'Tipopago'} = $this->db->query("SELECT ttp.descripcion AS nombre FROM tm_venta_pago as tvp join tm_tipo_pago as ttp on tvp.id_tipo_pago = ttp.id_tipo_pago WHERE tvp.id_venta = " . $d->id_venta)
                ->fetchAll(PDO::FETCH_OBJ);

            }
      
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function delivery_list($data)
    {
        try
        {   
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date('Y-m-d');

            if($data['estado'] == 'd'){
                $filtro_fecha = " AND DATE_FORMAT(p.fecha_pedido,'%Y-%m-%d') = '".$fecha."' ORDER BY tp.id_pedido DESC";
            }else{
                $filtro_fecha = "ORDER BY tp.id_pedido DESC";
            }

            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 

            $stm = $this->db->prepare("SELECT tp.*,p.fecha_pedido,p.estado,DATE(p.fecha_pedido) AS fecha FROM tm_pedido AS p INNER JOIN tm_pedido_delivery AS tp ON p.id_pedido = tp.id_pedido WHERE p.estado = ? and tp.tipo_canal like ? AND p.idemp = ? AND p.idsede = ? ".$filtro_fecha);
            $stm->execute(array($data['estado'],$data['tipo_canal'],$idemp,$idsede));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Tipopago'} = $this->db->query("SELECT descripcion AS nombre FROM tm_tipo_pago WHERE id_tipo_pago = " . $d->tipo_pago)
                    ->fetch(PDO::FETCH_OBJ);

                // suma si hay delivery 
                $comisiondelivery   = $this->db->query("SELECT comision_delivery FROM `tm_pedido_delivery` WHERE `id_pedido` =" . $d->id_pedido)->fetch();

                $ventatotal         = $this->db->query("SELECT IFNULL(SUM(precio*cant)+SUM(precioTopico),0) AS total FROM tm_detalle_pedido WHERE estado <> 'z' AND id_pedido = " . $d->id_pedido)->fetch();

                

                $c[$k]->{'Total'} =  $ventatotal;
            }            
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    
    public function delivery_list_c($data)
    {
        try
        {   
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date('Y-m-d');

            if($data['estado'] == 'd'){
                $filtro_fecha = " AND DATE_FORMAT(p.fecha_pedido,'%Y-%m-%d') = '".$fecha."' ORDER BY tp.id_pedido DESC";
            }else{
                $filtro_fecha = "ORDER BY tp.id_pedido DESC";
            }

            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 

            $stm = $this->db->prepare("SELECT v.id_venta,tp.*,p.fecha_pedido,p.estado,DATE(p.fecha_pedido) AS fecha, v.id_pago, IFNULL((v.total+v.comision_delivery-v.descuento_monto),0) AS total FROM tm_pedido AS p INNER JOIN tm_pedido_delivery AS tp ON p.id_pedido = tp.id_pedido INNER JOIN tm_venta AS v ON p.id_pedido = v.id_pedido WHERE v.id_apc = ? AND p.estado = ? AND tp.tipo_canal like ? AND p.idemp = ? AND p.idsede = ? ".$filtro_fecha);
            $stm->execute(array(Session::get('apcid'),$data['estado'],$data['tipo_canal'],$idemp,$idsede));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Tipopago'} = $this->db->query("SELECT ttp.descripcion AS nombre FROM tm_venta_pago as tvp join tm_tipo_pago as ttp on tvp.id_tipo_pago = ttp.id_tipo_pago WHERE tvp.id_venta = " . $d->id_venta)
                ->fetchAll(PDO::FETCH_OBJ);
                /*$c[$k]->{'Tipopago'} = $this->db->query("SELECT descripcion AS nombre FROM tm_tipo_pago WHERE id_tipo_pago = " . $d->tipo_pago_new)
                    ->fetch(PDO::FETCH_OBJ);*/
            }

            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function auto_servicio_list($data)
    {
        try
        {   
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL, 'es_ES.UTF-8', 'es_ES', 'esp');
            $fecha = date('Y-m-d');
            if($data['estado'] == 'd'){
                $filtro_fecha = " AND DATE_FORMAT(fecha_pedido,'%Y-%m-%d') = '".$fecha;
            }else{
                //$filtro_fecha = " AND DATE(fecha_pedido) = CURDATE()";
                $filtro_fecha = " AND DATE(fecha_pedido) = '".$fecha."'";
            }
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 

            $stm = $this->db->prepare("SELECT *,DATE(fecha_pedido) AS fecha FROM pedido_autoservicio WHERE idemp = ? AND opcionsede = ? AND estado = ? ".$filtro_fecha." ORDER BY fecha_pedido DESC");
            $stm->execute(array($idemp,$idsede,$data['estado']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Total'} = $this->db->query("SELECT IFNULL(SUM(precio*cantidad)+SUM(precioTopico),0) AS total FROM pedido_detalle_autoservicio WHERE estado <> 'z' AND id = " . $d->id)
                    ->fetch(PDO::FETCH_OBJ);
                $c[$k]->{'Salon'} = $this->db->query("SELECT id_salon,descripcion FROM tm_salon WHERE id_salon = " . $d->opcionsalon)
                    ->fetch(PDO::FETCH_OBJ);
                $c[$k]->{'Mesa'} = $this->db->query("SELECT id_mesa,nro_mesa FROM tm_mesa  WHERE id_mesa = " . $d->opcionmesa)
                    ->fetch(PDO::FETCH_OBJ);
            }            
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function validarPedidos($data){
        try{

            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 
            $stm = $this->db->prepare("SELECT COUNT(*) AS resp from tm_detalle_pedido dp
            WHERE dp.idemp = ? AND dp.idsede = ? AND dp.id_pedido=? AND dp.estado <> 'z'");
            $stm->execute(array($idemp,$idsede,$data['id_pedido']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ); 

            return $c;
        }catch(Exception $e){
            die($e->getMessage());
        }
    }

    public function  topico_list($data){
        try{
            $idemp=Session::get('idemp');
            $consulta = "call sp_get_listaTopico(:idemp,:id_pres);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':id_pres' => $data['id_pres']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
            return $c;

        }catch(Exception $e){
            die($e->getMessage());
        }
    }

    public function listarPedidos($data)
    {
        try
        {   
            if($data['codpagina'] == '1'){
                $stm = $this->db->prepare("SELECT dp.id_pedido, dp.id_pres, SUM(dp.cantidad) AS cantidad, dp.precio, dp.comentario, dp.estado, CONCAT(`u`.`nombres`, ' ', `u`.`ape_paterno`) AS `nombre_mozo`, SUM(dp.precioTopico) AS precioTopico,nom_prod_pres,crt_mod_prod  FROM tm_detalle_pedido AS dp JOIN tm_pedido_mesa AS pm ON dp.id_pedido = pm.id_pedido
                JOIN tm_usuario AS u ON pm.id_mozo = u.id_usu WHERE dp.id_pedido = ? AND dp.estado <> 'z' AND dp.cantidad > 0 GROUP BY dp.id_pres, dp.precio, nom_prod_pres ORDER BY dp.fecha_pedido DESC");
            } else {
                $stm = $this->db->prepare("SELECT dp.id_pedido, dp.id_pres, SUM(dp.cantidad) AS cantidad, dp.precio, dp.comentario, dp.estado, SUM(dp.precioTopico) AS precioTopico,nom_prod_pres,crt_mod_prod FROM tm_detalle_pedido AS dp WHERE dp.id_pedido = ? AND dp.estado <> 'z' AND dp.cantidad > 0 GROUP BY dp.id_pres, dp.precio, nom_prod_pres ORDER BY dp.fecha_pedido DESC");
            }
            $stm->execute(array($data['id_pedido']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);  
            foreach($c as $k => $d)
            {
                if($d->crt_mod_prod == 1){
                    $nom_prod_pres = $d->nom_prod_pres;
                    $c[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom,'".$nom_prod_pres."' AS pro_pre FROM tm_producto_pres pp JOIN tm_producto p ON pp.id_prod = p.id_prod WHERE pp.id_pres = ". $d->id_pres)
                    ->fetch(PDO::FETCH_OBJ);
                }else{
                    $c[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom,pp.presentacion AS pro_pre FROM tm_producto_pres pp JOIN tm_producto p ON pp.id_prod = p.id_prod WHERE pp.id_pres = ". $d->id_pres)
                    ->fetch(PDO::FETCH_OBJ);
                }
            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function listarPedidosDetalle($data)
    {
        try
        { 
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');   
            if($data['cod_atencion'] == 2) { $sp_pedido = 'sp_pedido_llevar'; } elseif($data['cod_atencion'] == 3) { $sp_pedido = 'sp_pedido_delivery'; }
            
           $consulta = "call ".$sp_pedido."(:idemp,:idsede,:id_pedido,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_pedido' => $data['id_pedido'],
                ':estado'=>'a'
            );
            $stm = $this->db->prepare($consulta);
            $stm->execute($arrayParam);
            $c = $stm->fetch(PDO::FETCH_OBJ);
            $stm->closeCursor();

            $c->{'Detalle'} = $this->db->query("SELECT id_pedido,id_pres,SUM(cant) AS cant, precio, precioTopico,comentario, estado, nom_prod_pres,crt_mod_prod FROM tm_detalle_pedido WHERE id_pedido = ".$c->id_pedido." AND estado <> 'z' AND cant > 0 GROUP BY id_pres, precio,nom_prod_pres ORDER BY fecha_pedido DESC")
                ->fetchAll(PDO::FETCH_OBJ);
            foreach($c->Detalle as $k => $d)
            {
                if($d->crt_mod_prod == 1){
                    $nom_prod_pres = $d->nom_prod_pres;
                    $c->Detalle[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom,'".$nom_prod_pres."' AS pro_pre FROM tm_producto_pres pp JOIN tm_producto p ON pp.id_prod = p.id_prod WHERE pp.id_pres =" . $d->id_pres)
                    ->fetch(PDO::FETCH_OBJ);
                }else{
                    $c->Detalle[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom,pp.presentacion AS pro_pre FROM tm_producto_pres pp JOIN tm_producto p ON pp.id_prod = p.id_prod WHERE pp.id_pres =" . $d->id_pres)
                    ->fetch(PDO::FETCH_OBJ);
                }
            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function listarUpdatePedidos($data)
    {
        try
        {   
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");

            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 

            $stm = $this->db->prepare("SELECT p.nombre AS producto, pp.presentacion AS presentacion, SUM(d.cant) AS cantidad, d.precio, 
            d.comentario,d.precioTopico,d.detatopico,pp.id_pres AS producto_id,p.id_catg,a.id_areap, a.nombre AS nombre_area FROM tm_detalle_pedido AS d 
            INNER JOIN tm_producto_pres AS pp ON d.id_pres = pp.id_pres
            INNER JOIN tm_producto AS p ON pp.id_prod = p.id_prod  
            INNER JOIN tm_area_prod AS a ON a.id_areap = p.id_areap 
            WHERE d.idemp = ? AND d.idsede = ? AND d.id_pedido = ? AND d.estado = 'y' AND d.cant > 0 
            GROUP BY d.id_pres 
            ORDER BY d.fecha_pedido DESC");
            $stm->execute(array($idemp,$idsede,$data['id_pedido']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $true = true;
            foreach($c as $k => $d)
            {
                $nombreImpresora = $this->db->query("SELECT nombre FROM tm_impresora WHERE idemp = $idemp AND idsede = $idsede AND id_areap = $d->id_areap AND estado = 'a'")
                ->fetch(PDO::FETCH_OBJ);
                if($nombreImpresora != false){
                    $c[$k]->{'nombre_imp'} = $nombreImpresora->nombre;
                }else{
                    $true = false;
                    $c[$k]->{'nombre_imp'} = "";
                }
    
            }

            if($true == true){
                $sql2 = "UPDATE tm_detalle_pedido SET estado = 'a', fecha_pedido = ? WHERE id_pedido = ? AND estado = 'y'";
                $this->db->prepare($sql2)->execute(array($fecha,$data['id_pedido']));

                if($data['estado_pedido'] == 'a'){

                    $sql3 = "UPDATE tm_pedido SET id_apc = ?, id_usu = ?, estado = 'b' WHERE id_pedido = ?";
                    $this->db->prepare($sql3)->execute(array(Session::get('apcid'),Session::get('usuid'),$data['id_pedido']));

                    $sql4 = "UPDATE tm_pedido_delivery SET fecha_preparacion = ? WHERE id_pedido = ?";
                    $this->db->prepare($sql4)->execute(array($fecha,$data['id_pedido']));

                }

            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function listarPedidosTicket($data)
    {
        try
        {   
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');  
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");
            $name_imp="";
            $consulta = $this->db->selectOne("SELECT nombre FROM tm_impresora WHERE impr_caja = 'a' AND idemp = ".$idemp." AND idsede =".$idsede);
            if ($consulta==false){
                $name_imp="NINGUNO";
            }else{
                $name_imp=$consulta['nombre'];
            }
            
            $stm = $this->db->prepare("SELECT p.nombre AS producto, pp.presentacion AS presentacion, SUM(d.cant) AS cantidad, d.precio, d.comentario,d.precioTopico,d.detatopico,p.id_areap AS id_areap, '$name_imp' AS nombre_imp FROM tm_detalle_pedido AS d INNER JOIN tm_producto_pres AS pp ON d.id_pres = pp.id_pres INNER JOIN tm_producto AS p ON pp.id_prod = p.id_prod WHERE d.id_pedido = ? AND d.estado = 'a' AND d.cant > 0 GROUP BY d.id_pres ORDER BY d.fecha_pedido DESC");
            $stm->execute(array($data['id_pedido']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ); 
    
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function pedidoAccion($data)
    {
        try
        {
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");

            if($data['cod_accion'] == 1){
                $estado = 'c';
                $tabla = 'tm_pedido_delivery';
                $fecha_campo = 'fecha_envio';
            }else if($data['cod_accion'] == 2){
                $estado = 'd';
                $tabla = 'tm_pedido_delivery';
                $fecha_campo = 'fecha_entrega';
            }else if($data['cod_accion'] == 3){
                $estado = 'd';
                $tabla = 'tm_pedido_llevar';
                $fecha_campo = 'fecha_entrega';
            }

            $sql = "UPDATE tm_pedido SET estado = '".$estado."' WHERE id_pedido = ?";
            $this->db->prepare($sql)->execute(array($data['id_pedido']));
            $sql2 = "UPDATE ".$tabla." SET ".$fecha_campo." = ? WHERE id_pedido = ?";
            $this->db->prepare($sql2)->execute(array($fecha,$data['id_pedido']));
            $sql3 = "UPDATE tm_venta SET codigo_operacion = ? WHERE id_pedido = ?";
            $this->db->prepare($sql3)->execute(array($data['codigo_operacion'],$data['id_pedido']));

        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function listarPedidosAutoServicio($data)
    {
        try
        { 

            $stm = $this->db->prepare("SELECT id as id_pedido, id_pres,sum(cantidad) as cant,precio,fecha_pedido,estado,precioTopico,detatopico FROM pedido_detalle_autoservicio WHERE id = ? AND estado <> 'z' AND cantidad > 0 GROUP BY id_pres, precio ORDER BY fecha_pedido DESC");
            $stm->execute(array($data['id_pedido']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ); 

            foreach($c as $k => $d)
            {
                $c[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom,pp.presentacion AS pro_pre FROM tm_producto_pres pp JOIN tm_producto p ON pp.id_prod = p.id_prod WHERE pp.id_pres =" . $d->id_pres)
                    ->fetch(PDO::FETCH_OBJ);
                $c[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom,pp.presentacion AS pro_pre FROM tm_producto_pres pp JOIN tm_producto p ON pp.id_prod = p.id_prod WHERE pp.id_pres =" . $d->id_pres)
                    ->fetch(PDO::FETCH_OBJ);
            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function subPedidoAutoServicio($data)
    {
        try
        { 
 
            $stm = $this->db->prepare("SELECT id as id_pedido, id_pres,sum(cantidad) as cant,precio,fecha_pedido,estado,precioTopico,detatopico FROM pedido_detalle_autoservicio WHERE id = ? AND id_pres = ? AND estado <> 'z' AND cantidad > 0 GROUP BY id_pres, precio ORDER BY fecha_pedido DESC");
            $stm->execute(array($data['id_pedido'],$data['id_pres']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ); 
            
            foreach($c as $k => $d)
            {
                $c[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom,pp.presentacion AS pro_pre FROM tm_producto_pres pp JOIN tm_producto p ON pp.id_prod = p.id_prod WHERE pp.id_pres =" . $d->id_pres)
                    ->fetch(PDO::FETCH_OBJ);
            }

            return $c;

        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function pedido_delete_autoServicio($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            //Seleccionar producto
            $sql = "UPDATE pedido_detalle_autoservicio SET estado = 'z', motivo_anulacion = ? WHERE id = ? AND id_pres = ?";
            $exec = $this->db->prepare($sql)->execute(array($data['motivo_anulacion'],$data['id_pedido'],$data['id_pres']));

            if($exec){
                $resp = "1";
            }else{
                $resp = "0";
            }

            $datos = array("Codigo" => $resp);
            $c = json_encode($datos);
            echo $c;

        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function anular_pedido_auto_servicio($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');

            //anular pedido auto_servicio
            $sql1 = "UPDATE pedido_autoservicio SET estado = 'z' WHERE id = ? AND idemp = ? AND opcionsede = ?";
            $this->db->prepare($sql1)->execute(array($data['id_pedido'],$idemp,$idsede));

            //anulando detalle del pedido
            $sql2 = "UPDATE pedido_detalle_autoservicio SET estado = 'z' WHERE id = ? AND idemp = ? AND idsede = ?";
            $this->db->prepare($sql2)->execute(array($data['id_pedido'],$idemp,$idsede));

        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function listarMesaSelect($data){
        try{

            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');    
            $stmm = $this->db->prepare("SELECT * FROM tm_mesa WHERE id_salon = ? AND estado <> 'm'  AND idemp = ?  AND idsede = ?  ORDER BY nro_mesa ASC");
            $stmm->execute(array($data['cod_salon_origen'],$idemp,$idsede));
            $var = $stmm->fetchAll(PDO::FETCH_ASSOC);
            foreach($var as $v){
                echo '<option value="'.$v['id_mesa'].'">'.$v['nro_mesa'].'</option>';
            }

        }catch(Exception $e){
            die($e->getMessage);
        }
    }

    public function edit_mesa_auto_servicio($data)
    {
        try
        {
            $sql = "UPDATE pedido_autoservicio SET opcionsalon = ?, opcionmesa = ? WHERE id = ?";
            $resp = $this->db->prepare($sql)->execute(array($data['id_salon_modal'],$data['id_mesa_modal_editar'],$data['id_pedido_auto_servicio']));

            if($resp){
                $resSql = "1";
            }else {
                $resSql = "0";
            }

            return $resSql;

        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function tm_mesa($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');          
            $stm = $this->db->prepare("SELECT * FROM tm_mesa WHERE id_mesa = ? AND idemp = ? AND idsede = ?");
            $stm->execute(array($data['id_mesa'],$idemp,$idsede));
            $resp = $stm->fetch(PDO::FETCH_OBJ);
            return $resp; 


        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function confirmarAutoServicio($data){
        try{

            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");
            $id_usu = Session::get('usuid');
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');

            if(Session::get('rol') == 5){ $id_mozo = $id_usu; } else { $id_mozo = $data['id_mozo_mau']; };
            //HABILITANDO MESA PARA EL PEDIDO
            $consulta = "call usp_restRegMesa( :flag, :id_tipo_pedido, :id_apc, :id_usu, :fecha_pedido, :id_mesa, :id_mozo, :nomb_cliente, :nro_personas, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 1,
                ':id_tipo_pedido' => 1,
                ':id_apc' => Session::get('apcid'),
                ':id_usu' => $id_usu,
                ':fecha_pedido' => $fecha,
                ':id_mesa' => $data['id_mesa_autoservicio'],
                ':id_mozo' => $id_mozo,
                ':nomb_cliente' => $data['nomb_clie_autoservicio'],
                ':nro_personas' => $data['nro_perso_mau'],
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $row = $st->fetch(PDO::FETCH_ASSOC);
            $st->closeCursor();

            //OPTENIENDO EL DETALLE DE LOS PRODUCTOS DEL AUTO SERVICIO
            $stmm = $this->db->prepare("SELECT * FROM pedido_detalle_autoservicio 
            WHERE id = ? AND estado = 'a'  AND idemp = ?  AND idsede = ?");
            $stmm->execute(array($data['id_pedido_autoservicio'],$idemp,$idsede));
            $resp = $stmm->fetchAll(PDO::FETCH_OBJ);

            $nom_prod_pres="";
            $crt_mod_prod = 0;
            $fechaenvio = "0000-00-00 00:00:00";
            $estado = 'a';

            //INSERTAMOS EL DETALLE DE LOS PRODUCTOS DEL AUTO SERVICIO EN LA TABLA TM_DETALLE_PEDIDO
            foreach($resp as $v){

                $sql = "INSERT INTO tm_detalle_pedido(id_pedido, id_usu, id_pres, cantidad, cant, precio, comentario, fecha_pedido, fecha_envio, estado, precioTopico, detatopico, idemp, idsede,nom_prod_pres,crt_mod_prod) 
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
                $this->db->prepare($sql)->execute(array($row['id_pedido'],$id_usu,$v->id_pres,$v->cantidad,$v->cantidad,$v->precio,$v->nota,$fecha,$fechaenvio,$estado,$v->precioTopico,$v->detatopico,$idemp,$idsede,$nom_prod_pres,$crt_mod_prod));

            }

            //ACTUALIZAMOS LOS ESTADOS 
            $sql2 = "UPDATE tm_pedido SET fecha_pedido = ? WHERE id_pedido = ?";
            $this->db->prepare($sql2)->execute(array($fecha,$row['id_pedido']));

            //pedido_detalle_autoservicio

            $sql3 = "UPDATE pedido_autoservicio SET estado = 'i' WHERE id = ?";
            $this->db->prepare($sql3)->execute(array($data['id_pedido_autoservicio']));

            $sql4 = "UPDATE pedido_detalle_autoservicio SET estado = 'i' WHERE id = ?";
            $this->db->prepare($sql4)->execute(array($data['id_pedido_autoservicio']));

            return $row['id_pedido'];

        }catch(Exception $e){
            die($e->getMessage());
        }
    }

    public function confirmarAutoServicio_mesaocupado($data){
        try{

            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");
            $id_usu = Session::get('usuid');
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');


            //OPTENIENDO EL ID DEL PEDIDO DE LA MESA OCUPADA
            $stm1 = $this->db->prepare("SELECT tp.id_pedido,tpm.id_mesa FROM tm_pedido tp
            INNER JOIN tm_pedido_mesa tpm ON tp.id_pedido = tpm.id_pedido
            WHERE tp.id_pedido <> 0 AND tpm.id_mesa = ? AND tp.idemp = ? AND tp.idsede = ? AND tp.estado = 'a'");
            $stm1->execute(array($data['id_mesa'],$idemp,$idsede));
            $resp1 = $stm1->fetch(PDO::FETCH_OBJ);

            //OPTENIENDO EL DETALLE DE LOS PRODUCTOS DEL AUTO SERVICIO
            $stmm = $this->db->prepare("SELECT * FROM pedido_detalle_autoservicio 
            WHERE id = ? AND estado = 'a'  AND idemp = ?  AND idsede = ?");
            $stmm->execute(array($data['id_pedido_autoservicio'],$idemp,$idsede));
            $resp = $stmm->fetchAll(PDO::FETCH_OBJ);

            $nom_prod_pres="";
            $crt_mod_prod = 0;
            $fechaenvio = "0000-00-00 00:00:00";
            $estado = 'a';

            //INSERTAMOS EL DETALLE DE LOS PRODUCTOS DEL AUTO SERVICIO EN LA TABLA TM_DETALLE_PEDIDO
            foreach($resp as $v){

                $sql = "INSERT INTO tm_detalle_pedido(id_pedido, id_usu, id_pres, cantidad, cant, precio, comentario, fecha_pedido, fecha_envio, estado, precioTopico, detatopico, idemp, idsede,nom_prod_pres,crt_mod_prod) 
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
                $this->db->prepare($sql)->execute(array($resp1->id_pedido,$id_usu,$v->id_pres,$v->cantidad,$v->cantidad,$v->precio,$v->nota,$fecha,$fechaenvio,$estado,$v->precioTopico,$v->detatopico,$idemp,$idsede,$nom_prod_pres,$crt_mod_prod));

            }

            //ACTUALIZAMOS LOS ESTADOS 
            $sql2 = "UPDATE tm_pedido SET fecha_pedido = ? WHERE id_pedido = ?";
            $this->db->prepare($sql2)->execute(array($fecha,$resp1->id_pedido));

            //pedido_detalle_autoservicio

            $sql3 = "UPDATE pedido_autoservicio SET estado = 'i' WHERE id = ?";
            $this->db->prepare($sql3)->execute(array($data['id_pedido_autoservicio']));

            $sql4 = "UPDATE pedido_detalle_autoservicio SET estado = 'i' WHERE id = ?";
            $this->db->prepare($sql4)->execute(array($data['id_pedido_autoservicio']));

            return $resp1->id_pedido;

        }catch(Exception $e){
            die($e->getMessage());
        }
    }

    public function comanda_auto_servicio($data)
    {
        try
        {   
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");

            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $id_pedido=$data['id_pedido'];
            $id_pedido_autoservicio = $data['id_pedido_autoservicio'];
            
            if($id_pedido_autoservicio != 0){
                $stm = $this->db->prepare("SELECT p.nombre AS producto, pp.presentacion AS presentacion, SUM(d.cantidad) AS cantidad, d.precio, 
                d.nota AS comentario,d.precioTopico,d.detatopico,pp.id_pres AS producto_id,p.id_catg, a.id_areap, a.nombre AS nombre_area FROM pedido_detalle_autoservicio AS d 
                INNER JOIN tm_producto_pres AS pp ON d.id_pres = pp.id_pres
                INNER JOIN tm_producto AS p ON pp.id_prod = p.id_prod  
                INNER JOIN tm_area_prod AS a ON a.id_areap = p.id_areap 
                WHERE d.idemp = ? AND d.idsede = ? AND d.id = ? AND d.cantidad > 0 
                GROUP BY d.id_pres 
                ORDER BY d.fecha_pedido DESC");
                $stm->execute(array($idemp,$idsede,$id_pedido_autoservicio));
            }else{

                $stm = $this->db->prepare("SELECT p.nombre AS producto, pp.presentacion AS presentacion, SUM(d.cant) AS cantidad, d.precio, 
                d.comentario,d.precioTopico,d.detatopico,pp.id_pres AS producto_id,p.id_catg, a.id_areap, a.nombre AS nombre_area FROM tm_detalle_pedido AS d 
                INNER JOIN tm_producto_pres AS pp ON d.id_pres = pp.id_pres
                INNER JOIN tm_producto AS p ON pp.id_prod = p.id_prod  
                INNER JOIN tm_area_prod AS a ON a.id_areap = p.id_areap 
                WHERE d.idemp = ? AND d.idsede = ? AND d.id_pedido = ? AND d.cant > 0 
                GROUP BY d.id_pres 
                ORDER BY d.fecha_pedido DESC");
                $stm->execute(array($idemp,$idsede,$id_pedido));
            }

            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $true = true;
            foreach($c as $k => $d)
            {
                $nombre_mozo = $this->db->query("SELECT CONCAT(tu.ape_paterno, ' ', tu.ape_materno,' ', tu.nombres) AS nombre_mozo FROM tm_pedido_mesa tp
                JOIN tm_usuario tu ON tp.id_mozo = tu.id_usu
                WHERE tp.id_pedido = $id_pedido AND tp.idemp = $idemp")
                ->fetch(PDO::FETCH_OBJ);
                $c[$k]->{'nombre_mozo'} = $nombre_mozo->nombre_mozo;

                $nombreImpresora = $this->db->query("SELECT nombre FROM tm_impresora WHERE idemp = $idemp AND idsede = $idsede AND id_areap = $d->id_areap AND estado = 'a'")
                ->fetch(PDO::FETCH_OBJ);
                if($nombreImpresora != false){
                    $c[$k]->{'nombre_imp'} = $nombreImpresora->nombre;
                }else{
                    $true = false;
                    $c[$k]->{'nombre_imp'} = "";
                }
    
            }

            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    

    public function ComboMesaOri($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');    
            $stmm = $this->db->prepare("SELECT * FROM tm_mesa WHERE id_salon = ? AND estado = 'i'  AND idemp = ?  AND idsede = ?  ORDER BY nro_mesa ASC");
            $stmm->execute(array($data['cod_salon_origen'],$idemp,$idsede));
            $var = $stmm->fetchAll(PDO::FETCH_ASSOC);
            foreach($var as $v){
                echo '<option value="'.$v['id_mesa'].'">'.$v['nro_mesa'].'</option>';
            }
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function ComboMesaDes($data)
    {
        try
        { 
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');    
            $stmm = $this->db->prepare("SELECT * FROM tm_mesa WHERE id_salon = ? AND estado = ? AND idemp = ?  AND idsede = ? ORDER BY nro_mesa ASC");
            $stmm->execute(array($data['cod_salon_destino'],$data['estado'],$idemp,$idsede));
            $var = $stmm->fetchAll(PDO::FETCH_ASSOC);
            foreach($var as $v){
                echo '<option value="'.$v['id_mesa'].'">'.$v['nro_mesa'].'</option>';
            }
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    
    public function CambiarMesa($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 
            $consulta = "call usp_restOpcionesMesa( :flag, :cod_mesa_origen, :cod_mesa_destino, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 1,
                ':cod_mesa_origen' =>  $data['cod_mesa_origen_opc01'],
                ':cod_mesa_destino' => $data['cod_mesa_destino_opc01'],
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $row = $st->fetch(PDO::FETCH_ASSOC);
            return $row;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function MoverPedidos($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 
            $consulta = "call usp_restOpcionesMesa( :flag, :cod_mesa_origen, :cod_mesa_destino, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 2,
                ':cod_mesa_origen' =>  $data['cod_mesa_origen_opc02'],
                ':cod_mesa_destino' => $data['cod_mesa_destino_opc02'],
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $row = $st->fetch(PDO::FETCH_ASSOC);
            return $row;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function subPedido($data)
    {
        try
        { 
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');   
            if($data['tipo_pedido'] == 1){ $sp_pedido = 'sp_pedido_mesa'; } elseif($data['tipo_pedido'] == 2) { $sp_pedido = 'sp_pedido_llevar'; } elseif($data['tipo_pedido'] == 3) { $sp_pedido = 'sp_pedido_delivery'; }
            
           $consulta = "call ".$sp_pedido."(:idemp,:idsede,:id_pedido,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_pedido' => $data['id_pedido'],
                ':estado'=>'a'
            );
            $stm = $this->db->prepare($consulta);
            $stm->execute($arrayParam);
            $c = $stm->fetch(PDO::FETCH_OBJ);
            $stm->closeCursor();

            $c->{'Detalle'} = $this->db->query("SELECT id_pres, cantidad, cant, precio, estado, fecha_pedido, nom_prod_pres, crt_mod_prod FROM tm_detalle_pedido WHERE id_pedido = ".$c->id_pedido." AND id_pres = ".$data['id_pres']." AND precio = ".$data['precio']." AND crt_mod_prod = ".$data['crt_mod_prod']." ORDER BY fecha_pedido DESC")
                ->fetchAll(PDO::FETCH_OBJ);
            foreach($c->Detalle as $k => $d)
            {
                $c->Detalle[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom,pp.presentacion AS pro_pre FROM tm_producto_pres pp JOIN tm_producto p ON pp.id_prod = p.id_prod WHERE pp.id_pres = " . $d->id_pres)
                    ->fetch(PDO::FETCH_OBJ);

                    if($d->crt_mod_prod == 1){
                        $nom_prod_pres = $d->nom_prod_pres;
                        $c->Detalle[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom,'".$nom_prod_pres."' AS pro_pre FROM tm_producto_pres pp JOIN tm_producto p ON pp.id_prod = p.id_prod WHERE pp.id_pres = " . $d->id_pres)
                        ->fetch(PDO::FETCH_OBJ);
                    }else{
                        $c->Detalle[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom,pp.presentacion AS pro_pre FROM tm_producto_pres pp JOIN tm_producto p ON pp.id_prod = p.id_prod WHERE pp.id_pres = " . $d->id_pres)
                        ->fetch(PDO::FETCH_OBJ);
                    }
            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function refrescar_mesas()
    {
        try {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 
            $stm = $this->db->prepare("UPDATE tm_mesa AS m INNER JOIN v_listar_mesas AS v ON m.id_mesa = v.id_mesa SET m.estado = 'a' WHERE v.estado <> 'a' AND v.estado <> 'm' AND v.idemp = ? AND v.idsede = ? AND v.id_pedido IS NULL");
            $stm->execute(array($idemp,$idsede));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            return $c;
        } catch (Exception $e) {
            return false;
        }
    }

    public function ValidarEstadoPedido($id_pedido)
    {
        try {
            $consulta = "SELECT count(*) AS cod, id_tipo_pedido AS tipo_pedido FROM tm_pedido WHERE id_pedido = :id_pedido AND (estado = 'a' OR estado = 'b' OR estado ='c')";
            $result = $this->db->prepare($consulta);
            $result->bindParam(':id_pedido',$id_pedido,PDO::PARAM_INT);
            $result->execute();
            $row = $result->fetch(PDO::FETCH_ASSOC);
            return $row;
        } catch (Exception $e) {
            return false;
        }
    }

    public function nuevo_pedido_modal($data)
    {
        try
        {
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");
            $id_usu = Session::get('usuid');
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
              
            $stmm = $this->db->prepare("SELECT p.id_pedido,pm.id_mesa,SUM(IF(tdp.estado <> 'z',tdp.precio*tdp.cant,0)) AS total,SUM(IF(tdp.estado <> 'z',tdp.precioTopico,0)) AS preciotopi
            FROM tm_pedido p
                JOIN tm_pedido_mesa pm ON p.id_pedido = pm.id_pedido
                LEFT JOIN tm_detalle_pedido tdp on p.id_pedido = tdp.id_pedido
                JOIN tm_usuario u ON pm.id_mozo = u.id_usu
            WHERE p.id_pedido <> 0 AND pm.id_mesa = ? AND p.estado = 'a' AND p.idemp = ? AND p.idsede = ?
            GROUP BY pm.id_mesa ORDER BY p.id_pedido DESC;");
            $stmm->execute(array($data['id_mesa_modal'],$idemp,$idsede));
            $var = $stmm->fetchAll(PDO::FETCH_ASSOC);
            // Verificar si hay resultados
            if(count($var) > 0) {
                $row = array(
                    'fil' => 0, // Set 'fil' attribute to 3
                    // Add other attributes if needed
                );
            } else {
                if(Session::get('rol') == 5){ $id_mozo = $id_usu; } else { $id_mozo = $data['id_mozo_modal']; };
                $consulta = "call usp_restRegMesa( :flag, :id_tipo_pedido, :id_apc, :id_usu, :fecha_pedido, :id_mesa, :id_mozo, :nomb_cliente, :nro_personas, :idemp, :idsede);";
                $arrayParam =  array(
                    ':flag' => 1,
                    ':id_tipo_pedido' => 1,
                    ':id_apc' => Session::get('apcid'),
                    ':id_usu' => $id_usu,
                    ':fecha_pedido' => $fecha,
                    ':id_mesa' => $data['id_mesa_modal'],
                    ':id_mozo' => $id_mozo,
                    ':nomb_cliente' => $data['nomb_cliente_modal'],
                    ':nro_personas' => $data['nro_personas_modal'],
                    ':idemp' => $idemp,
                    ':idsede' => $idsede
                );
                $st = $this->db->prepare($consulta);
                $st->execute($arrayParam);
                $row = $st->fetch(PDO::FETCH_ASSOC);
                
            }
            return $row;

        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }


    public function pc1($data)
    {
        try
        {
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");
            $id_usu = Session::get('usuid');
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 
            if(Session::get('rol') == 5){ $id_mozo = $id_usu; } else { $id_mozo = $data['id_mozo']; };
            $consulta = "call usp_restRegMesa( :flag, :id_tipo_pedido, :id_apc, :id_usu, :fecha_pedido, :id_mesa, :id_mozo, :nomb_cliente, :nro_personas, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 1,
                ':id_tipo_pedido' => 1,
                ':id_apc' => Session::get('apcid'),
                ':id_usu' => $id_usu,
                ':fecha_pedido' => $fecha,
                ':id_mesa' => $data['id_mesa'],
                ':id_mozo' => $id_mozo,
                ':nomb_cliente' => $data['nomb_cliente'],
                ':nro_personas' => $data['nro_personas'],
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $row = $st->fetch(PDO::FETCH_ASSOC);
            return $row;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function pc2($data)
    {
        try
        {
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");
            $id_usu = Session::get('usuid');
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 
            $consulta = "call usp_restRegMostrador( :flag, :id_tipo_pedido, :id_apc, :id_usu, :fecha_pedido, :nomb_cliente, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 1,
                ':id_tipo_pedido' => 2,
                ':id_apc' => Session::get('apcid'),
                ':id_usu' =>  $id_usu,
                ':fecha_pedido' => $fecha,
                ':nomb_cliente' => $data['nomb_cliente'],
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $row = $st->fetch(PDO::FETCH_ASSOC);
            return $row;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function pc3($data)
    {
        try
        {
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");
            $id_usu = Session::get('usuid');
            if($data['tipo_entrega'] == 1){ 
                $id_repartidor = $data['id_repartidor'];
                $direccion_cliente = $data['direccion_cliente'];
                $referencia_cliente = $data['referencia_cliente'];
            } else { 
                $id_repartidor = 1;
                $direccion_cliente = '';
                $referencia_cliente = '';
            };

            $horaentrega = "00:00";
            $pedidoprogramado = 0;

            if(isset($data['hora_entrega'])){
                $horaentrega = $data['hora_entrega'];
            }

            if(isset($data['pedido_programado'])){
                $pedidoprogramado = $data['pedido_programado'];
            }

            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 
            $consulta = "call usp_restRegDelivery( :flag, :tipo_canal, :id_tipo_pedido, :id_apc, :id_usu, :fecha_pedido, :id_cliente, :id_repartidor, :tipo_entrega, :tipo_pago, :pedido_programado, :hora_entrega, :nombre_cliente, :telefono_cliente, :direccion_cliente, :referencia_cliente, :email_cliente, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 1,
                ':tipo_canal' => 1,
                ':id_tipo_pedido' => 3,
                ':id_apc' => Session::get('apcid'),
                ':id_usu' =>  $id_usu,
                ':fecha_pedido' => $fecha,
                ':id_cliente' => $data['cliente_id'],
                ':id_repartidor' => $id_repartidor,
                ':tipo_entrega' => $data['tipo_entrega'],
                ':tipo_pago' => 1,
                ':pedido_programado' => $pedidoprogramado,
                ':hora_entrega' => $horaentrega,
                ':nombre_cliente' => $data['nomb_cliente'],
                ':telefono_cliente' => $data['telefono_cliente'],
                ':direccion_cliente' => $direccion_cliente,
                ':referencia_cliente' => $referencia_cliente,
                ':email_cliente' => 'example@email.com',
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $row = $st->fetch(PDO::FETCH_ASSOC);
            return $row;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function defaultdata($data)
    {
        try
        {   
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            if($data['tipo_pedido'] == 1){ $sp_pedido = 'sp_pedido_mesa'; } elseif($data['tipo_pedido'] == 2) { $sp_pedido = 'sp_pedido_llevar'; } elseif($data['tipo_pedido'] == 3) { $sp_pedido = 'sp_pedido_delivery'; }
            $consulta = "call ".$sp_pedido."(:idemp,:idsede,:id_pedido,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_pedido' => $data['id_pedido'],
                ':estado'=>'a'
            );
            $stm = $this->db->prepare($consulta);
            $stm->execute($arrayParam);
            $c = $stm->fetch(PDO::FETCH_OBJ);
            $stm->closeCursor();
            
            $c->{'Detalle'} = $this->db->query("SELECT id_pres, SUM(cantidad) AS cantidad, precio, comentario, estado, SUM(precioTopico) AS precioTopico FROM tm_detalle_pedido WHERE id_pedido = ".$c->id_pedido." AND estado <> 'z' GROUP BY id_pres,precio ORDER BY fecha_pedido DESC")
                ->fetchAll(PDO::FETCH_OBJ);

            foreach($c->Detalle as $k => $d)
            {
                $c->Detalle[$k]->{'Producto'} = $this->db->query("SELECT crt_icbper FROM tm_producto_pres WHERE id_pres = " . $d->id_pres)
                    ->fetch(PDO::FETCH_OBJ);
            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function listarCategorias($data)
    {
        try
        {   
            if ($data['codtipoped'] == 3){
                $variable = ' ORDER BY orden ASC';
                //$variable = 'AND delivery = 1';
            } else {
                $variable = ' ORDER BY orden ASC';
            }
            $idemp=Session::get('idemp');
            $stm = $this->db->prepare("SELECT * FROM tm_producto_catg WHERE estado = 'a' AND id_catg = 1 ".$variable);
            $stm->execute();
            $c = $stm->fetch(PDO::FETCH_OBJ);
            $c->{'categ'} = $this->db->query("SELECT * FROM tm_producto_catg WHERE estado = 'a' AND idemp =" . $idemp . " " . $variable)
                    ->fetchAll(PDO::FETCH_OBJ);
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    
    public function listarProductos($data)
    {
        try
        {   
            if ($data['codtipoped'] == 3){
                if($data['codrepartidor'] == 1){
                    $campo = ',pp.precio_delivery AS pro_cos';
                    $variable = ' AND pp.precio_delivery > 0';
                } else{
                    $campo = ',pp.precio AS pro_cos';
                    $variable = '';
                }
            } else {
                $campo = ',pp.precio AS pro_cos';
                $variable = '';
            }
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $stm = $this->db->prepare("SELECT p.id_areap AS id_areap,p.id_catg,p.id_tipo,pp.id_pres AS id_pres,p.nombre AS pro_nom,pp.presentacion AS pro_pre".$campo.",
            pp.imagen AS pro_img,IFNULL(pp.descripcion, '') AS pro_des,cp.descripcion AS nombre_catg FROM tm_producto_pres AS pp
            JOIN tm_producto AS p ON pp.id_prod = p.id_prod
            JOIN tm_producto_catg AS cp ON p.id_catg = cp.id_catg  
            WHERE pp.id_pres <> 0 AND p.id_catg = ? AND cp.estado = 'a' AND p.estado='a' AND pp.estado= 'a' AND pp.idemp = ? ".$variable." order by pro_nom asc, pro_pre asc");
            $stm->execute(array($data['id_catg'],$idemp));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Impresora'} = $this->db->query('SELECT i.nombre FROM tm_area_prod AS ap INNER JOIN tm_impresora AS i ON ap.id_areap = i.id_areap WHERE ap.id_areap = ' . $d->id_areap . ' AND i.idemp = '. $idemp . ' AND i.idsede = ' .$idsede)
                ->fetch(PDO::FETCH_OBJ);
            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function produc_combo($data){
        try {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $cant = $data['cant'];
            $stm = $this->db->prepare("SELECT tpi.id_ins, tpi.id_areap,tp.nombre AS producto,tpp.presentacion,SUM(tpi.cant) AS cantidad, ti.nombre AS impresora FROM tm_producto_ingr tpi
            JOIN tm_producto_pres tpp ON tpi.id_ins = tpp.id_pres
            JOIN tm_producto tp  ON tpp.id_prod = tp.id_prod
            JOIN tm_impresora ti ON tpi.id_areap = ti.id_areap
            WHERE tpi.id_pres = ? AND tpi.idemp = ? AND ti.idsede = ? AND ti.estado = 'a' GROUP BY tpi.id_ins ORDER BY tpi.id_pi DESC");
            $stm->execute(array($data['id_producto'],$idemp,$idsede));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
    
            return $c;
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }

    public function listarProdsMasVend($data)
    {
        try
        {   
            if ($data['codtipoped'] == 3){
                if($data['codrepartidor'] != 1){
                    $campo = ',pp.precio AS pro_cos';
                    $variable = 'GROUP BY dv.id_prod ORDER BY SUM(cantidad) DESC LIMIT 25';
                } else{
                    $campo = ',pp.precio_delivery AS pro_cos';
                    $variable = ' AND pp.precio_delivery > 0 GROUP BY dv.id_prod ORDER BY SUM(cantidad) DESC LIMIT 25';
                }
            } else {
                $campo = ',pp.precio AS pro_cos';
                $variable = 'GROUP BY dv.id_prod ORDER BY SUM(cantidad) DESC LIMIT 25';
            }
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $stm = $this->db->prepare("SELECT p.id_areap AS id_areap,p.id_catg,p.id_tipo,pp.id_pres AS id_pres,p.nombre AS pro_nom,pp.presentacion AS pro_pre".$campo.",
            pp.imagen AS pro_img, pp.descripcion AS pro_des,cp.descripcion AS nombre_catg FROM tm_detalle_venta AS dv 
            JOIN tm_producto_pres AS pp ON dv.id_prod = pp.id_pres
            JOIN tm_producto AS p ON pp.id_prod = p.id_prod
            JOIN tm_producto_catg AS cp ON p.id_catg = cp.id_catg 
            WHERE pp.id_pres <> 0 AND cp.estado = 'a' AND p.estado='a' AND pp.estado= 'a' AND dv.idemp = ? AND dv.idsede = ? AND dv.fecha_venta >= DATE_SUB(CURDATE(), INTERVAL 18 DAY) ".$variable);
            $stm->execute(array($idemp,$idsede));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Impresora'} = $this->db->query("SELECT i.nombre FROM tm_area_prod AS ap INNER JOIN tm_impresora AS i ON ap.id_areap = i.id_areap WHERE ap.id_areap = " . $d->id_areap . ' AND i.idemp = '. $idemp . ' AND i.idsede = ' .$idsede)
                ->fetch(PDO::FETCH_OBJ);
            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function RegistrarPedido($data)
    {
        try 
        {
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");
            $id_usu = Session::get('usuid');
            if($data['codtipoped'] == 3){ 
                $estado = 'y';
            } else {
                $estado = 'a';
            }
            $deta = "";
            $totalTopi = 0;
            $fechaenvio = "0000-00-00 00:00:00";
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $comentario ="";

            foreach($data['items'] as $d)
            {
                if(isset($d['detatopico']) &&  isset($d['totalTopico'])){
                    $deta=$d['detatopico'];
                    $totalTopi=$d['totalTopico'];
                }else{
                    $deta = "";
                    $totalTopi = 0;
                }

                if($d['comentario']!=""){
                    $comentario = $d['comentario'];
                }

                if($d['new_name_prod']!=""){
                    $nom_prod_pres=$d['new_name_prod'];
                    $crt_mod_prod = 1;
                }else{
                    $nom_prod_pres="";
                    $crt_mod_prod = 0;
                }

                $sql = "INSERT INTO tm_detalle_pedido(id_pedido, id_usu, id_pres, cantidad, cant, precio, comentario, fecha_pedido, fecha_envio, estado, precioTopico, detatopico, idemp, idsede,nom_prod_pres,crt_mod_prod) 
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
                $this->db->prepare($sql)->execute(array($data['cod_ped'],$id_usu,$d['producto_id'],$d['cantidad'],$d['cantidad'],$d['precio'],$comentario,$fecha,$fechaenvio,$estado,$totalTopi,$deta,$idemp,$idsede,$nom_prod_pres,$crt_mod_prod));

            }

            $sql2 = "UPDATE  tm_pedido SET fecha_pedido = ? WHERE id_pedido = ?";
            $this->db->prepare($sql2)->execute(array($fecha,$data['cod_ped']));

        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    public function buscar_producto($data)
    {
        try
        {   
            if ($data['codtipoped'] == 3){
                if($data['codrepartidor'] == 1){
                    $campo = ',pp.precio AS pro_cos';
                } else{
                    $campo = ',pp.precio_delivery AS pro_cos';
                }
                $variable = 'AND cp.delivery = 1 AND p.delivery = 1 AND pp.delivery = 1';
            } else {
                $variable = '';
                $campo = ',pp.precio AS pro_cos';
            }
            $cadena = $data['cadena'];
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $stm = $this->db->prepare("SELECT p.id_areap AS id_areap,p.id_catg,p.id_tipo, pp.id_pres AS id_pres, p.nombre AS pro_nom,
            pp.presentacion AS pro_pre".$campo.",pp.imagen AS pro_img, pp.descripcion AS pro_des,cp.descripcion AS nombre_catg FROM tm_producto_pres pp
            JOIN tm_producto p ON pp.id_prod = p.id_prod
            JOIN tm_producto_catg cp ON p.id_catg = cp.id_catg 
            WHERE pp.id_pres <> 0 AND (pp.cod_prod  LIKE '%$cadena%' OR pp.presentacion LIKE '%$cadena%')
            AND pp.idemp = ? AND cp.estado = 'a' AND p.estado = 'a' AND pp.estado = 'a' ".$variable);
            $stm->execute(array($idemp));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Impresora'} = $this->db->query("SELECT i.nombre FROM tm_area_prod AS ap INNER JOIN tm_impresora AS i ON ap.id_areap = i.id_areap WHERE ap.id_areap = " . $d->id_areap . ' AND i.idemp = '. $idemp . ' AND i.idsede = ' .$idsede)
                ->fetch(PDO::FETCH_OBJ);
            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function ListarDetallePed($data)
    {
        try
        {   
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');   
            if($data['tipo_pedido'] == 1){ $sp_pedido = 'sp_pedido_mesa'; } elseif($data['tipo_pedido'] == 2) { $sp_pedido = 'sp_pedido_llevar'; } elseif($data['tipo_pedido'] == 3) { $sp_pedido = 'sp_pedido_delivery'; }
            
           $consulta = "call ".$sp_pedido."(:idemp,:idsede,:id_pedido,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_pedido' => $data['id_pedido'],
                ':estado'=>'a'
            );
            $stm = $this->db->prepare($consulta);
            $stm->execute($arrayParam);
            $c = $stm->fetch(PDO::FETCH_OBJ);
            $stm->closeCursor();

            $c->{'Detalle'} = $this->db->query("SELECT id_pres,SUM(cantidad) AS cantidad, precio, SUM(precioTopico) AS precioTopico, estado,nom_prod_pres,crt_mod_prod FROM tm_detalle_pedido WHERE id_pedido = " . $c->id_pedido." AND estado <> 'z' GROUP BY id_pres, precio, nom_prod_pres")
                ->fetchAll(PDO::FETCH_OBJ);
            foreach($c->Detalle as $k => $d)
            {
                if($d->crt_mod_prod == 1){
                    $nom_prod_pres = $d->nom_prod_pres;
                    $c->Detalle[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom,'".$nom_prod_pres."' AS pro_pre, pp.crt_icbper FROM tm_producto_pres pp JOIN tm_producto p ON pp.id_prod = p.id_prod WHERE pp.id_pres = " . $d->id_pres)
                    ->fetch(PDO::FETCH_OBJ);
                }else{
                    $c->Detalle[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom,pp.presentacion AS pro_pre, pp.crt_icbper FROM tm_producto_pres pp JOIN tm_producto p ON pp.id_prod = p.id_prod WHERE pp.id_pres = " . $d->id_pres)
                    ->fetch(PDO::FETCH_OBJ);
                }

                $c->Detalle[$k]->{'Total_costo'} = $this->db->query("SELECT tpi.id_pres ,SUM(tpi.costo) AS costo,tpp.receta FROM tm_producto_ingr tpi
                JOIN tm_producto_pres tpp ON tpi.id_pres = tpp.id_pres
                WHERE tpp.receta = 1 AND tpi.id_pres=" . $d->id_pres)
                    ->fetch(PDO::FETCH_OBJ);
            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function cliente_crud_create($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $correo = "--";
            $referencia = "--";
            $telefono = "999999999";
            if($data['telefono'] != ""){
                $telefono =$data['telefono'];
            }
            if($data['correo'] != ""){
                $correo =$data['correo'];
            }
            if($data['referencia'] != ""){
                $referencia =$data['referencia'];
            }
            $consulta = "call usp_restRegCliente( :flag, @a, :tipo_cliente, :dni, :ruc, :nombres, :razon_social, :telefono, :fecha_nac, :correo, :direccion, :referencia, :idemp, :idsede);";
                $arrayParam =  array(
                    ':flag' => 1,
                    ':tipo_cliente' => $data['tipo_cliente'],
                    ':dni' => $data['dni'],
                    ':ruc' => $data['ruc'],
                    ':nombres' => $data['nombres'],
                    ':razon_social' => $data['razon_social'],
                    ':telefono' => $telefono,
                    ':fecha_nac' => date('Y-m-d',strtotime($data['fecha_nac'])),
                    ':correo' => $correo,
                    ':direccion' => $data['direccion'],
                    ':referencia' => $referencia,
                    ':idemp' => $idemp,
                    ':idsede' => $idsede
                  );
                $st = $this->db->prepare($consulta);
                $st->execute($arrayParam);
                $c = $st->fetch(PDO::FETCH_OBJ);
                return $c;
            } catch (Exception $e) 
            {
                die($e->getMessage());
            }
    }

    public function cliente_crud_update($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call usp_restRegCliente( :flag, :id_cliente, :tipo_cliente, :dni, :ruc, :nombres, :razon_social, :telefono, :fecha_nac, :correo, :direccion, :referencia, :idemp, :idsede);";
                $arrayParam =  array(
                    ':flag' => 2,
                    ':id_cliente' => $data['id_cliente'],
                    ':tipo_cliente' => $data['tipo_cliente'],
                    ':dni' => $data['dni'],
                    ':ruc' => $data['ruc'],
                    ':nombres' => $data['nombres'],
                    ':razon_social' => $data['razon_social'],
                    ':telefono' => $data['telefono'],
                    ':fecha_nac' => date('Y-m-d',strtotime($data['fecha_nac'])),
                    ':correo' => $data['correo'],
                    ':direccion' => $data['direccion'],
                    ':referencia' => $data['referencia'],
                    ':idemp' => $idemp,
                    ':idsede' => $idsede
                );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetch(PDO::FETCH_OBJ);
            return $c;
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }

    public function buscar_cliente($data)
    {
        try
        {
            $idemp=Session::get('idemp');        
            /*nota: para kerlyn quitar el tipo_cliente de la consulta*/
            $tipo_cliente = $data['tipo_cliente'];
            
            if($data['tipo_cliente'] == 2){
                $tipo_cliente = $data['tipo_cliente'];
                $cadena = "%".$data['cadena']."%";
            }else if($data['tipo_cliente'] == 1){
                $tipo_cliente = "%";
                $cadena = "%".$data['cadena']."%";
            } else {
                $tipo_cliente = "%";
                $cadena = "%";
            }

            $consulta = "call sp_get_clientes(:idemp,:id_cliente,:tipo_cliente,:estado,:buscar);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':id_cliente' => '%',
                ':tipo_cliente' => $tipo_cliente,
                ':estado' => '%',
                ':buscar' => $cadena
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
            $c = array_filter($c, function ($cliente) {
                return $cliente->estado !== 'i';
            });
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function buscar_cliente_telefono($data)
    {
        try
        {        
            /*nota: para kerlyn quitar el tipo_cliente de la consulta*/
            $idemp=Session::get('idemp');
            $cadena = "%".$data['cadena']."%";
            $consulta = "call sp_get_clientes(:idemp,:id_cliente,:tipo_cliente,:estado,:buscar);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':id_cliente' => '%',
                ':tipo_cliente' => '%',
                ':estado' => '%',
                ':buscar' => $cadena
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
            $c = array_filter($c, function ($cliente) {
                return $cliente->estado !== 'i';
            });
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }


    public function tags_list($data)
    {
        try
        {
            $idemp=Session::get('idemp');        
            $stm = $this->db->prepare("SELECT p.id_prod,p.notas FROM tm_producto AS p INNER JOIN tm_producto_pres AS pp ON p.id_prod = pp.id_prod WHERE pp.idemp = ? AND pp.id_pres = ?");
            $stm->execute(array($idemp,$data['id_pres']));
            return $stm->fetch(PDO::FETCH_OBJ); 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function tags_crud($data)
    {
        try 
        {
            $sql = "UPDATE tm_producto SET notas = ? WHERE id_prod = ?";
            $this->db->prepare($sql)->execute(array($data['notas'],$data['id_prod']));
        }
        catch (Exception $e) 
        {
            return false;
        }
    }
    public function estadoCaja($data){
        try{
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 
            $stm = $this->db->prepare("SELECT id_usu, estado FROM tm_aper_cierre WHERE estado = ? AND id_usu = ? AND idemp = ? AND idsede = ?");
            $stm->execute(array($data['estado'],$data['idUsu'],$idemp,$idsede)); 
            return $stm->fetch(PDO::FETCH_ASSOC);

        }catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function RegistrarVenta($data)
    {
        try
        {
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');

            $descupersonas = 0; //descuento_personas
            if($data['descuento_personal'] != ""){
                $descupersonas = $data['descuento_personal'];
            }

            if($data['tipo_doc'] == 4){
                $tipo_doc = 2;
            }else{
                $tipo_doc=$data['tipo_doc'];
            }
            $sql_tipo_pago = $this->db->selectOne("SELECT * FROM tm_tipo_pago WHERE id_tipo_pago =".$data['tipo_pago']);

            $consulta = "call usp_restEmitirVenta(:flag, :dividir_cuenta, :id_pedido, :tipo_pedido, :tipo_entrega, :id_cliente, :id_tipo_doc, :id_pago, :id_usu, :id_apc, :pago_efe_none, :descuento_tipo, :descuento_personal, :descuento_monto, :descuento_motivo, :comision_tarjeta, :comision_delivery, :igv, :total, :codigo_operacion, :fecha_venta, :idemp, :idsede, :crt_fac_cons);";
            $arrayParam = array(
                ':flag' => 1,
                ':dividir_cuenta' =>  $data['dividir_cuenta'],
                ':id_pedido' =>  $data['id_pedido'],
                ':tipo_pedido' =>  $data['tipo_pedido'],
                ':tipo_entrega' =>  $data['tipo_entrega'],
                ':id_cliente' =>  $data['cliente_id'],
                ':id_tipo_doc' =>  $tipo_doc,
                ':id_pago' =>  $sql_tipo_pago['id_pago'],
                ':id_usu' =>  Session::get('usuid'),
                ':id_apc' =>  Session::get('apcid'),
                ':pago_efe_none' => $data['pago_efe'],
                ':descuento_tipo' => $data['descuento_tipo'],
                ':descuento_personal' => $descupersonas,
                ':descuento_monto' => $data['descuento_monto'],
                ':descuento_motivo' => $data['descuento_motivo'],
                ':comision_tarjeta' => $data['comision_tarjeta'],
                ':comision_delivery' => $data['comision_delivery'],
                ':igv' => Session::get('igv'),
                ':total' =>  $data['total'],
                ':codigo_operacion' =>  $data['codigo_operacion'],
                ':fecha_venta' =>  $fecha,
                ':idemp' =>  $idemp,
                ':idsede' =>  $idsede,
                ':crt_fac_cons' => $data['crt_fac_cons']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);

            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                $id_venta = $row['id_venta'];
            }
            if($id_venta != 0) {
                $this->db = new Database(DB_TYPE, DB_HOST, DB_NAME, DB_USER, DB_PASS, DB_CHARSET);
                $a = $data['idProd'];
                $b = $data['cantProd'];
                $c = $data['precProd'];
                $d = $data['nombre_prod'];
                $e = $data['crt_cambio'];
                $f = $data['costo_prod'];
    
                for($x=0; $x < sizeof($a); ++$x){
                    if ($b[$x] > 0){
                        $sql = "INSERT INTO tm_detalle_venta (id_venta,id_prod,cantidad,precio,idemp,idsede,nom_prod_pres,crt_mod_prod,costo,fecha_venta) VALUES (?,?,?,?,?,?,?,?,?,?);";
                        $this->db->prepare($sql)->execute(array($id_venta,$a[$x],$b[$x],$c[$x],$idemp,$idsede,$d[$x],$e[$x],$f[$x],$fecha));
                        
                    }
    
                    $consinventa = "call ventaActualizaInventario(:idProdu, :id_venta, :cantidad, :precio , :fecha, :idemp, :idsede);";//revisar que el crt_stock sea 0 paraa actualizar
                        $arrayParam = array(
                            ':idProdu' => $a[$x],
                            ':id_venta' =>  $id_venta,
                            ':cantidad' => $b[$x],
                            'precio' => $c[$x],
                            ':fecha' =>  $fecha,
                            ':idemp' =>  $idemp,
                            ':idsede' =>  $idsede
                        );
                    $stm1 = $this->db->prepare($consinventa);
                    $stm1->execute($arrayParam);
                }
    
                $this->db = new Database(DB_TYPE, DB_HOST, DB_NAME, DB_USER, DB_PASS, DB_CHARSET);
                $cons = "call usp_restEmitirVentaDet( :flag, :id_venta, :id_pedido, :fecha, :idemp, :idsede);";
                $arrayParam = array(
                    ':flag' => 1,
                    ':id_venta' =>  $id_venta,
                    ':id_pedido' =>  $data['id_pedido'],
                    ':fecha' =>  $fecha,
                    ':idemp' =>  $idemp,
                    ':idsede' =>  $idsede
                );
                $stm = $this->db->prepare($cons);
                $stm->execute($arrayParam);

                if($data['tipo_pago'] ==  3){
                    $t_pago = $data['venta_pago'];
                    foreach ($t_pago as $element) {
                        $id_tipo_pago = $element['id_tipo_pago'];
                        $descripcion = $element['descripcion'];
                        $cant_recibida = $data['descuento_tipo'] == '1' ? 0 : $element['cant_recibida'];
                        $sql = "INSERT INTO tm_venta_pago(id_venta,id_tipo_pago,cant_pago,estado) VALUES (?,?,?,?)";
                        $this->db->prepare($sql)->execute(array($id_venta,$id_tipo_pago,$cant_recibida,1));
                    }
                }else{

                    $total_tip_pa = $data['descuento_tipo'] == '1' ? 0 : ($data['total'] + $data['comision_delivery'] - $data['descuento_monto']);
                    $sql = "INSERT INTO tm_venta_pago(id_venta,id_tipo_pago,cant_pago,estado) VALUES (?,?,?,?)";
                    $this->db->prepare($sql)->execute(array($id_venta,$data['tipo_pago'],$total_tip_pa,1));
                }
            }

            return $id_venta;

        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function venta_editar_fecha($data){
        try{

            $fechaObj = date_create_from_format("d-m-Y", $data['fecha_ven']);

            $fechaFormateada = date_format($fechaObj, "Y-m-d");

            $resSql="0";

            // Obtén la hora original de la base de datos
            $sqlHora = "SELECT TIME(fecha_venta) AS hora_original FROM tm_venta WHERE id_venta = ?";
            $stmt = $this->db->prepare($sqlHora);
            $stmt->execute(array($data['id_venta']));
            $horaOriginal = $stmt->fetchColumn();

            // Combina la fecha formateada y la hora original
            $fechaYHora = $fechaFormateada . ' ' . $horaOriginal;

            $sql = "UPDATE tm_venta SET fecha_venta = ? WHERE id_venta = ?";
            $resp = $this->db->prepare($sql)->execute(array($fechaYHora,$data['id_venta']));

            if($resp){
                $resSql = "2";
            }

            return $resSql;
            
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function anular_pedido($data)
    {
        try
        {
            if($data['tipo_pedido'] == 1){

                $consulta = "call usp_restDesocuparMesa( :flag, :id_pedido);";
                $arrayParam =  array(
                    ':flag' => 1,
                    ':id_pedido' =>  $data['id_pedido']
                );
                $st = $this->db->prepare($consulta);
                $st->execute($arrayParam);

            } elseif($data['tipo_pedido'] == 2 OR $data['tipo_pedido'] == 3){
                
                $sql = "UPDATE tm_pedido SET estado = 'z' WHERE id_pedido = ?";
                $this->db->prepare($sql)->execute(array($data['id_pedido']));
                $sql1 ="DELETE FROM tm_detalle_pedido WHERE id_pedido = ?";
                $this->db->prepare($sql1)->execute(array($data['id_pedido']));
                $sql2 ="DELETE FROM tm_pedido_llevar WHERE id_pedido = ?";
                $this->db->prepare($sql2)->execute(array($data['id_pedido']));
                $sql3 ="DELETE FROM tm_pedido_delivery WHERE id_pedido = ?";
                $this->db->prepare($sql3)->execute(array($data['id_pedido']));
                /*$sql4 ="DELETE FROM tm_pedido WHERE id_pedido = ?";
                $this->db->prepare($sql4)->execute(array($data['id_pedido']));*/
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function anular_venta($data)
    {
        try
        { 
            $resp= 0;  
            $sql1 = "UPDATE tm_inventario SET estado = 'i' WHERE id_tipo_ope = 2 AND id_ope = ?";
            $this->db->prepare($sql1)->execute(array($data['id_venta']));
            $sql2 = "UPDATE tm_venta SET estado = 'i' WHERE id_venta = ?";
            $this->db->prepare($sql2)->execute(array($data['id_venta']));
            $sql3 = "UPDATE tm_pedido SET estado = 'z' WHERE id_pedido = ?";
            $result = $this->db->prepare($sql3)->execute(array($data['id_pedido']));

            if($result){
                $resp = $data['id_venta'];
            }
            return $resp;
        } 
            catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function pedido_edit($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $stm = $this->db->prepare("SELECT * FROM tm_pedido_delivery WHERE idemp = ? AND idsede = ? AND id_pedido = ?");
            $stm->execute(array($idemp,$idsede,$data['id_pedido']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function pedido_delete($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            //Seleccionar producto
            $stm = $this->db->prepare("SELECT p.nombre AS producto, pp.presentacion AS presentacion, d.cant AS cantidad, 
            d.precio, d.comentario, i.nombre AS nombre_imp FROM tm_detalle_pedido AS d 
            INNER JOIN tm_producto_pres AS pp ON d.id_pres = pp.id_pres
            INNER JOIN tm_producto AS p ON pp.id_prod = p.id_prod   
            INNER JOIN tm_area_prod AS a ON a.id_areap = p.id_areap 
            INNER JOIN tm_impresora AS i ON i.id_areap = a.id_areap 
            WHERE d.idemp = ? AND d.idsede = ? AND d.id_pedido = ? AND d.id_pres = ? AND d.estado <> 'z' AND i.estado = 'a' AND d.cant > 0 
            GROUP BY d.id_pres 
            ORDER BY d.fecha_pedido DESC");
            $stm->execute(array($idemp,$idsede,$data['id_pedido'],$data['id_pres']));
            $data_producto = $stm->fetchAll(PDO::FETCH_OBJ);

            //Cancelar pedido
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            // $filtro_seguridad = '9'.date('dm').'20';
            $filtro_seguridad = Session::get('cod_seg');
            $fecha_envio = date("Y-m-d H:i:s");
            $consulta = "call usp_restCancelarPedido( :flag, :id_usu, :id_pres, :id_pedido, :estado_pedido, :fecha_pedido, :fecha_envio, :codigo_seguridad, :filtro_seguridad, :motivo_anulacion);";
            $arrayParam =  array(
                ':flag' => 1,
                ':id_usu' => Session::get('usuid'),
                ':id_pres' => $data['id_pres'],
                ':id_pedido' =>  $data['id_pedido'],
                ':estado_pedido' =>  $data['estado_pedido'],
                ':fecha_pedido' => $data['fecha_pedido'],
                ':fecha_envio' => $fecha_envio,
                ':codigo_seguridad' => $data['codigo_seguridad'],
                ':filtro_seguridad' => $filtro_seguridad,
                ':motivo_anulacion' => $data['motivo_anulacion']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $codigo_respuesta = $st->fetchAll(PDO::FETCH_OBJ);

            $datos = array("Producto" => $data_producto,"Codigo" => $codigo_respuesta);
            $c = json_encode($datos);
            echo $c;

        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function pedido_crud_update($data)
    {
        try 
        {
            if($data['hora_entrega'] == ""){
                $hora_entrega = date('H:i:s');
            }else{
                $hora_entrega = $data['hora_entrega'];
            }
            $sql = "UPDATE tm_pedido_delivery SET id_repartidor = ?, hora_entrega = ?, amortizacion = ?, tipo_pago = ?, paga_con = ?, comision_delivery = ? WHERE id_pedido = ?";
            $this->db->prepare($sql)->execute(array($data['id_repartidor'],$hora_entrega,$data['amortizacion'],
                $data['tipo_pago'],$data['paga_con'],$data['comision_delivery'],$data['id_pedido']));
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function venta_edit_pago($data)
    {
        try 
        {
            $sql_tipo_pago = $this->db->selectOne("SELECT id_pago FROM tm_tipo_pago WHERE id_tipo_pago =".$data['id_tipo_pago']);

            $sql = "UPDATE tm_venta SET id_pago = ? WHERE id_venta = ?";
            $this->db->prepare($sql)->execute(array($sql_tipo_pago['id_pago'] ,$data['id_venta']));

            $sql = "UPDATE tm_venta_pago SET id_tipo_pago = ? WHERE id_venta = ?";
            $this->db->prepare($sql)->execute(array($data['id_tipo_pago'],$data['id_venta']));

        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function venta_edit_documento($data)
    {
        try 
        {
            $consulta = "call usp_restEditarVentaDocumento( :flag, :id_venta, :id_cliente, :id_tipo_documento);";
            $arrayParam =  array(
                ':flag' => 1,
                ':id_venta' =>  $data['id_venta'],
                ':id_cliente' => $data['id_cliente'],
                ':id_tipo_documento' => $data['id_tipo_documento']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $row = $st->fetch(PDO::FETCH_ASSOC);
            return $row;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }


    /* INICIO PEDIDOS PREPARADOS */

    public function contadorPedidosPreparados()
    {
        try
        { 
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');   
            $idmozo = Session::get('usuid');   

            $consulta = "call sp_cocina_me(:idemp,:idsede,:id_areap,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_areap' => "0",
                ':estado' => 'c'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
              // Crear un nuevo array para agrupar los pedidos por el id del pedido
            // Filtrar por estados diferentes de 'c'
            $c = array_filter($c, function ($pedido) {
                if(Session::get('rol') == 1 OR Session::get('rol') == 2 OR Session::get('rol') == 3){
                    return $pedido->cantidad > 0;
                }else if(Session::get('rol') == 5){
                    return $pedido->cantidad > 0 && $pedido->id_mozo == Session::get('usuid');
                }
            });

            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function listarPedidosPreparados()
    {
        try
        {  
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $idmozo = Session::get('usuid');

            $consulta = "call sp_cocina_me(:idemp,:idsede,:id_areap,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_areap' => 0,
                ':estado' => 'c'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);

              // Crear un nuevo array para agrupar los pedidos por el id del pedido
            // Filtrar por estados diferentes de 'c'
            $c = array_filter($c, function ($pedido) {
                if(Session::get('rol') == 1 OR Session::get('rol') == 2 OR Session::get('rol') == 3){
                    return $pedido->cantidad > 0;
                }else if(Session::get('rol') == 5){
                    return $pedido->cantidad > 0 && $pedido->id_mozo == Session::get('usuid');
                }
            });
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function pedidoEntregado($data)
    {
        try
        {   
            $sql = "UPDATE tm_detalle_pedido SET estado = 'd' WHERE id_pedido = ? AND id_pres = ? AND fecha_pedido = ?";
            $this->db->prepare($sql)
              ->execute(array(
                $data['id_pedido'],
                $data['id_pres'],
                $data['fecha_pedido']
                ));
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    //cambiar el estado de las mesas despues de un pedido
    public function CambiarStadoMesa($data)
    {
        try {
            if($data['estado']=='i'){$estado='a';}
            $sql="UPDATE tm_mesa SET estado = ? WHERE id_mesa = ? AND";
            $this->db->prepare($sql)->execute(array(
                $estado,
                $data['id_mesa']
            ));
        } catch (\Exception $e) {
            return false;
        }
    }
    
    public function pedido_estado_update($data)
    {
        try 
        {
            if($data['estado']=='i'){$estado='p';}elseif($data['estado']=='p'){$estado='p';};
            $sql = "UPDATE tm_mesa SET estado = ? WHERE id_mesa = ?";
            $this->db->prepare($sql)->execute(array($estado,$data['id_mesa']));
        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    /* FIN PEDIDOS PREPARADOS */

    public function menu_categoria_list()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 
            $stm = $this->db->prepare("SELECT * FROM tm_producto_catg WHERE delivery = 1 AND idemp = ?");
            $stm->execute(array($idemp));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function menu_plato_list($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $stm = $this->db->prepare("SELECT p.nombre AS pro_nom,pp.presentacion AS pro_pre,pp.precio AS pro_cos,pp.estado AS est_c,
            p.id_catg AS id_catg,pp.id_pres AS id_pres
            FROM tm_producto_pres AS pp
            JOIN tm_producto AS p ON pp.id_prod = p.id_prod
            JOIN tm_producto_catg AS cp ON p.id_catg = cp.id_catg WHERE pp.idemp = ? AND pp.id_pres <> 0 AND cp.delivery = 1 AND p.delivery = 1 AND pp.delivery = 1 AND p.id_catg = ?");
            $stm->execute(array($idemp,$data['id_catg']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function menu_plato_estado($data)
    {
        try 
        {
            if($data['estado']=='a'){$estado='i';}elseif($data['estado']=='i'){$estado='a';};
            $sql = "UPDATE tm_producto_pres SET estado = ? WHERE id_pres = ?";
            $this->db->prepare($sql)->execute(array($estado,$data['id_pres']));
        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    /* INICIO IMPRESION */
    //Impresion de la precuenta
    public function impresion_precuenta($data)
    {
        try
        {  
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');   
            if($data['tip_ped'] == 1){ $sp_pedido = 'sp_pedido_mesa'; } elseif($data['tip_ped'] == 2) { $sp_pedido = 'sp_pedido_llevar'; } elseif($data['tip_ped'] == 3) { $sp_pedido = 'sp_pedido_delivery'; }
            
            $consulta = "call ".$sp_pedido."(:idemp,:idsede,:id_pedido,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_pedido' => $data['id_pedido'],
                ':estado'=>'a'
            );
            $stm = $this->db->prepare($consulta);
            $stm->execute($arrayParam);
            $c = $stm->fetch(PDO::FETCH_OBJ);
            $stm->closeCursor();

            $c->{'Detalle'} = $this->db->query("SELECT id_pres,SUM(cantidad) AS cantidad, precio, detatopico, SUM(precioTopico) AS precioTopico, nom_prod_pres, crt_mod_prod FROM tm_detalle_pedido WHERE id_pedido = " . $c->id_pedido." AND estado <> 'z' GROUP BY id_pres, detatopico, precio,nom_prod_pres")
                ->fetchAll(PDO::FETCH_OBJ);
            foreach($c->Detalle as $k => $d)
            {
                if($d->crt_mod_prod == 1){
                    $nom_prod_pres = $d->nom_prod_pres;
                    $c->Detalle[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom,'".$nom_prod_pres."' AS pro_pre FROM tm_producto_pres pp JOIN tm_producto p ON pp.id_prod = p.id_prod WHERE pp.id_pres = " . $d->id_pres)
                    ->fetch(PDO::FETCH_OBJ);

                }else{
                    $c->Detalle[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom,pp.presentacion AS pro_pre FROM tm_producto_pres pp JOIN tm_producto p ON pp.id_prod = p.id_prod WHERE pp.id_pres = " . $d->id_pres)
                    ->fetch(PDO::FETCH_OBJ);
                }
            }

            $c->{'Impresora'} = $this->db->query("SELECT * FROM tm_impresora WHERE id_imp LIKE '%' and estado = 'a' and impr_caja='a' AND idemp =". $idemp ." AND idsede =".$idsede)
                ->fetch(PDO::FETCH_OBJ);

            $c->{'pc_name'} = $this->db->query("SELECT pc_name FROM tm_configuracion WHERE idemp =". $idemp . " AND idsede =". $idsede)
                ->fetch(PDO::FETCH_OBJ);
            $c->{'msg_impre'} = Session::get('msg_impre');
            //SELECT pc_name FROM tm_configuracion;
            

            $c->{'host_pc'} = Session::get('host_pc');
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    //Impresion de la precuenta en pdf
    public function impresion_precuentapdf($id_pedido,$tipo_pedido)
    {
        try
        {  
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');   
            if($tipo_pedido == 1){ $sp_pedido = 'sp_pedido_mesa'; } elseif($tipo_pedido == 2) { $sp_pedido = 'sp_pedido_llevar'; } elseif($tipo_pedido == 3) { $sp_pedido = 'sp_pedido_delivery'; }
            
            $consulta = "call ".$sp_pedido."(:idemp,:idsede,:id_pedido,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_pedido' => $id_pedido,
                ':estado'=>'a'
            );
            $stm = $this->db->prepare($consulta);
            $stm->execute($arrayParam);
            $c = $stm->fetch(PDO::FETCH_OBJ);
            $stm->closeCursor();
                
            $c->{'Topico'} = $this->db->query("SELECT count(*) AS cant,id_pres, detatopico,SUM(precioTopico) AS precioTopico FROM tm_detalle_pedido WHERE id_pedido =" . $c->id_pedido . " AND estado <> 'z' AND precioTopico > 0 GROUP BY detatopico")
                ->fetchAll(PDO::FETCH_OBJ);
            /* Traemos el detalle */
            $c->{'Detalle'} = $this->db->query("SELECT id_pres,SUM(cantidad) AS cantidad, precio, nom_prod_pres, crt_mod_prod FROM tm_detalle_pedido WHERE id_pedido = " . $c->id_pedido." AND estado <> 'z' GROUP BY id_pres, precio,nom_prod_pres")
                ->fetchAll(PDO::FETCH_OBJ);
            foreach($c->Detalle as $k => $d)
            {
                if($d->crt_mod_prod == 1){
                    $nom_prod_pres = $d->nom_prod_pres;
                    $c->Detalle[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom,'".$nom_prod_pres."' AS pro_pre FROM tm_producto_pres pp JOIN tm_producto p ON pp.id_prod = p.id_prod WHERE pp.id_pres = " . $d->id_pres)
                    ->fetch(PDO::FETCH_OBJ);
                }else{
                    $c->Detalle[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom,pp.presentacion AS pro_pre FROM tm_producto_pres pp JOIN tm_producto p ON pp.id_prod = p.id_prod WHERE pp.id_pres = " . $d->id_pres)
                    ->fetch(PDO::FETCH_OBJ);
                }
            }

            $c->{'Impresora'} = $this->db->query("SELECT * FROM tm_impresora WHERE id_imp LIKE '%' and estado = 'a' and impr_caja='a' AND idemp=" . $idemp . " AND idsede=". $idsede)
                ->fetch(PDO::FETCH_OBJ);

            $c->{'pc_name'} = $this->db->query("SELECT pc_name FROM tm_configuracion WHERE idemp =". $idemp . " AND idsede =". $idsede)
                ->fetch(PDO::FETCH_OBJ);
            //SELECT pc_name FROM tm_configuracion;

            $c->{'host_pc'} = Session::get('host_pc');
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function impresion_reparto($id_venta)
    {
        try
        { 
  
            $stm = $this->db->prepare("SELECT v.id_venta AS id_ven, v.id_pedido AS id_ped,v.id_cliente AS id_cli,tp.descripcion AS desc_tp,v.id_pago AS id_tpag,
            v.fecha_venta AS fec_ven,v.pago_efe_none AS pago_efe_none,
            SUM(CASE WHEN tp.id_pago = 1 THEN tvp.cant_pago  ELSE 0 END) AS pago_efe,
            SUM(CASE WHEN tp.id_pago <> 1 THEN tvp.cant_pago ELSE 0 END) AS pago_tar,
            IFNULL((v.total+v.comision_delivery-v.descuento_monto),0) AS total,
            tpd.nro_pedido, tpd.nombre_cliente, tpd.telefono_cliente, tpd.direccion_cliente, tpd.referencia_cliente, 
            tpd.email_cliente,tc.tipo_cliente AS tipo_cliente,tc.dni AS dni,tc.ruc AS ruc 
            FROM tm_venta v
            JOIN tm_venta_pago tvp ON v.id_venta = tvp.id_venta
            JOIN tm_tipo_pago tp ON tvp.id_tipo_pago = tp.id_tipo_pago
            JOIN tm_pedido_delivery AS tpd ON v.id_pedido = tpd.id_pedido
            JOIN tm_cliente AS tc ON tpd.id_cliente =tc.id_cliente 
            WHERE v.id_venta <> 0 AND v.id_venta = ? GROUP BY tvp.id_venta");
            $stm->execute(array($id_venta));
            $c = $stm->fetch(PDO::FETCH_OBJ);

            $c->{'Detalle'} = $this->db->query("SELECT id_prod,SUM(cantidad) AS cantidad, precio FROM tm_detalle_venta WHERE id_venta = " . $c->id_ven." GROUP BY id_prod, precio")
                ->fetchAll(PDO::FETCH_OBJ);
            foreach($c->Detalle as $k => $d)
            {
                $c->Detalle[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom,pp.presentacion AS pro_pre  FROM tm_producto_pres pp JOIN tm_producto p ON pp.id_prod = p.id_prod  WHERE pp.id_pres = " . $d->id_prod)
                    ->fetch(PDO::FETCH_OBJ);
            }
            $c->{'DetaTopico'} = $this->db->query("SELECT detatopico, precioTopico FROM tm_detalle_pedido WHERE id_pedido = " . $c->id_ped." AND estado <> 'z' AND precioTopico > 0")
                ->fetchAll(PDO::FETCH_OBJ);

            $c->{'Tipopago'} = $this->db->query("SELECT descripcion AS nombre,tvp.cant_pago FROM tm_venta_pago as tvp join tm_tipo_pago as ttp on tvp.id_tipo_pago = ttp.id_tipo_pago WHERE tvp.id_venta = " . $c->id_ven)
                ->fetchAll(PDO::FETCH_OBJ);

            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function contador_comanda()
    {
        try
        { 
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');  
            $stm = $this->db->prepare("SELECT COUNT(*) AS correlativo FROM tm_detalle_pedido WHERE idemp = $idemp AND idsede = $idsede GROUP BY id_pedido,fecha_pedido");
            $stm->execute();
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function alert_pedidos_programados()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');   
            $stm = $this->db->prepare("SELECT MIN(pd.hora_entrega) AS hora_entrega, pd.id_pedido, pd.nombre_cliente, pd.nro_pedido FROM tm_pedido_delivery AS pd INNER JOIN tm_pedido AS p ON pd.id_pedido = p.id_pedido WHERE pd.pedido_programado = 1 AND p.estado = 'a' AND idemp = ? AND idsede = ?");
            $stm->execute(array($idemp,$idsede));
            $c = $stm->fetch(PDO::FETCH_OBJ);
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    /* FIN IMPRESION */

    public function control_stock_pedido($data)
    {
        try {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            
            $id_pres = $data['id_pres'];
            $cod_ped = $data['cod_ped'];
            $resp = 0;
            if($data['id_tipo'] == 1){
                $id_tipo_ins = "3";
            }else{
                $id_tipo_ins = "2";
            }

            $consulta = "call sp_get_stock(:idemp,:idsede,:id_ins,:id_tipo_ins);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_ins' => $id_pres,
                ':id_tipo_ins' => $id_tipo_ins
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetch(PDO::FETCH_OBJ);
            $st->closeCursor();

            if($c){
                $cant_pedido = $this->db->query("SELECT IFNULL(SUM(cant),0) AS cant_pedido FROM tm_detalle_pedido WHERE id_pedido =". $cod_ped ." AND id_pres =".$c->id_ins . " AND estado = 'a'") ->fetch(PDO::FETCH_OBJ);
                $c->{'cant_pedido'} = $cant_pedido->cant_pedido;

                $resp = $c;
            }

            return $resp;
        } catch (Exception $e) {
            return false;
        }
    }

}