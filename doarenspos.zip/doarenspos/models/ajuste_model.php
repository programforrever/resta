<?php Session::init();
require_once "vendor/autoload.php";
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

?>
<?php

class Ajuste_Model extends Model
{
	public function __construct()
	{
		parent::__construct();
	}

    public function AreaProduccion()
    {
        try
        {   
            $idemp=Session::get('idemp');   
            return $this->db->selectAll('SELECT * FROM tm_area_prod WHERE idemp = ' . $idemp . ' AND estado = "a"');
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Rol()
    {
        try
        {      
            return $this->db->selectAll('SELECT * FROM tm_rol WHERE id_rol <> 1');
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function UnidadMedida()
    {
        try
        {      
            return $this->db->selectAll('SELECT * FROM tm_tipo_medida');
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function TipoDocumento()
    {
        try
        {      
            return $this->db->selectAll('SELECT * FROM tm_tipo_doc');
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Impresora()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');      
            return $this->db->selectAll('SELECT * FROM tm_impresora WHERE estado = "a" AND idemp =' . $idemp . ' AND idsede =' .$idsede);
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    /***INICIO MODULO MULTIEMPRESA */
    public function empresa_list()/*datosistema_data*/
    {
        try
        {
            //CAMBIAR EL LEFT POR EL INNER
            $stm = $this->db->prepare("SELECT * FROM tm_empresa 
            INNER JOIN tm_configuracion ON id_de =idemp WHERE principal = 1 AND ruc LIKE ?");

            $stm->execute(array($_POST['ruc']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;
            /*While(var i in ddd){
                $data1[nombre] = i.nombre;
                $data1[Produccion] = i.produccion;
                $data1[bloqueo] = new classConfir.getById(i.id_empresa);
            }*/
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function empresa_list_data($id)
    {
        $idusu = Session::get('usuid');
        return $this->db->selectOne('SELECT e.id_de,e.ruc,e.razon_social,e.nombre_comercial,e.direccion_comercial,e.direccion_fiscal,e.ubigeo,e.departamento,e.provincia,
        e.distrito,e.sunat,e.modo,e.logo,e.celular,e.email,e.namesubdominio,e.urlapi,e.passentorno,e.optimiproceso,e.crt_plan,e.crt_sede,u.id_usu,u.usuario,u.contrasena,u.estado FROM tm_empresa e
        JOIN tm_usuario u ON e.id_de = u.idEmpresa WHERE e.id_de=:id_de AND u.id_usu=:id_usu' , 
            array(':id_de' => $id,':id_usu' => $idusu));
    }

    public function sedeempresa_crud_create($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $consulta = "call usp_sedeempresaconfi(:id_empresa, :nombre, :direccion, :departamento, :provincia, :distrito, :estado, :telefono);";
            $arrayParam =  array(
                ':id_empresa' => $idemp,
                ':nombre' => $data['nombre'],
                ':direccion' => $data['direccion'],
                ':departamento' => $data['departamento'],
                ':provincia' => $data['provincia'],
                ':distrito' => $data['distrito'],
                ':estado' => $data['estado'],
                ':telefono' => $data['telefono']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
 
        }catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function sedeempresa_crud_update($data)
    {
        try
        {
            $envres= "0";
            $sql2 = "UPDATE tm_sedes SET nombre = ?, direccion = ?, departamento= ?, provincia = ?, distrito= ? , estado = ?, telefono = ? WHERE id_sede = ?";
            $resp = $this->db->prepare($sql2)->execute(array($data['nombre'],$data['direccion'],$data['departamento'],$data['provincia'],$data['distrito'],$data['estado'],$data['telefono'],$data['id_sede']));

            if($resp){
                $envres = "2";
            }
            return $envres;
            
        }catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function empresa_sede_list()
    {
        try
        {
            $stm = $this->db->prepare("SELECT * FROM tm_sedes WHERE id_empresa = ? and id_sede LIKE ?");
            $stm->execute(array($_POST['id_empresa'], $_POST['id_sedes']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function empresa_sede_list_select($id)
    {
        try
        {
            return $this->db->selectAll('SELECT * FROM tm_sedes WHERE id_empresa = :id_empresa',array('id_empresa' => $id));

        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function crudsede_usuario($data){
        try{
            $res=1;
            $sedes = $data['sedes'];
            foreach ($sedes as $x => $valor){
                $sql = "INSERT INTO tm_sede_usuario(id_sede,id_usu) VALUES (?,?)";
                $this->db->prepare($sql)->execute(array($valor, $data['id_usu']));
            }
            return $res;
        }catch(Exception $e){
            die($e->getMessage());
        }

    }

    public function update_sede_usuario($data){
        try{
            $res=1;
            $sql1 ="DELETE FROM tm_sede_usuario WHERE id_usu = ?";
            $resq = $this->db->prepare($sql1)->execute(array($data['id_usu']));

            $sedes = $data['sedes'];
            foreach ($sedes as $x => $valor){
                $sql = "INSERT INTO tm_sede_usuario(id_sede,id_usu) VALUES (?,?)";
                $this->db->prepare($sql)->execute(array($valor, $data['id_usu']));
            }
            return $res;

        }catch(Exception $e){
            die($e->getMessage());
        }

    }


    
    public function usuario_sede_list()
    {
        try
        {
            $idemp=Session::get('idemp');
            $consulta = "call sp_get_usuarios(:idemp,:idsede,:id_usu,:id_rol,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => '%',
                ':id_usu' => '%',
                ':id_rol' => '%',
                ':estado' => '%'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
            $st->closeCursor();

            $c = array_filter($c, function ($filtro) {
                return $filtro->id_usu !== '1';
            });

            foreach($c as $k => $d)
            {
                $c[$k]->{'sedes'} = $this->db->query("SELECT ts.nombre AS namesede FROM tm_sede_usuario su INNER JOIN tm_sedes ts ON su.id_sede = ts.id_sede WHERE su.id_usu = $d->id_usu")
                    ->fetchAll(PDO::FETCH_OBJ);
            }

            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function selectpicker_sede(){
        $stm = $this->db->prepare("SELECT su.id_sede, ts.id_empresa, ts.nombre AS namesede, ts.direccion, ts.departamento, ts.provincia, ts.distrito, ts.estado FROM tm_sede_usuario su INNER JOIN tm_sedes ts ON su.id_sede = ts.id_sede WHERE su.id_usu = ?");
        $stm->execute(array($_POST['id_usu']));
        $c = $stm->fetchAll(PDO::FETCH_OBJ);
        $data = array("data" => $c);
        $json = json_encode($data);
        echo $json;
    }

    /****FIN MODULO MULTIEMPRESA */
    /* INICIO MODULO EMPRESA */

    public function tipodoc_list()
    {
        try
        {   
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');    
            $stm = $this->db->prepare("SELECT td.descripcion, ts.idserie,ts.id_tipo_doc,ts.serie,ts.numero,ts.estado FROM tm_tipo_doc td
            inner join tm_series ts on td.id_tipo_doc = ts.id_tipo_doc WHERE ts.idemp = ? AND ts.idsede = ?");
            $stm->execute(array($idemp,$idsede));            
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function tipodoc_crud_create($data)
    {
        try 
        {

            $res = 0;
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');

            $id_tipo_documento = $data['id_tipo_documento'];
            $sql_series = $this->db->selectOne("SELECT * FROM tm_series WHERE id_tipo_doc = $id_tipo_documento AND idemp = $idemp AND idsede = $idsede");

            if ($sql_series==false){
                $sql = "INSERT INTO tm_series SET id_tipo_doc  = ?, serie  = ?, numero = ?, estado = ?, idemp = ?, idsede = ?";
                $resultado = $this->db->prepare($sql)->execute(array($data['id_tipo_documento'],$data['serie'],$data['numero'],$data['estado'], $idemp, $idsede));

                if ($resultado){
                    $res=1;
                }
            }else{
                $res = 3;
            }
            
            return $res;
        
        
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function tipodoc_crud_update($data)
    {
        try 
        {
            $res = 0;
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $sql = "UPDATE tm_series SET id_tipo_doc  = ?, serie = ?, numero = ?, estado = ? WHERE idserie = ? AND idemp = ?";
            $resultado = $this->db->prepare($sql)->execute(array($data['id_tipo_documento'],$data['serie'],$data['numero'],$data['estado'],$data['idserie'],$idemp));
            if ($resultado){
                $res=2;
            }
            return $res;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function usuario_data($id)
    {
        try{

            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call sp_get_usuarios(:idemp,:idsede,:id_usu,:id_rol,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => '%',
                ':id_usu' => $id,
                ':id_rol' => '%',
                ':estado' => '%'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $resp = $st->fetch(PDO::FETCH_OBJ);
            $data = get_object_vars($resp);

            return $data;

        }catch (Exception $e) 
        {
            die($e->getMessage());
        }

    }

    public function usuario_crud_create($data)
    {
        try 
        {
            if( !empty( $_FILES['imagen']['name'] ) ){
                switch ($_FILES['imagen']['type']) 
                { 
                    case 'image/jpeg': 
                    $ext = "jpg"; 
                    break;
                    case 'image/gif': 
                    $ext = "gif"; 
                    break; 
                    case 'image/png': 
                    $ext = "png"; 
                    break;
                    case 'application/pdf':
                    $ext = "pdf";
                    break;
                }
                $imagen = date('ymdhis').'.'.$ext;
                move_uploaded_file ($_FILES['imagen']['tmp_name'], 'public/images/users/'.$imagen);
            } else {
                $imagen = $data['imagen'];
            }

            $area = (isset($data['id_areap'])) ? $data['id_areap'] : 0;

            $consulta = "call usp_configUsuario( :flag, @a, :id_rol, :id_areap, :dni, :ape_paterno, :ape_materno, :nombres, :email, :usuario, :contrasena, :imagen, :cod_mozo, :id_emp);";
            $arrayParam =  array(
                ':flag' => 1,
                ':id_rol' => $data['id_rol'],
                ':id_areap' => $area,
                ':dni' => $data['dni'],
                ':ape_paterno' => $data['ape_paterno'],
                ':ape_materno' => $data['ape_materno'],
                ':nombres' => $data['nombres'],
                ':email' => $data['email'],
                ':usuario' => $data['usuario'],
                ':contrasena' => base64_encode($data['contrasena']),
                ':imagen' => $imagen,
                ':cod_mozo' => base64_encode($data['contrasena']),
                ':id_emp' => $data['id_emp']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $row = $st->fetch(PDO::FETCH_ASSOC);
            
            return $row;
            
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function usuario_crud_update($data)
    {
        try 
        {
            if( !empty( $_FILES['imagen']['name'] ) ){
                switch ($_FILES['imagen']['type']) 
                { 
                    case 'image/jpeg': 
                    $ext = "jpg"; 
                    break;
                    case 'image/gif': 
                    $ext = "gif"; 
                    break; 
                    case 'image/png': 
                    $ext = "png"; 
                    break;
                    case 'application/pdf':
                    $ext = "pdf";
                    break;
                }
                $imagen = date('ymdhis').'.'.$ext;
                move_uploaded_file ($_FILES['imagen']['tmp_name'], 'public/images/users/'.$imagen);
            } else {
                $imagen = $data['imagen'];
            }

            $area = (isset($data['id_areap'])) ? $data['id_areap'] : 0;

            $consulta = "call usp_configUsuario( :flag, :id_usu, :id_rol, :id_areap, :dni, :ape_paterno, :ape_materno, :nombres, :email, :usuario, :contrasena, :imagen, :cod_mozo, :id_emp);";
            $arrayParam =  array(
                ':flag' => 2,
                ':id_usu' => $data['id_usu'],
                ':id_rol' => $data['id_rol'],
                ':id_areap' => $area,
                ':dni' => $data['dni'],
                ':ape_paterno' => $data['ape_paterno'],
                ':ape_materno' => $data['ape_materno'],
                ':nombres' => $data['nombres'],
                ':email' => $data['email'],
                ':usuario' => $data['usuario'],
                ':contrasena' => base64_encode($data['contrasena']),
                ':imagen' => $imagen,
                ':cod_mozo' => base64_encode($data['contrasena']),
                ':id_emp' => $data['id_emp']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $row = $st->fetch(PDO::FETCH_ASSOC);
            return $row;
            
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function usuario_estado($data)
    {
        try 
        {
            $sql = "UPDATE tm_usuario SET estado = ? WHERE id_usu = ?";
            $this->db->prepare($sql)
                ->execute(array($data['estado'],$data['id_usu']));
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function usuario_delete($data)
    {
        try 
        {
        if($data['id_rol'] == 1 OR $data['id_rol'] == 2){
            $consulta = "SELECT count(*) AS total FROM tm_pedido WHERE id_usu = ?";
        } else {
            $consulta = "SELECT count(*) AS total FROM tm_pedido_mesa WHERE id_mozo = ?";
        }
        $result = $this->db->prepare($consulta);
        $result->execute(array($data['id_usu']));
        $result->execute();
            if($result->fetchColumn()==0){
                $sql1 ="DELETE FROM tm_sede_usuario WHERE id_usu = ?";
                $resq = $this->db->prepare($sql1)->execute(array($data['id_usu']));

                $stm = $this->db->prepare("DELETE FROM tm_usuario WHERE id_usu = ?");          
                $stm->execute(array($data['id_usu']));
                return 1;
            }else{
                return 0;
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    /* FIN MODULO EMPRESA */
    public function TipoPago()
    {
        try
        {      
            return $this->db->selectAll('SELECT * FROM tm_pago WHERE estado = "a" AND id_pago <> 3');
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    public function tipopago_list($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            //$idsede=Session::get('sede_id');
            $stm = $this->db->prepare("SELECT * FROM tm_tipo_pago WHERE id_tipo_pago LIKE ? AND id_tipo_pago > 3 AND idemp = ?");
            $stm->execute(array($data['id_pago'],$idemp));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Tipo'} = $this->db->query("SELECT descripcion AS nombre FROM tm_pago WHERE id_pago = ".$d->id_pago)
                    ->fetch(PDO::FETCH_OBJ);
            }
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function tipopago_crud_create($data)
    {

        try
        {
            $res = 0;
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $sql = "INSERT INTO tm_tipo_pago SET id_pago = ? ,descripcion = ? ,estado = ?, idemp = ?, idsede = ?";
            $resultado = $this->db->prepare($sql)->execute(array($data['id_tipo_pago'],$data['nombre'],$data['estado'],$idemp, $idsede));
            if ($resultado){
                $res = 1;
            }
            return $res;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function tipopago_crud_update($data)
    {
        try 
        {
            $res = 0;
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $sql = "UPDATE tm_tipo_pago SET id_pago = ?, descripcion = ?, estado = ?,idsede = ? WHERE tm_tipo_pago.id_tipo_pago = ? AND idemp = ?";
            $resultado = $this->db->prepare($sql)->execute(array($data['id_tipo_pago'],$data['nombre'],$data['estado'], $idsede,$data['id_pago'],$idemp));
            if ($resultado){
                $res = 1;
            }
            return $res;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    /* INICIO MODULO RESTAURANTE */

    public function caja_list()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $stm = $this->db->prepare("SELECT * FROM tm_caja WHERE idemp = ? AND idsede = ?");
            $stm->execute(array($idemp,$idsede));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function caja_crud_create($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call usp_configCajas( :flag, @a, :descripcion, :estado, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 1,
                ':descripcion' => $data['descripcion'],
                ':estado' => $data['estado'],
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function caja_crud_update($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $resp;
            $sql_caja_est= $this->db->selectOne("SELECT estado FROM tm_caja WHERE id_caja =".$data['id_caja']);

            if ($sql_caja_est['estado'] !="c"){
                $consulta = "call usp_configCajas( :flag, :id_caja, :descripcion, :estado, :idemp, :idsede);";
                $arrayParam =  array(
                    ':flag' => 2,
                    ':id_caja' => $data['id_caja'],
                    ':descripcion' => $data['descripcion'],
                    ':estado' => $data['estado'],
                    ':idemp' => $idemp,
                    ':idsede' => $idsede
                );
                $st = $this->db->prepare($consulta);
                $st->execute($arrayParam);
                while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                    $resp= $row['cod'];
                }
            }else{
                $resp=$sql_caja_est['estado'];
            }

            return $resp;
            
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function areaprod_list($data)
    {
        try
        {
            $idemp=Session::get('idemp');

            $stm = $this->db->prepare("SELECT * FROM tm_area_prod WHERE id_areap like ? AND idemp = ?");
            $stm->execute(array($data['id_areap'],$idemp));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function areaprod_crud_create($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call usp_configAreasProd( :flag, @a, :id_imp, :nombre, :estado, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 1,                
                ':id_imp' => $data['id_imp'],
                ':nombre' => $data['nombre'],
                ':estado' => $data['estado'],
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function areaprod_crud_update($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call usp_configAreasProd( :flag, :id_areap, :id_imp, :nombre, :estado, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 2,
                ':id_areap' => $data['id_areap'],
                ':id_imp' => $data['id_imp'],
                ':nombre' => $data['nombre'],
                ':estado' => $data['estado'],
                ':idemp' => $idemp,
                ':idsede' => $idsede,                
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function salon_list()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $stm = $this->db->prepare("SELECT * FROM tm_salon WHERE idemp = ? AND idsede = ? ORDER BY id_salon ASC");
            $stm->execute(array($idemp,$idsede));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Mesas'} = $this->db->query("SELECT COUNT(id_mesa) AS total FROM tm_mesa WHERE id_salon = ".$d->id_salon)
                ->fetch(PDO::FETCH_OBJ);
            }
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    //validar mesa para que no permita cambiar de estado a una mesa, cuando está ocupada
    public function validarMesaEstado($data){
        try{
            $resp = 0;
            $stm = $this->db->prepare("SELECT id_mesa, id_salon, estado FROM tm_mesa WHERE id_mesa=?");
            $stm->execute(array($data['id_mesa']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ); 
            if($c != null){
                $resp = $c;
            }else{
                $resp = 1;
            }
            return $resp;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function mesa_list()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $stm = $this->db->prepare("SELECT * FROM tm_mesa WHERE id_salon like ? AND idemp = ? AND idsede = ? ORDER BY nro_mesa ASC");
            $stm->execute(array($_POST['id_salon'],$idemp,$idsede));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Salon'} = $this->db->query("SELECT descripcion FROM tm_salon WHERE id_salon = ".$d->id_salon)
                ->fetch(PDO::FETCH_OBJ);
            }
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function salon_crud_create($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call usp_configSalones( :flag, @a, :descripcion, :estado, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 1,
                ':descripcion' => $data['descripcion'],
                ':estado' => $data['estado'],
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    public function salon_crud_update($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call usp_configSalones( :flag, :id_salon, :descripcion, :estado, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 2,
                ':id_salon' => $data['id_salon'],
                ':descripcion' => $data['descripcion'],
                ':estado' => $data['estado'],
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    public function salon_crud_delete($data)
    {
        try 
        {
            
            $consulta = "call usp_configSalones( :flag, :id_salon, @a, @b, @c, @d);";
            $arrayParam =  array(
                ':flag' => 3,
                ':id_salon' => $data['id_salon']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function mesa_crud_create($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call usp_configMesas( :flag, @a, :id_salon, :nro_mesa, :estado, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 1,
                ':id_salon' => $data['id_salon'],
                ':nro_mesa' => $data['nro_mesa'],
                ':estado' => $data['estado'],
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    public function mesa_crud_update($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call usp_configMesas( :flag, :id_mesa, :id_salon, :nro_mesa, :estado, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 2,
                ':id_mesa' => $data['id_mesa'],
                ':id_salon' => $data['id_salon'],
                ':nro_mesa' => $data['nro_mesa'],
                ':estado' => $data['estado'],
                ':idemp' => $idemp,
                ':idsede' => $idsede                        
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    public function mesa_crud_delete($data)
    {
        try 
        {
            $consulta = "call usp_configMesas( :flag, :id_mesa, @a, @b, @c, @d, @e);";
            $arrayParam =  array(
                ':flag' => 3,
                ':id_mesa' => $data['id_mesa']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    /* ===================================== PRODUCTO*/
    public function producto_list()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $stm = $this->db->prepare("SELECT * FROM tm_producto WHERE id_prod like ? AND id_catg like ? AND id_catg <> 1 AND idemp = ? ORDER BY id_prod DESC");
            $stm->execute(array($_POST['id_prod'],$_POST['id_catg'],$idemp));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function listProductUpdate(){
        try{
            $stm = $this->db->prepare("SELECT p.id_prod, p.id_tipo, p.id_catg, p.id_areap, p.nombre, p.notas,p.descripcion,p.delivery,p.estado,t.id_topicos,t.nombre AS nombretopico FROM tm_producto p 
            LEFT JOIN tm_produc_topicos pt ON p.id_prod = pt.id_producto
            LEFT JOIN tm_topicos t ON pt.id_topicos = t.id_topicos WHERE id_prod like ? AND id_catg like ? AND id_catg <> 1 ORDER BY id_prod DESC");
            $stm->execute(array($_POST['id_prod'],$_POST['id_catg']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 

        }catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function producto_pres_list()
    {
        try
        {
            $idemp=Session::get('idemp');
            $stm = $this->db->prepare("SELECT * FROM tm_producto_pres WHERE id_prod LIKE ? AND id_pres LIKE ? AND idemp = ?");
            $stm->execute(array($_POST['id_prod'],$_POST['id_pres'],$idemp));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'TipoProd'} = $this->db->query("SELECT id_tipo FROM tm_producto WHERE id_prod = ".$d->id_prod)
                ->fetch(PDO::FETCH_OBJ);
            }
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function producto_cat_list()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $stm = $this->db->prepare("SELECT * FROM tm_producto_catg WHERE id_catg <> 1 AND idemp = ? ORDER BY orden ASC");
            $stm->execute(array($idemp));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function producto_pres_ing($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');

            $stm = $this->db->prepare("SELECT * FROM tm_producto_ingr WHERE id_pres = ?");
            $stm->execute(array($data['id_pres']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {

                $consulta = "call sp_get_insprod(:idemp,:idsede,:id_tipo_ins,:id_ins,:cadena);";
                $arrayParam =  array(
                    ':idemp' => $idemp,
                    ':idsede' => '%',
                    ':id_tipo_ins' => $d->id_tipo_ins,
                    ':id_ins' => $d->id_ins,
                    ':cadena'=>'%'
                );
                $st1 = $this->db->prepare($consulta);
                $st1->execute($arrayParam);
                $c[$k]->{'Insumo'} = $st1->fetch(PDO::FETCH_OBJ);
                $st1->closeCursor();

                $c[$k]->{'Medida'} = $this->db->query("SELECT descripcion FROM tm_tipo_medida WHERE id_med = ".$d->id_med)
                ->fetch(PDO::FETCH_OBJ);
                if($d->id_areap){
                    $c[$k]->{'nombProducion'} = $this->db->query("SELECT nombre FROM tm_area_prod WHERE id_areap = " . $d->id_areap)
                    ->fetch(PDO::FETCH_OBJ);
                }else{
                    $c[$k]->{'nombProducion'} ="--";
                }
            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function producto_buscar_ins($data)
    {
        try
        {   
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $cadena = $data['cadena'];
            $tipo = $data['tipo'];
            $tipo_prod = $data['tipo_prod'];
            $consulta = "call sp_get_insprod(:idemp,:idsede,:id_tipo_ins,:id_ins,:cadena);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_tipo_ins' => '%',
                ':id_ins' => '%',
                ':cadena'=>'%'.$cadena.'%'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
            $st->closeCursor();
            // Filtrar por estados diferentes de 'c'
            $c = array_filter($c, function ($insprod) use ($tipo_prod) {
                return $insprod->est_b == 'a' && $insprod->est_c == 'a' && $insprod->id_tipo_ins !== $tipo_prod;
            });

            // Limitar el número de respuestas a un máximo de 5
            $c = array_slice($c, 0, 5);

            foreach($c as $k => $d)
            {
                $nombProducion = $this->db->query("SELECT nombre FROM tm_area_prod WHERE id_areap = " . $d->id_areap)
                ->fetch(PDO::FETCH_OBJ);
                if($nombProducion){
                    $c[$k]->{'nombProducion'} = $nombProducion->nombre;
                }else{
                    $c[$k]->{'nombProducion'} = "--";
                }
                
            }

            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function producto_buscar_ins_combo($data)
    {
        try
        {   
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $cadena = $data['cadena'];
            $tipo = $data['tipo'];
            $consulta = "call sp_get_insprod(:idemp,:idsede,:id_tipo_ins,:id_ins,:cadena);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_tipo_ins' => '%',
                ':id_ins' => '%',
                ':cadena'=>'%'.$cadena.'%'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
            $st->closeCursor();

            // Filtrar por estados diferentes de 'c'
            $c = array_filter($c, function ($insprod) {
                return $insprod->est_b == 'a' && $insprod->est_c == 'a' && $insprod->id_tipo_ins !== '1';
            });

            // Limitar el número de respuestas a un máximo de 5
            $c = array_slice($c, 0, 5);

            foreach($c as $k => $d)
            {
                $nombProducion = $this->db->query("SELECT nombre FROM tm_area_prod WHERE id_areap = " . $d->id_areap)
                ->fetch(PDO::FETCH_OBJ);
                $c[$k]->{'nombProducion'} = $nombProducion->nombre;
            }

            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function producto_cat_crud_create($data)
    {
        try 
        {
            if( !empty( $_FILES['imagen']['name'] ) ){
                switch ($_FILES['imagen']['type']) 
                { 
                    case 'image/jpeg': 
                    $ext = "jpg"; 
                    break;
                    case 'image/gif': 
                    $ext = "gif"; 
                    break; 
                    case 'image/png': 
                    $ext = "png"; 
                    break;
                    case 'application/pdf':
                    $ext = "pdf";
                    break;
                }
                $imagen = date('ymdhis').'.'.$ext;
                move_uploaded_file ($_FILES['imagen']['tmp_name'], 'public/images/productos/'.$imagen);
            } else {
                $imagen = $data['imagen'];
            }
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 
            $consulta = "call usp_configProductoCatgs( :flag, @a, :descripcion, :delivery, :orden, :imagen, :estado, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 1,
                ':descripcion' => $data['descripcion_categoria'],
                ':delivery' => $data['hidden_delivery_categoria'],
                ':orden' => 100,
                ':imagen' => $imagen,
                ':estado' => $data['hidden_estado_categoria'],
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    public function producto_cat_crud_update($data)
    {
        try 
        {
            if( !empty( $_FILES['imagen']['name'] ) ){
                switch ($_FILES['imagen']['type']) 
                { 
                    case 'image/jpeg': 
                    $ext = "jpg"; 
                    break;
                    case 'image/gif': 
                    $ext = "gif"; 
                    break; 
                    case 'image/png': 
                    $ext = "png"; 
                    break;
                    case 'application/pdf':
                    $ext = "pdf";
                    break;
                }
                $imagen = date('ymdhis').'.'.$ext;
                move_uploaded_file ($_FILES['imagen']['tmp_name'], 'public/images/productos/'.$imagen);
            } else {
                $imagen = $data['imagen'];
            }
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 
            $consulta = "call usp_configProductoCatgs( :flag, :id_catg, :descripcion, :delivery, :orden, :imagen, :estado, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 2,
                ':id_catg' => $data['id_catg_categoria'],
                ':descripcion' => $data['descripcion_categoria'],
                ':delivery' => $data['hidden_delivery_categoria'],
                ':orden' => $data['orden_categoria'],
                ':imagen' => $imagen,
                ':estado' => $data['hidden_estado_categoria'],
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    public function producto_crud_create($data)
    {
        try
        {
            $idProd = 0;
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 
            $consulta = "call usp_configProducto( :flag, @a, :id_tipo, :id_catg, :id_areap, :nombre, :notas, :delivery, @b, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 1,
                ':id_tipo' => $data['id_tipo'],
                ':id_catg' => $data['id_catg'],
                ':id_areap' => $data['id_areap'],
                ':nombre' => $data['nombre'],
                ':notas' => $data['notas'],
                ':delivery' => $data['delivery'],
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                $idProd =  $row['id'];
            };

            return $idProd;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function topico_producto($data){
        try{
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 
            $res=1;
            $topic = $data['topic'];
            foreach ($topic as $x => $valor){
                $sql = "INSERT INTO tm_produc_topicos(id_producto,id_topicos,idemp,idsede) VALUES (?,?,?,?)";
                $this->db->prepare($sql)->execute(array($data['id'],$valor,$idemp,$idsede));
            }
            return $res;
        }catch(Exception $e){
            die($e->getMessage());
        }

    }
    public function producto_crud_update($data)
    {
        try 
        {

            $sql1 ="DELETE FROM tm_produc_topicos WHERE id_producto = ?";
            $resq = $this->db->prepare($sql1)->execute(array($data['id_prod']));
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 

            $consulta = "call usp_configProducto( :flag, :id_prod, :id_tipo, :id_catg, :id_areap, :nombre, :notas, :delivery, :estado, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 2,
                ':id_prod' => $data['id_prod'],
                ':id_tipo' => $data['id_tipo'],
                ':id_catg' => $data['id_catg'],
                ':id_areap' => $data['id_areap'],
                ':nombre' => $data['nombre'],
                ':notas' => $data['notas'],
                ':delivery' => $data['delivery'],
                ':estado' => $data['estado'],
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function producto_pres_crud_create($data)
    {
        try 
        {
            if( !empty( $_FILES['imagen']['name'] ) ){
                switch ($_FILES['imagen']['type']) 
                { 
                    case 'image/jpeg': 
                    $ext = "jpg"; 
                    break;
                    case 'image/gif': 
                    $ext = "gif"; 
                    break; 
                    case 'image/png': 
                    $ext = "png"; 
                    break;
                    case 'application/pdf':
                    $ext = "pdf";
                    break;
                }
                $imagen = date('ymdhis').'.'.$ext;
                move_uploaded_file ($_FILES['imagen']['tmp_name'], 'public/images/productos/'.$imagen);
            } else {
                $imagen = $data['imagen'];
            }
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $precio_delivery = 0.00;
            $stock_min_pre = 0;
            if($data['precio_delivery'] != ""){
                $precio_delivery =$data['precio_delivery'];
            }
            if($data['stock_min_presentacion'] != ""){
                $stock_min_pre =$data['stock_min_presentacion'];
            }
            $consulta = "call usp_configProductoPres( :flag, :id_pres, :id_prod, :cod_prod, :presentacion, :descripcion, :precio, :precio_delivery, :receta, :stock_min, :stock_limit, :impuesto, :delivery, :margen, :igv, :imagen, :estado, :idemp, :idsede, :crt_icbper);";
            $arrayParam =  array(
                ':flag' => 1,
                ':id_pres' => 50,
                ':id_prod' => $data['id_prod_presentacion'],
                ':cod_prod' => $data['cod_prod_presentacion'],
                ':presentacion' => $data['presentacion_presentacion'],
                ':descripcion' => $data['descripcion_presentacion'],
                ':precio' => $data['precio_presentacion'],
                ':precio_delivery' => $precio_delivery,
                ':receta' => $data['hidden_receta_presentacion'],
                ':stock_min' => $stock_min_pre,
                ':stock_limit' => $data['hidden_stock_limit'],
                ':impuesto' => $data['hidden_impuesto_presentacion'],
                ':delivery' => $data['hidden_delivery_presentacion'],
                ':margen' => $data['hidden_insumo_principal_presentacion'],
                ':igv' => Session::get('igv'),
                ':imagen' => $imagen,
                ':estado' => $data['hidden_estado_presentacion'],
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':crt_icbper' =>  $data['hidden_impuesto_icbper']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
            
        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    public function producto_pres_crud_update($data)
    {
        try 
        {
            if( !empty( $_FILES['imagen']['name'] ) ){
                switch ($_FILES['imagen']['type']) 
                { 
                    case 'image/jpeg': 
                    $ext = "jpg"; 
                    break;
                    case 'image/gif': 
                    $ext = "gif"; 
                    break; 
                    case 'image/png': 
                    $ext = "png"; 
                    break;
                    case 'application/pdf':
                    $ext = "pdf";
                    break;
                }
                $imagen = date('ymdhis').'.'.$ext;
                move_uploaded_file ($_FILES['imagen']['tmp_name'],'public/images/productos/'.$imagen);
            } else {
                $imagen = $data['imagen'];
            }
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $stock_min_pre = 0;
            if($data['stock_min_presentacion'] != ""){
                $stock_min_pre =$data['stock_min_presentacion'];
            }
            $consulta = "call usp_configProductoPres( :flag, :id_pres, :id_prod, :cod_prod, :presentacion, :descripcion, :precio, :precio_delivery, :receta, :stock_min,:stock_limit, :impuesto, :delivery, :margen, :igv, :imagen, :estado, :idemp, :idsede, :crt_icbper);";
            $arrayParam =  array(
                ':flag' => 2,
                ':id_pres' => $data['id_pres_presentacion'],
                ':id_prod' => $data['id_prod_presentacion'],
                ':cod_prod' => $data['cod_prod_presentacion'],
                ':presentacion' => $data['presentacion_presentacion'],
                ':descripcion' => $data['descripcion_presentacion'],
                ':precio' => $data['precio_presentacion'],
                ':precio_delivery' => $data['precio_delivery'],
                ':receta' => $data['hidden_receta_presentacion'],
                ':stock_min' => $stock_min_pre,
                ':stock_limit' => $data['hidden_stock_limit'],
                ':impuesto' => $data['hidden_impuesto_presentacion'],
                ':delivery' => $data['hidden_delivery_presentacion'],
                ':margen' => $data['hidden_insumo_principal_presentacion'],
                ':igv' => Session::get('igv'),
                ':imagen' => $imagen,
                ':estado' => $data['hidden_estado_presentacion'],
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':crt_icbper' =>  $data['hidden_impuesto_icbper']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    public function producto_combo_cat()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $stm = $this->db->prepare("SELECT * FROM tm_producto_catg WHERE id_catg <> 1 AND idemp = ?");
            $stm->execute(array($idemp));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function producto_combo_unimed($data)
    {
        try
        {   
            $stmm = $this->db->prepare("SELECT * FROM tm_tipo_medida WHERE grupo = ? OR grupo = ?");
            $stmm->execute(array($data['va1'],$data['va2']));
            $var = $stmm->fetchAll(PDO::FETCH_ASSOC);
            foreach($var as $v){
                echo '<option value="'.$v['id_med'].'">'.$v['descripcion'].'</option>';
            }
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }


    public function producto_ingrediente_create($data)
    {
        try 
        {    
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $resp = 1;      
            $consulta = "call usp_configProductoIngrs( :flag, @a, :id_pres, :id_tipo_ins, :id_ins, :id_med, :cant, :idemp, :idsede, :costo, :id_areap);";
            $arrayParam =  array(
                ':flag' => 1,
                ':id_pres' => $data['id_pres'],
                ':id_tipo_ins' => $data['id_tipo_ins'],
                ':id_ins' => $data['id_ins'],
                ':id_med' => $data['id_med'],
                ':cant' => $data['cant'],
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':costo' => $data['costo'],
                ':id_areap' => $data['id_areap']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);

            // Verifica si hubo algún error durante la ejecución del procedimiento almacenado
            if (!$st) {
                $resp = 0;
            }
            // La ejecución del procedimiento almacenado fue exitosa
            return $resp;
        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    /*
    public function producto_ingrediente_update($data)
    {
        try 
        {
            $consulta = "call usp_configProductoIngrs( :flag, :idPres, :idIns, :cant, :idPi);";
            $arrayParam =  array(
                ':flag' => 2,
                ':idPres' => 1,
                ':idIns' => 1,
                ':cant' => $data['cant'],
                ':idPi' => $data['cod'],
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
        }
        catch (Exception $e) 
        {
            return false;
        }
    }
    */

    public function producto_ingrediente_delete($data)
    {
        try 
        {
            $consulta = "call usp_configProductoIngrs( :flag, :id_pi, @a, @b, @c, @d, @e, @f, @g, @h,@i);";
            $arrayParam =  array(
                ':flag' => 3,
                ':id_pi' => $data['id_pi']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    public function producto_cat_delete($data)
    {
        try 
        {
            $consulta = "call usp_configEliminarCategoriaProd(:id_catg);";
            $arrayParam =  array(
                ':id_catg' => $data['id_catg']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }
    public function producto_prod_delete($data)
    {
        try 
        {
            $sqlConsulDelet = "DELETE FROM tm_produc_topicos WHERE id_producto = ?";
            $st1 = $this->db->prepare($sqlConsulDelet);
            $st1->execute(array($data['id_prod']));

            $consulta = "DELETE FROM tm_producto WHERE id_prod = ?;";
            $st = $this->db->prepare($consulta);
            $st->execute(array($data['id_prod']));
            $st->fetch(PDO::FETCH_ASSOC);
            if($st->rowCount()){
                return 1;
            }else{
                return 0;
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function producto_pres_delete($data)
    {
        try 
        {
            // DELETE FROM tm_producto_pres WHERE tm_producto_pres.id_pres = 2
            $consulta = "DELETE FROM tm_producto_pres WHERE id_pres = ?";
            $st = $this->db->prepare($consulta);
            $st->execute(array($data['id_pres']));
            $st->fetch(PDO::FETCH_ASSOC);
            if($st->rowCount()){
                return 1;
            }else{
                return 0;
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }
        /* ======================= FIN PRODUCTO */

    /* ======================= INCIO COMBO */
    public function combo_list()
    {
        try
        {
            $idemp=Session::get('idemp'); 
            $stm = $this->db->prepare("SELECT * FROM tm_producto WHERE id_prod like ? AND idemp = ? AND id_catg = 1 ORDER BY id_prod DESC");
            $stm->execute(array($_POST['id_prod'],$idemp));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    /* ======================= FIN COMBO */

    /* ======================= INICIO INSUMO */

    public function insumo_cat_list()
    {
        try
        {
            $idemp=Session::get('idemp');
            $stm = $this->db->prepare("SELECT * FROM tm_insumo_catg WHERE idemp = ?");
            $stm->execute(array($idemp));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function insumo_list()
    {
        try
        {
            $idemp=Session::get('idemp');
            $stm = $this->db->prepare("SELECT i.id_ins AS id_ins,
            i.id_catg AS id_catg,
            i.id_med AS id_med,
            m.grupo AS id_gru,
            i.cod_ins AS ins_cod,
            i.nomb_ins AS ins_nom,
            i.stock_min AS ins_sto,
            i.cos_uni AS ins_cos,
            i.estado AS ins_est,
            i.idemp AS idemp,
            ic.descripcion AS ins_cat,
            m.descripcion AS ins_med
        FROM tm_insumo i
            JOIN tm_insumo_catg ic ON i.id_catg = ic.id_catg
            JOIN tm_tipo_medida m ON i.id_med = m.id_med  WHERE i.id_ins like ? AND i.id_catg like ? AND i.idemp = ? ORDER BY i.id_ins DESC");
            $stm->execute(array($_POST['id_ins'],$_POST['id_catg'],$idemp));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function insumo_combo_cat()
    {
        try
        {
            $idemp=Session::get('idemp');
            $stm = $this->db->prepare("SELECT * FROM tm_insumo_catg WHERE idemp = ?");
            $stm->execute(array($idemp));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function insumo_cat_crud_create($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $consulta = "call usp_configInsumoCatgs( :flag, :descC, @a, :idemp);";
            $arrayParam =  array(
                ':flag' => 1,
                ':descC' => $data['descripcion'],
                ':idemp' => $idemp
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    public function insumo_cat_crud_update($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $consulta = "call usp_configInsumoCatgs( :flag, :descC, :idCatg, :idemp);";
            $arrayParam =  array(
                ':flag' => 2,
                ':descC' => $data['descripcion'],
                ':idCatg' => $data['id_catg'],
                ':idemp' => $idemp
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        }
        catch (Exception $e) 
        {
            return false;
        }
    }

    public function insumo_crud_create($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $consulta = "call usp_configInsumo( :flag, :idCatg, :idMed, :cod, :nombre, :stock, :costo, @a, @b, :idemp);";
            $arrayParam =  array(
                ':flag' => 1,
                ':idCatg' => $data['id_catg'],
                ':idMed' => $data['id_med'],
                ':cod' => $data['cod_ins'],
                ':nombre' => $data['nomb_ins'],
                ':stock' => $data['stock_min'],
                ':costo' => $data['cos_uni'],
                ':idemp' => $idemp
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function insumo_crud_update($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $consulta = "call usp_configInsumo( :flag, :idCatg, :idMed, :cod, :nombre, :stock, :costo, :estado, :idIns, :idemp);";
            $arrayParam =  array(
                ':flag' => 2,
                ':idCatg' => $data['id_catg'],
                ':idMed' => $data['id_med'],
                ':cod' => $data['cod_ins'],
                ':nombre' => $data['nomb_ins'],
                ':stock' => $data['stock_min'],
                ':costo' => $data['cos_uni'],
                ':estado' => $data['estado'],
                ':idIns' => $data['id_ins'],
                ':idemp' => $idemp
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function insumo_cat_delete($data)
    {
        try 
        {
            $consulta = "call usp_configEliminarCategoriaIns(:id_catg);";
            $arrayParam =  array(
                ':id_catg' => $data['id_catg']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function print_list($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $stm = $this->db->prepare("SELECT * FROM tm_impresora WHERE id_imp LIKE ? AND idemp = ? AND idsede = ?");
            $stm->execute(array($data['id_imp'],$idemp,$idsede));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Areapro'} = $this->db->query("SELECT nombre FROM tm_area_prod WHERE id_areap = ".$d->id_areap)
                    ->fetch(PDO::FETCH_OBJ);
            }
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 

        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    /*public function chk_comprobante_print_list($data)
    {
        try
        {
            $stm = $this->db->prepare("SELECT * FROM tm_impresora WHERE id_imp LIKE ? and comprov_vent='1'");
            $stm->execute(array($data['id_imp']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }*/

    public function chk_precuenta_print_list($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $stm = $this->db->prepare("SELECT * FROM tm_impresora WHERE id_imp LIKE ? and impr_caja='a' AND idemp = ? AND idsede = ?");
            $stm->execute(array($data['id_imp'],$idemp,$idsede));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function print_crud_create($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');

            $consulta = "call usp_configImpresoras( :flag, @a, :id_areap,:nombre, :estado, :impr_caja, :idemp , :idsede);";
            $arrayParam =  array(
                ':flag' => 1,
                ':id_areap' => $data['id_areap'],
                ':nombre' => $data['nombre'],
                ':estado' => $data['estado'],
                ':impr_caja' => $data['imprecaja'],
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function print_crud_update($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call usp_configImpresoras( :flag, :id_imp, :id_areap,:nombre, :estado, :impr_caja, :idemp , :idsede);";
            $arrayParam =  array(
                ':flag' => 2,
                ':id_imp' => $data['id_imp'],
                ':id_areap' => $data['id_areap'],
                ':nombre' => $data['nombre'],
                ':estado' => $data['estado'],
                ':impr_caja' => $data['imprecaja'],
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $row = $st->fetch(PDO::FETCH_ASSOC);
            $st->closeCursor();
            $var=$row['cod'];

            if($var == "3"){
                $sql = "UPDATE tm_impresora SET estado = 'i' WHERE id_imp = ?";
                $this->db->prepare($sql)->execute(array($data['id_imp']));
            }
            
            return $var;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    /* ======================= FIN INSUMO */

       /**INICIO TOPICOS */
    public function topicos_crud_create($data){

        try{
            $res = 0;
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $sql = "INSERT INTO tm_topicos SET nombre  = ?, precio  = ?, descripcion = ?, estado = ?, idemp = ?, idsede = ?";
            $resultado = $this->db->prepare($sql)->execute(array($data['nombre'],$data['precio'],$data['descripcion'],$data['estado'], $idemp, $idsede));

            if ($resultado){
                $res=1;
            }
            return $res;
        }catch(Exception $e){
            die($e->getMessage());
        }
    }

    public function topicos_crud_update($data){
        try{
            $res = 0;
            $idemp=Session::get('idemp');
            $sql = "UPDATE tm_topicos SET nombre  = ?, precio  = ?, descripcion = ?, estado = ? WHERE id_topicos = ? AND idemp = ?";
            $resultado = $this->db->prepare($sql)->execute(array($data['nombre'],$data['precio'],$data['descripcion'],$data['estado'],$data['id_topico'],$idemp));

            if ($resultado){
                $res=2;
            }
            return $res;
        }catch(Exception $e){
            die($e->getMessage());
        }

    }

    public function topicos_act(){
        try{
            $idemp=Session::get('idemp');
            return $this->db->selectAll('SELECT * FROM tm_topicos  WHERE idemp = '. $idemp .' AND estado = "a"');
        }catch(Exception $e){
            die($e->getMessage());
        }
    }

    public function topicos_list()
    {
        try
        {
            $idemp=Session::get('idemp');
            $stm = $this->db->prepare("SELECT * FROM tm_topicos WHERE id_topicos like ? AND idemp = ? ORDER BY id_topicos DESC");
            $stm->execute(array($_POST['id_topico'],$idemp));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
   
   
   
       /**FIN TOPICOS */



    /* FIN MODULO RESTAURANTE */

    public function optimizar_pedidos()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call usp_optPedidos(:flag,:idemp,:idsede);";
            $arrayParam =  array(
                ':flag' => 1,
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function optimizar_ventas()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call usp_optPedidos(:flag,:idemp,:idsede);";
            $arrayParam =  array(
                ':flag' => 2,
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function optimizar_productos()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call usp_optPedidos(:flag,:idemp,:idsede);";
            $arrayParam =  array(
                ':flag' => 3,
                ':idemp' => $idemp,
                ':idsede' => $idsede

            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function optimizar_insumos()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call usp_optPedidos(:flag,:idemp,:idsede);";
            $arrayParam =  array(
                ':flag' => 4,
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function optimizar_clientes()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call usp_optPedidos(:flag,:idemp,:idsede);";
            $arrayParam =  array(
                ':flag' => 5,
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function optimizar_proveedores()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call usp_optPedidos(:flag,:idemp,:idsede);";
            $arrayParam =  array(
                ':flag' => 6,
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function optimizar_mesas()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call usp_optPedidos(:flag,:idemp,:idsede);";
            $arrayParam =  array(
                ':flag' => 7,
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function optimizar_topicos()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call usp_optPedidos(:flag,:idemp,:idsede);";
            $arrayParam =  array(
                ':flag' => 8,
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                return $row['cod'];
            }
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function datosistema_data()
    {
        try
        {   
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $stm = $this->db->prepare("SELECT id_cfg,zona_hora,trib_acr,trib_car,di_acr,di_car,imp_acr,imp_val,mon_acr,mon_val,icbper FROM tm_configuracion WHERE idemp = ? AND principal =1;");
            $stm->execute(array($idemp));
            $c = $stm->fetch(PDO::FETCH_OBJ);

            $c->{'configsede'} = $this->db->query("SELECT id_cfg as idconfsede, pc_name, pc_ip, print_com, print_pre, print_cpe,opc_01,opc_02,opc_03,bloqueo,cod_seg,enlace_qr,msg_impre,img_promocion,print_com_2 FROM tm_configuracion WHERE idemp = $idemp AND idsede =$idsede;")
                    ->fetchAll(PDO::FETCH_OBJ);

            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function datosistema_crud($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $imagen=0;

            if( !empty( $_FILES['imagen']['name'] ) ){
                switch ($_FILES['imagen']['type']) 
                { 
                    case 'image/jpeg': 
                    $ext = "jpg"; 
                    break;
                    case 'image/gif': 
                    $ext = "gif"; 
                    break; 
                    case 'image/png': 
                    $ext = "png"; 
                    break;
                }
                //$imagen = 'logoprint.'.$ext;
                $imagen = date('ymdhis').'.'.$ext;
                move_uploaded_file ($_FILES['imagen']['tmp_name'], 'public/images/logosemp/'.$imagen);
                //$data['logo'] =  $imagen;
            } else {
                $imagen = $data['imagen'];
    
            }


            //update principal
            $sql = "UPDATE tm_configuracion SET zona_hora = ?,trib_acr = ?,trib_car = ?,di_acr = ?,di_car = ?,imp_acr = ?,imp_val = ?,mon_acr = ?,mon_val = ?,icbper=? WHERE idemp = ? AND principal =1;";
            $this->db->prepare($sql)->execute(array($data['zona_hora'],$data['trib_acr'],$data['trib_car'],$data['di_acr'],$data['di_car'],$data['imp_acr'],$data['imp_val'],$data['mon_acr'],$data['mon_val'],$data['imp_val_bol'],$idemp));
            
            //update de la configuracion sede, la opcion comentada es con la config categoriaa en comanda
            //$sql1 = "UPDATE tm_configuracion SET pc_name = ?,pc_ip = ?,print_com = ?,print_pre = ?,print_cpe = ?,cod_seg = ?, opc_01 = ?, enlace_qr = ?, msg_impre = ?, img_promocion = ?, print_com_catg = ? WHERE idemp = ? AND idsede = ?;";
            //$this->db->prepare($sql1)->execute(array($data['pc_name'],$data['pc_ip'],$data['print_com'],$data['print_pre'],$data['print_cpe'],$data['cod_seg'],$data['opc_01'],$data['enlace_qr'],$data['msg_impre'],$imagen,$data['print_com_catg'],$idemp,$idsede));

            $sql1 = "UPDATE tm_configuracion SET pc_name = ?,pc_ip = ?,print_com = ?,print_pre = ?,print_cpe = ?,cod_seg = ?, opc_01 = ?, enlace_qr = ?, msg_impre = ?, img_promocion = ?, print_com_2 = ? WHERE idemp = ? AND idsede = ?;";
            $this->db->prepare($sql1)->execute(array($data['pc_name'],$data['pc_ip'],$data['print_com'],$data['print_pre'],$data['print_cpe'],$data['cod_seg'],$data['opc_01'],$data['enlace_qr'],$data['msg_impre'],$imagen,$data['print_com_2'],$idemp,$idsede));
            /* ACTUALIZAR DATOS */
            Session::set('moneda', $data['mon_val']);
            Session::set('igv', $data['imp_val']/ 100);
            Session::set('tribAcr', $data['trib_acr']);
            Session::set('tribCar', $data['trib_car']);
            Session::set('diAcr', $data['di_acr']);
            Session::set('diCar', $data['di_car']);
            Session::set('impAcr', $data['imp_acr']);
            Session::set('monAcr', $data['mon_acr']);
            Session::set('zona_hor', $data['zona_hora']);
            Session::set('pc_name', $data['pc_name']);
            Session::set('pc_ip', $data['pc_ip']);
            Session::set('print_com', $data['print_com']);
            Session::set('print_pre', $data['print_pre']);
            Session::set('print_cpe', $data['print_cpe']); //funcion impresion directa 
            Session::set('cod_seg', $data['cod_seg']); //funcion codigo de seguridad 
            Session::set('opc_01', $data['opc_01']); //funcion codigo de seguridad
            Session::set('enlace_qr', $data['enlace_qr']);
            Session::set('msg_impre', $data['msg_impre']);
            Session::set('imp_icbper', $data['imp_val_bol']);
            Session::set('img_promocion', $imagen);
            //Session::set('print_com_catg',$data['print_com_catg']);
            Session::set('print_com_2',$data['print_com_2']);
            

        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function eliminar_imagen($data){
        try {
            $resp = 0;
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $default_img = "default.png";

            $sql1 = "UPDATE tm_configuracion SET img_promocion = ? WHERE idemp = ? AND idsede = ?;";
            $this->db->prepare($sql1)->execute(array($default_img,$idemp,$idsede));

            Session::set('img_promocion', $default_img);
            $nombreImagen = $data['nombre_imagen'];
            // Directorio donde se encuentra la imagen
            $directorioImagenes = 'public/images/logosemp/';

            // Ruta completa de la imagen a eliminar
            $rutaImagen = $directorioImagenes . $nombreImagen;

            // Verificar si el archivo existe antes de intentar eliminarlo
            if (file_exists($rutaImagen)) {
                // Intentar eliminar el archivo
                if (unlink($rutaImagen)) {
                    $resp = 1;
                } else {
                    $resp=2;
                }
            } else {
                $resp=0;
            }

            return $resp;
        }
        catch (Exception $e){
            die($e->getMessage());
        }
    }

    public function anularlogo()
    {
        try
        {    
            $stm = $this->db->prepare("UPDATE tm_empresa SET logo = NULL WHERE tm_empresa.id_de = 1");
            $stm->execute();
            // return $c;
            if($stm){
                return '1';
            }
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function bloqueoplataforma($data)
    {
        try
        {    
            $stm = $this->db->prepare("UPDATE tm_configuracion SET bloqueo = ? WHERE tm_configuracion.id_cfg = '1' ");
            $stm->execute(array($data['tipo_bloqueo']));
            // return $c;
            if($stm){
                // Session::set('moneda', $data['mon_val']);
                Session::set('bloqueo_id', $data['tipo_bloqueo']); 
                return '1';
            }
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    // bloqueoplataforma

    public function importarexcel()
    {   
        try {
            error_reporting(0);
            include "libs/class.upload.php";
            if(isset($_FILES["file"])){
                $up = new Upload($_FILES["file"]);
                if($up->uploaded){
                    $up->Process("libs/uploads/");
                    if($up->processed){
                        /// leer el archivo excel

                        $archivo = "libs/uploads/".$up->file_dst_name;

                        $objPHPExcel = IOFactory::load($archivo);
                        $totalHojas = $objPHPExcel->getSheetCount();
                        
                        $hojaActual = $objPHPExcel->getSheet(0);
                        $numeroFilas = $hojaActual->getHighestDataRow();
                        $letra = $hojaActual->getHighestColumn();
                        $idemp=Session::get('idemp');
                        $idsede=Session::get('sede_id');

                        for($indiceFila = 2; $indiceFila <= $numeroFilas; $indiceFila++){

                            $categoria      = $hojaActual->getCellByColumnAndRow(1, $indiceFila)->getValue();
                            $x_producto     = $hojaActual->getCellByColumnAndRow(2, $indiceFila)->getValue();
                            $x_cod_pro      = $hojaActual->getCellByColumnAndRow(3, $indiceFila)->getValue();
                            $x_area         = $hojaActual->getCellByColumnAndRow(4, $indiceFila)->getValue();
                            $x_trasformado  = $hojaActual->getCellByColumnAndRow(5, $indiceFila)->getValue();
                            $x_notas        = $hojaActual->getCellByColumnAndRow(6, $indiceFila)->getValue();
                            $x_desc         = $hojaActual->getCellByColumnAndRow(7, $indiceFila)->getValue();
                            $x_delivery     = $hojaActual->getCellByColumnAndRow(8, $indiceFila)->getValue();
            
                            if($categoria){
                                //$sql_categoria = $this->db->selectOne("SELECT * FROM tm_insumo_catg WHERE idemp = ".$idemp." AND descripcion LIKE '". $categoria ."' ");

                                $sql_categoria = $this->db->selectOne("SELECT * FROM tm_producto_catg WHERE idemp = ".$idemp." AND descripcion LIKE '". $categoria ."' ");
                                       
                                if ($sql_categoria) {
                                    $id_catg = $sql_categoria['id_catg'];
                                }
                                else{
                                    $insert_categoria   = "INSERT INTO tm_producto_catg SET descripcion = ?, idemp = ?, idsede = ?";
                                    $result_categoria   = $this->db->prepare($insert_categoria)->execute(array($categoria,$idemp,$idsede));
                                    $id_catg            = $this->db->lastInsertId(); // se obtiene el id 
                                }                                
                                    $sql_areapro = $this->db->selectOne("SELECT * FROM tm_area_prod WHERE idemp = ".$idemp." AND nombre LIKE '". $x_area ."' ");

                                if ($sql_areapro) {
                                    $id_areap = $sql_areapro['id_areap'];
                                }
                                else{
                                    $id_areap = "";

                                }
                                $x_trasformado = ($x_trasformado == 'si') ? '2': '1';
                                $x_delivery = ($x_delivery == 'SI') ? '1': '0';
                                
                                $sql_producto1 = $this->db->selectOne("SELECT * FROM tm_producto WHERE idemp=".$idemp." AND cod_pro LIKE '". $x_cod_pro ."' ");
                                if(!$sql_producto1){
                                    $insert_producto = "INSERT INTO tm_producto SET id_tipo = ? ,id_catg = ?, id_areap = ?, nombre = ?, notas = ?, descripcion = ?, delivery = ?, cod_pro  = ?, idemp = ?, idsede = ?";
                                    $result_producto = $this->db->prepare($insert_producto)->execute(array($x_trasformado, $id_catg, $id_areap, $x_producto, $x_notas, $x_desc, $x_delivery, $x_cod_pro, $idemp, $idsede)); 
                                }
                            }
            
                        }
                        // presentacion se activa
                        $result_presentacion = '0';
                        $hojaActual = $objPHPExcel->getSheet(1);
                        $numeroFilas = $hojaActual->getHighestDataRow();
                        $letra = $hojaActual->getHighestColumn();
                        for($indiceFila = 2; $indiceFila <= $numeroFilas; $indiceFila++){

                            $p_cod_producto     = $hojaActual->getCellByColumnAndRow(1, $indiceFila)->getValue();
                            $p_presentacion     = $hojaActual->getCellByColumnAndRow(2, $indiceFila)->getValue();
                            $p_cod_presentacion = $hojaActual->getCellByColumnAndRow(3, $indiceFila)->getValue();
                            $p_descripcion      = $hojaActual->getCellByColumnAndRow(4, $indiceFila)->getValue();
                            $p_precio           = $hojaActual->getCellByColumnAndRow(5, $indiceFila)->getValue();
                            $p_precio_delivery  = $hojaActual->getCellByColumnAndRow(6, $indiceFila)->getValue();
                            $p_stock_min        = $hojaActual->getCellByColumnAndRow(7, $indiceFila)->getValue();
                            $p_control_stock    = $hojaActual->getCellByColumnAndRow(8, $indiceFila)->getValue();
                            $p_igv              = $hojaActual->getCellByColumnAndRow(9, $indiceFila)->getValue();
                            $p_delivery         = $hojaActual->getCellByColumnAndRow(10, $indiceFila)->getValue();
                            // REMPLAZAR 
                            $p_control_stock    = (strtoupper($p_control_stock) == 'SI') ? '1': '0';
                            $p_igv              = (strtoupper($p_igv)   == 'SI') ? '1': '0';
                            $p_delivery         = (strtoupper($p_delivery) == 'SI') ? '1': '0';

                            $p_igv_monto        = Session::get('igv');

                            // extraer id producto
                            if($p_cod_presentacion != null){
                                $sql_producto = $this->db->selectOne("SELECT * FROM tm_producto WHERE idemp = ".$idemp." AND cod_pro LIKE '". $p_cod_producto ."' ");
                            
                                if ($sql_producto) {
                                    $id_p_producto = $sql_producto['id_prod'];
                                    $p_descripcion = (strlen($p_descripcion) >= 1)? $p_descripcion : '';
                                    $sql_presentacion = $this->db->selectOne("SELECT * FROM tm_producto_pres WHERE idemp = ".$idemp." AND cod_prod LIKE '". $p_cod_presentacion ."' ");
                                    if(!$sql_presentacion){
                                        $insert_presentacion = "INSERT INTO tm_producto_pres SET id_prod = ?,cod_prod = ?,presentacion = ?,descripcion = ?,precio = ?,precio_delivery = ?,receta = ?,stock_min = ?,crt_stock = ?,impuesto = ?,delivery = ?,margen = ?,igv = ?, idemp = ?, idsede = ?";
                                        $result_presentacion = $this->db->prepare($insert_presentacion)->execute(array($id_p_producto, $p_cod_presentacion, $p_presentacion, $p_descripcion, $p_precio, $p_precio_delivery, '0',$p_stock_min,$p_control_stock,$p_igv, $p_delivery,'0', $p_igv_monto, $idemp, $idsede)); 
                                    } 
                                }
                            }
                          
                        }
                        return ($result_presentacion != '0')? 1 : 0;


                    unlink($archivo);
                    }
            
                }
            }
            



        } 
        catch (Exception $e) 
        {
            die($e->getMessage());
        }

    }

    public function importarexcelinsumos()
    {   
        try {
            error_reporting(0);
            include "libs/class.upload.php";
            
            if(isset($_FILES["file"])){
                $up = new Upload($_FILES["file"]);
                if($up->uploaded){
                    $up->Process("libs/uploads/");
                    if($up->processed){
                        /// leer el archivo excel
                        // require_once "../libs/PHPExcel/Classes/PHPExcel.php";
                        //require_once "libs/PHPExcel/Classes/PHPExcel.php";
                        $archivo = "libs/uploads/".$up->file_dst_name;

                        $objPHPExcel = IOFactory::load($archivo);
                        $totalHojas = $objPHPExcel->getSheetCount();
                        
                        $hojaActual = $objPHPExcel->getSheet(0);
                        $numeroFilas = $hojaActual->getHighestDataRow();
                        $letra = $hojaActual->getHighestColumn();
                        $idemp=Session::get('idemp');
                        $idsede=Session::get('sede_id');
                        $estado = "a";
                        //$p_cod_producto     = $sheetpre->getCell("A".$row)->getValue();*/

                        for($indiceFila = 2; $indiceFila <= $numeroFilas; $indiceFila++){
                            $categoria      = $hojaActual->getCellByColumnAndRow(1, $indiceFila)->getValue();
                            $x_nombre       = $hojaActual->getCellByColumnAndRow(2, $indiceFila)->getValue();
                            $x_cod          = $hojaActual->getCellByColumnAndRow(3, $indiceFila)->getValue();
                            $x_medida       = $hojaActual->getCellByColumnAndRow(4, $indiceFila)->getValue();
                            $x_stock_min    = $hojaActual->getCellByColumnAndRow(5, $indiceFila)->getValue();
                            $x_costo_und    = $hojaActual->getCellByColumnAndRow(6, $indiceFila)->getValue();

                            if($categoria){
                                $sql_categoria = $this->db->selectOne("SELECT * FROM tm_insumo_catg WHERE idemp = ".$idemp." AND descripcion LIKE '". $categoria ."' ");
                                       
                                if ($sql_categoria) {
                                    $id_catg = $sql_categoria['id_catg'];
                                }
                                else{
                                    $insert_categoria   = "INSERT INTO tm_insumo_catg SET descripcion = ?, estado = ?, idemp = ?, idsede = ?";
                                    $result_categoria   = $this->db->prepare($insert_categoria)->execute(array($categoria,$estado,$idemp,$idsede));
                                    $id_catg            = $this->db->lastInsertId(); // se obtiene el id 
                                }                                
                                    $sql_medida = $this->db->selectOne("SELECT * FROM tm_tipo_medida WHERE descripcion LIKE '".$x_medida."' ");

                                if ($sql_medida) {
                                    $id_medida = $sql_medida['id_med'];
                                }
                                else{
                                    $id_medida = "";

                                }
                                
                                $sql_producto1 = $this->db->selectOne("SELECT * FROM tm_insumo WHERE idemp = ".$idemp." AND cod_ins LIKE '".$x_cod."'");
                                if(!$sql_producto1){
                                    $insert_producto = "INSERT INTO tm_insumo SET id_catg = ?, id_med = ?,cod_ins = ?, nomb_ins = ?, stock_min = ?, cos_uni = ?, idemp = ?, idsede = ?";
                                    $result_producto = $this->db->prepare($insert_producto)->execute(array($id_catg,$id_medida,$x_cod,$x_nombre,$x_stock_min,$x_costo_und,$idemp,$idsede)); 
                                }
                            }            
                        }
                        return ($result_producto)? '1' : '0';


                    unlink($archivo);
                    }	
            
                }
            }
            



        } 
        catch (Exception $e) 
        {
            die($e->getMessage());
        }

    }

}