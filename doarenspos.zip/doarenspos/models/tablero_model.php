<?php

class Tablero_Model extends Model {

	public function __construct() {
		parent::__construct();
	}

    public function Caja()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            
            $consulta = "call sp_get_caja_aper(:idemp,:idsede,:id_usu,:id_apc,:fecha_i,:fecha_f,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_usu' => '%',
                ':id_apc' =>  '%',
                ':fecha_i' => '%',
                ':fecha_f' => '%',
                ':estado' => 'a'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
            $st->closeCursor();

            // convertir el resultado en un array asociativo
            $data = array();
            foreach ($c as $row) {
                $data[] = get_object_vars($row);
            }

            return $data;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
	
	public function tablero_datos()
    {
        try
        {
            /*
            $ifecha = date('Y-m-d H:i:s',strtotime($_POST['ifecha']));
            $ffecha = date('Y-m-d H:i:s',strtotime($_POST['ffecha']));
            */
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');  
            $id_apc = $_POST['id_apc'];

            $sql_ventas = $this->db->prepare("SELECT  SUM(CASE WHEN tp.id_pago = 1 THEN tvp.cant_pago ELSE 0 END) AS pago_efe,
            SUM(CASE WHEN tp.id_pago <> 1 THEN tvp.cant_pago ELSE 0 END) AS pago_tar,
            SUM(v.descuento_monto) AS descuento,
            SUM(v.comision_tarjeta)  AS comis_tar,
            SUM(v.comision_delivery) AS comis_delivery,
            SUM(v.total) AS total FROM tm_venta v
            JOIN tm_venta_pago tvp ON v.id_venta = tvp.id_venta
            JOIN tm_tipo_pago tp ON tvp.id_tipo_pago = tp.id_tipo_pago  
            WHERE v.id_venta <> 0 AND v.id_apc = ? AND v.idemp = ? AND v.idsede = ? AND v.estado <> 'i'");
            $sql_ventas->execute(array($id_apc,$idemp,$idsede));
            $ventas= $sql_ventas->fetch(PDO::FETCH_OBJ); 

            $sql_egresos = $this->db->prepare("SELECT IFNULL(SUM(importe),0) AS total FROM tm_gastos_adm WHERE /*(fecha_re >= ? AND fecha_re < ?) AND*/ id_apc = ? AND estado = 'a'");
            $sql_egresos->execute(array(/*$ifecha,$ffecha,*/$id_apc));
            $egresos = $sql_egresos->fetch(PDO::FETCH_OBJ);

            $sql_ingresos = $this->db->prepare("SELECT IFNULL(SUM(importe),0) AS total FROM tm_ingresos_adm WHERE /*(fecha_reg >= ? AND fecha_reg < ?) AND */id_apc = ? AND estado = 'a'");
            $sql_ingresos->execute(array(/*$ifecha,$ffecha,*/$id_apc));
            $ingresos = $sql_ingresos->fetch(PDO::FETCH_OBJ);

            /*$sql_pollos_vendidos = $this->db->prepare("SELECT p.id_pres,p.pro_nom,p.pro_pre,dv.precio,SUM(dv.cantidad) AS cantidad, i.cant FROM tm_detalle_venta AS dv INNER JOIN tm_venta AS v ON dv.id_venta = v.id_venta INNER JOIN v_productos AS p ON dv.id_prod = p.id_pres INNER JOIN tm_producto_ingr AS i ON dv.id_prod = i.id_pres WHERE v.id_apc = ? AND i.id_ins = 1 AND p.pro_mar = 1 AND v.estado = 'a' GROUP BY dv.id_prod, dv.precio ORDER BY total DESC");
            $sql_pollos_vendidos->execute(array($id_apc));
            $pollos_vendidos = $sql_pollos_vendidos->fetchAll(PDO::FETCH_OBJ);*/
            //59 al 66

            /*$sql_pollos_stock = $this->db->prepare("SELECT (ent-sal) AS total FROM v_stock WHERE id_tipo_ins = 1 AND id_ins = 1 AND idemp = ? AND idsede = ?");
            $sql_pollos_stock->execute(array($idemp,$idsede));
            $pollos_stock = $sql_pollos_stock->fetch(PDO::FETCH_OBJ);*/
            //MODIFICAR ///////////////////////////////////////////////////// TODOS LOS PLATOS MAS VENDIDOS
            $sql_platos = $this->db->prepare("SELECT p.nombre AS pro_nom,pp.presentacion AS pro_pre,dv.precio,SUM(dv.cantidad) AS cantidad,COUNT(dv.id_venta) AS total,SUM(dv.costo * dv.cantidad) AS costo_prod_venta,pp.receta  FROM tm_detalle_venta AS dv INNER JOIN tm_venta AS v ON dv.id_venta = v.id_venta INNER JOIN tm_producto_pres AS pp ON dv.id_prod = pp.id_pres INNER JOIN tm_producto AS p ON pp.id_prod = p.id_prod WHERE p.id_tipo = 1 AND v.estado = 'a' AND v.id_apc = ? GROUP BY dv.id_prod, dv.precio ORDER BY total DESC LIMIT 10");
            $sql_platos->execute(array(/*$ifecha,$ffecha,*/$id_apc));
            $platos = $sql_platos->fetchAll(PDO::FETCH_OBJ);

            $sql_productos = $this->db->prepare("SELECT p.nombre AS pro_nom,pp.presentacion AS pro_pre,dv.precio,SUM(dv.cantidad) AS cantidad,COUNT(dv.id_venta) AS total,SUM(dv.costo * dv.cantidad) AS costo_prod_venta,pp.receta FROM tm_detalle_venta AS dv INNER JOIN tm_venta AS v ON dv.id_venta = v.id_venta INNER JOIN tm_producto_pres AS pp ON dv.id_prod = pp.id_pres INNER JOIN tm_producto AS p ON pp.id_prod = p.id_prod  WHERE p.id_tipo = 2 AND v.estado = 'a' AND v.id_apc = ? GROUP BY dv.id_prod, dv.precio ORDER BY total DESC LIMIT 10");
            $sql_productos->execute(array(/*$ifecha,$ffecha,*/$id_apc));
            $productos = $sql_productos->fetchAll(PDO::FETCH_OBJ);
            ////////////////////////////////////////////////////////////////////////////
            $sql_canal_salon = $this->db->prepare("SELECT COUNT(DISTINCT v.id_venta) AS cantidad_ventas, SUM(tvp.cant_pago) AS total_ventas FROM tm_venta AS v JOIN tm_venta_pago tvp ON v.id_venta = tvp.id_venta JOIN tm_tipo_pago tp ON tvp.id_tipo_pago = tp.id_tipo_pago WHERE  v.id_venta <> 0 AND v.id_tipo_pedido = 1 AND v.estado = 'a' AND v.id_apc = ?");
            $sql_canal_salon->execute(array(/*$ifecha,$ffecha,*/$id_apc));
            $canal_salon = $sql_canal_salon->fetch(PDO::FETCH_OBJ);

            $sql_canal_mostrador = $this->db->prepare("SELECT COUNT(DISTINCT v.id_venta) AS cantidad_ventas, SUM(tvp.cant_pago) AS total_ventas FROM tm_venta AS v JOIN tm_venta_pago tvp ON v.id_venta = tvp.id_venta JOIN tm_tipo_pago tp ON tvp.id_tipo_pago = tp.id_tipo_pago WHERE v.id_venta <> 0 AND v.id_tipo_pedido = 2 AND v.estado = 'a' AND v.id_apc = ?");
            $sql_canal_mostrador->execute(array(/*$ifecha,$ffecha,*/$id_apc));
            $canal_mostrador = $sql_canal_mostrador->fetch(PDO::FETCH_OBJ);

            $sql_canal_delivery = $this->db->prepare("SELECT COUNT(DISTINCT v.id_venta) AS cantidad_ventas, SUM(tvp.cant_pago) AS total_ventas FROM tm_venta AS v JOIN tm_venta_pago tvp ON v.id_venta = tvp.id_venta JOIN tm_tipo_pago tp ON tvp.id_tipo_pago = tp.id_tipo_pago WHERE v.id_venta <> 0 AND v.id_tipo_pedido = 3 AND v.estado = 'a' AND v.id_apc = ?");
            $sql_canal_delivery->execute(array(/*$ifecha,$ffecha,*/$id_apc));
            $canal_delivery = $sql_canal_delivery->fetch(PDO::FETCH_OBJ);

            $sql_canal_salon_i = $this->db->prepare("SELECT COUNT(DISTINCT v.id_venta) AS cantidad_ventas, SUM(tvp.cant_pago) AS total_ventas FROM tm_venta AS v JOIN tm_venta_pago tvp ON v.id_venta = tvp.id_venta JOIN tm_tipo_pago tp ON tvp.id_tipo_pago = tp.id_tipo_pago WHERE v.id_venta <> 0 AND v.id_tipo_pedido = 1 AND v.estado = 'i' AND v.id_apc = ?");
            $sql_canal_salon_i->execute(array(/*$ifecha,$ffecha,*/$id_apc));
            $canal_salon_i = $sql_canal_salon_i->fetch(PDO::FETCH_OBJ);

            $sql_canal_mostrador_i = $this->db->prepare("SELECT COUNT(DISTINCT v.id_venta) AS cantidad_ventas, SUM(tvp.cant_pago) AS total_ventas FROM tm_venta AS v JOIN tm_venta_pago tvp ON v.id_venta = tvp.id_venta JOIN tm_tipo_pago tp ON tvp.id_tipo_pago = tp.id_tipo_pago WHERE v.id_venta <> 0 AND v.id_tipo_pedido = 2 AND v.estado = 'i' AND v.id_apc = ?");
            $sql_canal_mostrador_i->execute(array(/*$ifecha,$ffecha,*/$id_apc));
            $canal_mostrador_i = $sql_canal_mostrador_i->fetch(PDO::FETCH_OBJ);

            $sql_canal_delivery_i = $this->db->prepare("SELECT COUNT(DISTINCT v.id_venta) AS cantidad_ventas, SUM(tvp.cant_pago) AS total_ventas FROM tm_venta AS v JOIN tm_venta_pago tvp ON v.id_venta = tvp.id_venta JOIN tm_tipo_pago tp ON tvp.id_tipo_pago = tp.id_tipo_pago WHERE v.id_venta <> 0 AND v.id_tipo_pedido = 3 AND v.estado = 'i' AND v.id_apc = ?");
            $sql_canal_delivery_i->execute(array(/*$ifecha,$ffecha,*/$id_apc));
            $canal_delivery_i = $sql_canal_delivery_i->fetch(PDO::FETCH_OBJ);

            /*
            $mozo = $this->db->prepare("SELECT IFNULL(COUNT(dp.id_pedido),0) AS tped,u.nombres,u.ape_paterno,u.ape_materno FROM tm_detalle_pedido AS dp INNER JOIN tm_pedido_mesa AS pm ON dp.id_pedido = pm.id_pedido INNER JOIN tm_pedido AS p ON dp.id_pedido = p.id_pedido INNER JOIN tm_usuario AS u ON pm.id_mozo = u.id_usu WHERE dp.estado <> 'i' AND p.estado = 'c' AND (p.fecha_pedido >= ? AND p.fecha_pedido < ?) GROUP BY pm.id_mozo ORDER BY tped DESC LIMIT 1");
            $mozo->execute(array($ifecha,$ffecha));
            $m = $mozo->fetch(PDO::FETCH_OBJ);

            $t_ped = $this->db->prepare("SELECT IFNULL(COUNT(dp.id_pedido),0) AS toped FROM tm_detalle_pedido AS dp INNER JOIN tm_pedido AS p ON dp.id_pedido = p.id_pedido WHERE dp.estado <> 'i' AND p.estado = 'c' AND (p.fecha_pedido >= ? AND p.fecha_pedido < ?)");
            $t_ped->execute(array($ifecha,$ffecha));
            $tp = $t_ped->fetch(PDO::FETCH_OBJ);

            $mesas = $this->db->prepare("SELECT IFNULL(COUNT(pm.id_pedido),0) AS total FROM tm_pedido_mesa AS pm INNER JOIN tm_pedido as p ON pm.id_pedido = p.id_pedido WHERE p.estado = 'c' AND (p.fecha_pedido >= ? AND p.fecha_pedido < ?)");
            $mesas->execute(array($ifecha,$ffecha));
            $me = $mesas->fetch(PDO::FETCH_OBJ);

            $v_mesa = $this->db->prepare("SELECT IFNULL(SUM(v.total - v.descu),0) AS total_v FROM v_ventas_con AS v INNER JOIN tm_pedido_mesa AS pm ON v.id_ped = pm.id_pedido WHERE (v.fec_ven >= ? AND v.fec_ven < ?)");
            $v_mesa->execute(array($ifecha,$ffecha));
            $vm = $v_mesa->fetch(PDO::FETCH_OBJ);

            $v_mos = $this->db->prepare("SELECT IFNULL(SUM(v.total - v.descu),0) AS total_v FROM v_ventas_con AS v INNER JOIN tm_pedido_llevar AS pm ON v.id_ped = pm.id_pedido WHERE (v.fec_ven >= ? AND v.fec_ven < ?)");
            $v_mos->execute(array($ifecha,$ffecha));
            $vmo = $v_mos->fetch(PDO::FETCH_OBJ);

            $mostrador = $this->db->prepare("SELECT IFNULL(COUNT(pm.id_pedido),0) AS total FROM tm_pedido_llevar AS pm INNER JOIN tm_pedido as p ON pm.id_pedido = p.id_pedido WHERE p.estado = 'c' AND (p.fecha_pedido >= ? AND p.fecha_pedido < ?)");
            $mostrador->execute(array($ifecha,$ffecha));
            $mo = $mostrador->fetch(PDO::FETCH_OBJ);


            $mesa_a = $this->db->prepare("SELECT COUNT(id_pedido) as total FROM tm_pedido WHERE (fecha_pedido >= ? AND fecha_pedido < ?) AND id_tipo_pedido = 1 AND estado ='i'");
            $mesa_a->execute(array($ifecha,$ffecha));
            $ma = $mesa_a->fetch(PDO::FETCH_OBJ);

            $mos_a = $this->db->prepare("SELECT COUNT(id_pedido) as total FROM tm_pedido WHERE (fecha_pedido >= ? AND fecha_pedido < ?) AND id_tipo_pedido = 2 AND estado ='i'");
            $mos_a->execute(array($ifecha,$ffecha));
            $moa = $mos_a->fetch(PDO::FETCH_OBJ);
            */

            $data = array("Ventas" => $ventas,"Egresos" => $egresos,"Ingresos" => $ingresos,"Platos" => $platos,"Productos" => $productos, /*"Pollostock" => $pollos_stock, "Pollosvendidos" => $pollos_vendidos,*/ "CanalSalon" => $canal_salon, "CanalMostrador" => $canal_mostrador, "CanalDelivery" => $canal_delivery, "CanalSalonAnulados" => $canal_salon_i, "CanalMostradorAnulados" => $canal_mostrador_i,"CanalDeliveryAnulados" => $canal_delivery_i/*"data3" => $m,"data4" => $tp,"data5" => $me,"data6" => $vm,"data7" => $vmo,"data8" => $mo,*//*,"data11" => $ma,"data12" => $moa*/);
            $json = json_encode($data);
            echo $json;  

        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
}