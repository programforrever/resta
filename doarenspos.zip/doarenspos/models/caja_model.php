<?php Session::init(); ?>
<?php

class Caja_Model extends Model
{
	public function __construct()
	{
		parent::__construct();
	}

    public function Caja()
    {
        try
        {   
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');   
            return $this->db->selectAll('SELECT * FROM tm_caja WHERE estado = "a" AND idemp = ' . $idemp . ' AND idsede =' . $idsede);
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    
    public function Turno()
    {
        try
        {      
            return $this->db->selectAll("SELECT * FROM tm_turno");
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function UsuCajero(){
        try{
            $idemp=Session::get('idemp');
            return $this->db->selectAll("SELECT id_usu,CONCAT(ape_paterno,' ',ape_materno,' ',nombres) AS nombres FROM tm_usuario WHERE (id_rol = 1 OR id_rol = 2 OR id_rol = 3) AND idEmpresa=" . $idemp);
        }catch(Exception $e){
            die($e->getMessage());
        }
    }
 
    public function Personal()
    {
        try
        {
            $idemp = Session::get('idemp');
            $idsede = Session::get('sede_id');      
            return $this->db->selectAll('SELECT * FROM tm_usuario WHERE id_usu <> 1 AND estado = "a" AND idEmpresa = '. $idemp);
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Tipo_gasto()
    {
        try
        {    
            return $this->db->selectAll('SELECT * FROM tm_tipo_gasto');
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Formapago()
    {
        try
        {
            return $this->db->selectAll('SELECT * FROM tm_tipo_pago WHERE id_tipo_pago IN(1,2,3) AND estado = "a" ORDER BY id_tipo_pago ASC LIMIT 3');
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function GetAllTipoPago(){
        $idemp=Session::get('idemp');

        return $this->db->selectAll('SELECT * FROM (SELECT * FROM tm_tipo_pago WHERE id_tipo_pago IN(1,2) AND estado = "a" ORDER BY id_tipo_pago ASC LIMIT 2) T1
            UNION SELECT * FROM (SELECT * FROM tm_tipo_pago WHERE idemp = '. $idemp .' AND estado = "a" ) T2;');

    }

    public function TipoPago()
    {
        try
        {   
            $idemp=Session::get('idemp');

            return $this->db->selectAll('SELECT * FROM (SELECT * FROM tm_tipo_pago WHERE estado = "a" ORDER BY id_tipo_pago ASC LIMIT 3) T1
            UNION SELECT * FROM (SELECT * FROM tm_tipo_pago WHERE idemp = '. $idemp .' AND estado = "a") T2;');
           
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    public function TipoPedido()
    {
        try
        {      
            return $this->db->selectAll('SELECT * FROM tm_tipo_pedido');
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    public function TipoDocumento()
    {
        try
        {   
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            return $this->db->selectAll('SELECT ts.id_tipo_doc,td.descripcion FROM tm_tipo_doc as td
            inner join tm_series as ts on td.id_tipo_doc = ts.id_tipo_doc 
            WHERE ts.estado = "a" AND ts.idemp =' . $idemp .'  AND ts.idsede = '. $idsede);
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    /* INICIO MODULO APERTURA Y CIERRE */
    public function apercie_list()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call sp_get_caja_aper(:idemp,:idsede,:id_usu,:id_apc,:fecha_i,:fecha_f,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_usu' => Session::get('usuid'),
                ':id_apc' => '%',
                ':fecha_i' => '%',
                ':fecha_f' => '%',
                ':estado' => 'a'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetch(PDO::FETCH_OBJ);

            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function apercie_montosist($data)
    {
        try
        {
            $stm = $this->db->prepare("SELECT SUM(CASE WHEN tp.id_pago = 1 THEN tvp.cant_pago ELSE 0 END) AS pago_efe,
            SUM(CASE WHEN tp.id_pago <> 1 THEN tvp.cant_pago ELSE 0 END) AS pago_tar,
            SUM(v.descuento_monto) AS desc_monto,
            SUM(tvp.cant_pago) AS total
            FROM tm_venta v
        JOIN tm_venta_pago tvp ON v.id_venta = tvp.id_venta
        JOIN tm_tipo_pago tp ON tvp.id_tipo_pago = tp.id_tipo_pago
        WHERE v.id_venta <> 0 AND v.id_apc = ? AND v.estado <> 'i' GROUP BY v.id_apc");
            $stm->execute(array($data['id_apc']));
            $c = $stm->fetch(PDO::FETCH_OBJ);
            if($c != false){
                $c->{'Apertura'} = $this->db->query("SELECT monto_aper FROM tm_aper_cierre WHERE id_apc = ".$data['id_apc'])
                ->fetch(PDO::FETCH_OBJ);
                $c->{'Ingresos'} = $this->db->query("SELECT IFNULL(SUM(importe),0) AS total FROM tm_ingresos_adm WHERE id_apc = {$data['id_apc']} AND estado='a'")
                ->fetch(PDO::FETCH_OBJ);
                $c->{'EgresosA'} = $this->db->query("SELECT IFNULL(SUM(importe),0) AS total FROM tm_gastos_adm WHERE id_apc = {$data['id_apc']} AND (id_tipo_gasto = 1 OR id_tipo_gasto = 2 OR id_tipo_gasto = 3) AND estado='a'")
                ->fetch(PDO::FETCH_OBJ);
                $c->{'EgresosB'} = $this->db->query("SELECT IFNULL(SUM(importe),0) AS total FROM tm_gastos_adm WHERE id_apc = {$data['id_apc']} AND id_tipo_gasto = 4 AND estado='a'")
                ->fetch(PDO::FETCH_OBJ);
            }else{
                $c["total"] = "";
            }

            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    /*public function stock_pollo()
    {
        try
        {
            $idemp = Session::get('idemp');
            $idsede = Session::get('sede_id');
            $st = $this->db->prepare("SELECT (ent-sal) AS total FROM v_stock WHERE id_tipo_ins = 1 AND id_ins = 1 AND idemp = ? AND idsede = ?;");
            $st->execute(array($idemp,$idsede));
            $row = $st->fetch(PDO::FETCH_OBJ);
            return $row;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }*/

    public function aperturar_caja($data)
    {
        try
        {
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");
            $idTurno = 1;
            $idemp = Session::get('idemp');
            $idsede = Session::get('sede_id');
            $row; 

            if(Session::get('usuid')==1){
                $consulta = "call usp_cajaAperturar( :flag, :id_usu, :id_caja, :id_turno, :fecha_aper, :monto_aper, :idemp, :idsede);";
                $arrayParam =  array(
                    ':flag' => 1,
                    ':id_usu' => $data['id_cajaUsu'],
                    ':id_caja' => $data['id_caja'],
                    ':id_turno' => $idTurno,
                    ':fecha_aper' =>  $fecha,
                    ':monto_aper' => $data['monto_aper'],
                    ':idemp' => $idemp,
                    ':idsede' => $idsede
                );
                $st = $this->db->prepare($consulta);
                $st->execute($arrayParam);
                $row = $st->fetch(PDO::FETCH_ASSOC);
            }else{
                $consulta = "call usp_cajaAperturar( :flag, :id_usu, :id_caja, :id_turno, :fecha_aper, :monto_aper, :idemp, :idsede);";
                $arrayParam =  array(
                    ':flag' => 1,
                    ':id_usu' => Session::get('usuid'),
                    ':id_caja' => $data['id_caja'],
                    ':id_turno' => $idTurno,
                    ':fecha_aper' => $fecha,
                    ':monto_aper' => $data['monto_aper'],
                    ':idemp' => $idemp,
                    ':idsede' => $idsede
                );
                $st = $this->db->prepare($consulta);
                $st->execute($arrayParam);
                $row = $st->fetch(PDO::FETCH_ASSOC);
            }
          
            return $row;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function UpdateAperCaja()
    {
        try
        {
            $retun = 0;   
            $idusu = Session::get('usuid');
			$idemp=Session::get('idemp');
			$idsede=Session::get('sede_id');
            $consulta = "call sp_get_caja_aper(:idemp,:idsede,:id_usu,:id_apc,:fecha_i,:fecha_f,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_usu' => $idusu,
                ':id_apc' => '%',
                ':fecha_i' => '%',
                ':fecha_f' => '%',
                ':estado' => 'a'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $data_a = $st->fetch(PDO::FETCH_OBJ);
            $count_a =  $st->rowCount();

			if ($count_a > 0) {
				Session::set('aperturaIn', true);
				Session::set('apcid', $data_a->id_apc);
				Session::set('namecaja', $data_a->desc_caja);
                $retun = 1;
			} else {
				Session::set('aperturaIn', false);
			}
            return $retun;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function cerrar_caja($data)
    {
        try
        {
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");

            $idemp = Session::get('idemp');
            $idsede = Session::get('sede_id');
            $consulta = "call usp_cajaCerrar( :flag, :id_apc, :fecha_cierre, :monto_cierre, :monto_sistema, :stock_pollo, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 1,
                ':id_apc' => $data['id_apc'],
                ':fecha_cierre' => $fecha,
                ':monto_cierre' => $data['monto_cierre'],
                ':monto_sistema' => $data['monto_sistema'],
                ':stock_pollo' => $data['stock_pollo'],
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $row = $st->fetch(PDO::FETCH_ASSOC);
            return $row;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }
    /* FIN MODULO APERTURA Y CIERRE */

    /* INICIO MODULO INGRESO */
    public function ingreso_list($data)
    {
        try
        {   
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d");
            $id_usu = Session::get('usuid');
            $idemp = Session::get('idemp');
            $idsede = Session::get('sede_id');
            $stm = $this->db->prepare("SELECT * FROM tm_ingresos_adm WHERE id_usu = ? AND estado like ? AND idemp = ? AND idsede = ?");
            $stm->execute(array($id_usu,$data['estado'],$idemp,$idsede));            
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function ingreso_crud_create($data)
    {
        try
        {
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");
            $id_usu = Session::get('usuid');
            $id_apc = Session::get('apcid');
            $idemp = Session::get('idemp');
            $idsede = Session::get('sede_id');
            $sql = "INSERT INTO tm_ingresos_adm(id_usu,id_apc,importe,responsable,motivo,fecha_reg,idemp,idsede) VALUES (?,?,?,?,?,?,?,?)";
            $this->db->prepare($sql)->execute(array($id_usu,$id_apc,$data['importe'],$data['responsable'],$data['motivo'],$fecha,$idemp,$idsede));
            $this->db=null; 
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function ingreso_estado($data)
    {
        try 
        {
            $sql = "UPDATE tm_ingresos_adm SET estado = 'i' WHERE id_ing = ?";
            $this->db->prepare($sql)->execute(array($data['id_ing']));
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    /* FIN MODULO INGRESO */


    /* INICIO MODULO EGRESO */
    public function egreso_list($data)
    {
        try
        {
            $idemp = Session::get('idemp');
            $idsede = Session::get('sede_id');   
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d");
            $id_usu = Session::get('usuid');
            $consulta = "call sp_get_gastosadm(:idemp,:idsede,:id_usu,:id_per,:id_tg,:estado,:idapc,:fechai,:fechaf);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_usu' => $id_usu,
                ':id_per' => '%',
                ':id_tg' => $data['tipo_gasto'],
                ':estado' => $data['estado'],
                ':idapc' => '%',
                ':fechai' => '%',
                ':fechaf' => '%'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);

            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function egreso_crud_create($data)
    {
        try
        {
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha = date("Y-m-d H:i:s");
            $id_usu = Session::get('usuid');
            $id_apc = Session::get('apcid');
            $idemp = Session::get('idemp');
            $idsede = Session::get('sede_id');
            $estado="a";
            $id_per=0;
            if($data['id_per'] != ""){
                $id_per=$data['id_per'];
            }

            $sql = "INSERT INTO tm_gastos_adm(id_tipo_gasto,id_usu,id_apc,id_per,importe,responsable,motivo,fecha_registro,estado,idemp,idsede) VALUES (?,?,?,?,?,?,?,?,?,?,?)";            
            $this->db->prepare($sql)->execute(array($data['id_tipo_gasto'],$id_usu,$id_apc,$id_per,$data['importe'],$data['responsable'],$data['motivo'],$fecha,$estado,$idemp,$idsede));
            $this->db=null; 
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function egreso_estado($data)
    {
        try 
        {
            $sql = "UPDATE tm_gastos_adm SET estado = 'i' WHERE id_ga = ?";
            $this->db->prepare($sql)->execute(array($data['id_ga']));
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    /* FIN MODULO EGRESO */

    /* INICIO MODULO MONITOR DE VENTAS */

    /*public function monitor_list()
    {
        try
        {
            $stm = $this->db->prepare("SELECT * FROM v_caja_aper WHERE estado <> 'c'");
            $stm->execute();
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }*/

    public function monitor_ventas_list()
    {
        try
        {
            if(Session::get('rol') == 3){
                $ifecha = date('Y-m-d H:i:s',strtotime($_POST['ifecha_rol_caj']));
                $ffecha = date('Y-m-d H:i:s',strtotime($_POST['ffecha_rol_caj']));
            }else{
                $ifecha = date('Y-m-d H:i:s',strtotime($_POST['ifecha']));
                $ffecha = date('Y-m-d H:i:s',strtotime($_POST['ffecha']));
            }



            $id_tped = $_POST['tped'];
            $id_tdoc = $_POST['tdoc'];
            $idCajero = $_POST['idcajero'];
            $id_fpag = $_POST['id_fpag'];
            $id_tpag = $_POST['id_tpag'];

            if(Session::get('rol') == 1 OR Session::get('rol') == 2){
                $consulta = "";
            }else{
                // $consulta = " WHERE id_apc = ".Session::get('apcid');

                $consulta = "";
                $idCajero = Session::get('usuid');
            }
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 
            $consulta2 = "call sp_get_ventas_con(:idemp,:idsede,:fecha_i,:fecha_f,:id_vent,:id_cli);";
            $arrayParam2 =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':fecha_i' => $ifecha,
                ':fecha_f' => $ffecha,
                ':id_vent' => '%',
                ':id_cli' => '%'
            );
            $stm = $this->db->prepare($consulta2);
            $stm->execute($arrayParam2);
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $stm->closeCursor();

            //Reindexar el array  filtrar por canal de venta, por tipo documento, por tipo pago, por cajero

            $c = array_values(array_filter($c, function ($vent_con) use ($id_tped,$id_tdoc,$id_fpag,$idCajero)  {
                $condicion1 = $id_tped == "%" || $vent_con->id_tped == $id_tped;
                $condicion2 = $id_tdoc == "%" || $vent_con->id_tdoc == $id_tdoc;
                $condicion3 = $id_fpag == "%" || $vent_con->id_fpag == $id_fpag;
                $condicion4 = $idCajero == "%" || $vent_con->id_usu == $idCajero;
                return $condicion1 && $condicion2 && $condicion3 && $condicion4;
            }));
            
            foreach($c as $k => $d)
            {
                
                if($d->estado == "a"){
                    $c[$k]->{'monto_total'} = number_format( $d->pago_efe + $d->pago_tar, 2, '.', '');
                }else{
                    $c[$k]->{'monto_total'} = number_format(0, 2, '.', '');
                }
                
                $c[$k]->{'Pedido'} = $this->db->query("SELECT cm.descripcion AS desc_salon, m.nro_mesa FROM tm_pedido_mesa AS tpm JOIN tm_mesa AS m ON tpm.id_mesa = m.id_mesa JOIN tm_salon AS cm ON m.id_salon = cm.id_salon WHERE m.id_mesa <> 0 AND cm.estado <> 'i' AND tpm.id_pedido = ".$d->id_ped)
                    ->fetch(PDO::FETCH_OBJ);
            
                $c[$k]->{'Cliente'} = $this->db->query("SELECT id_cliente,
                CASE
                    WHEN tipo_cliente = 1 THEN nombres
                    WHEN tipo_cliente = 2 THEN razon_social
                END AS nombrecliente FROM tm_cliente  WHERE id_cliente = ".$d->id_cli)
                    ->fetch(PDO::FETCH_OBJ);

                $c[$k]->{'FormaPago'} = $this->db->query("SELECT descripcion AS nombre,id_pago FROM tm_tipo_pago WHERE id_tipo_pago in (1,2,3) AND id_pago =" .$d->id_fpag)
                    ->fetch(PDO::FETCH_OBJ);
                    //trae todos los tipos de pago
                $c[$k]->{'Tipopago'} = $this->db->query("SELECT descripcion AS nombre,tvp.cant_pago FROM tm_venta_pago as tvp join tm_tipo_pago as ttp on tvp.id_tipo_pago = ttp.id_tipo_pago WHERE tvp.id_venta = " . $d->id_ven." AND tvp.id_tipo_pago LIKE '".$id_tpag."'")
                    ->fetchAll(PDO::FETCH_OBJ);

                $c[$k]->{'Cajero'} = $this->db->query("SELECT CONCAT(ape_paterno,' ',nombres) as nombres FROM tm_usuario WHERE id_usu = " . $d->id_usu)
                    ->fetch(PDO::FETCH_OBJ);
            }

            $nuevoArray = array_values(array_filter($c, function ($elemento) {
                return is_object($elemento) && property_exists($elemento, 'Tipopago') && is_array($elemento->Tipopago) && count($elemento->Tipopago) > 0;
            }));

            $data = array("data" => $nuevoArray);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function monitor_mesas_list()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call sp_pedido_mesa(:idemp,:idsede,:id_pedido,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_pedido' => '%',
                ':estado' => 'a'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
            $st->closeCursor();

            foreach($c as $k => $d)
            {
                $c[$k]->{'Total'} = $this->db->query("SELECT SUM((precio*cant)+precioTopico) AS total FROM tm_detalle_pedido WHERE id_pedido = ".$d->id_pedido." AND estado <> 'z'")
                    ->fetch(PDO::FETCH_OBJ);
            }
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    public function impresion_ingreso($id_pedido)
    {
        try
        {    
            // SELECT * FROM tm_ingresos_adm WHERE id_ing = ?
            $stm = $this->db->prepare("SELECT * FROM tm_ingresos_adm WHERE id_ing = ?");
            $stm->execute(array($id_pedido));
            $c = $stm->fetch(PDO::FETCH_OBJ);
            // SELECT * FROM tm_usuario WHERE id_usu = 2
            $c->{'usuario'} = $this->db->query("SELECT * FROM tm_usuario WHERE id_usu = " . $c->id_usu."")->fetchAll(PDO::FETCH_OBJ);
            /* Traemos el detalle */
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    public function impresion_egreso($id_pedido)
    {
        try
        {    
            // SELECT * FROM tm_gastos_adm WHERE id_ga = ?

            $stm = $this->db->prepare("SELECT * FROM tm_gastos_adm WHERE id_ga = ?");
            $stm->execute(array($id_pedido));
            $c = $stm->fetch(PDO::FETCH_OBJ);
            // if(!$c->id_per== 0){
            //     // $c->{'trabajador'} = $this->db->query("SELECT * FROM tm_usuario WHERE id_usu = " . $c->id_usu."")->fetchAll(PDO::FETCH_OBJ);
            // }
            // SELECT * FROM tm_usuario WHERE id_usu = 2
            // SELECT * FROM tm_tipo_gasto WHERE id_tipo_gasto = 3

            $c->{'tipogasto'} = $this->db->query(" SELECT * FROM tm_tipo_gasto WHERE id_tipo_gasto = ".$c->id_tipo_gasto."")->fetchAll(PDO::FETCH_OBJ);
            $c->{'usuario'} = $this->db->query("SELECT * FROM tm_usuario WHERE id_usu = " . $c->id_usu."")->fetchAll(PDO::FETCH_OBJ);
            /* Traemos el detalle */
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    /*
    public function monitor_ventas_porcobrar()
    {
        try
        {   
            $stm = $this->db->prepare("SELECT id_pedido FROM v_listar_mesas WHERE estado = 'i'");
            $stm->execute();
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'VentasPorCobrar'} = $this->db->query("SELECT SUM(precio*cant) AS total FROM tm_detalle_pedido WHERE id_pedido = ".$d->id_pedido." AND estado <> 'z'")
                    ->fetch(PDO::FETCH_OBJ);
            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    */

    /* FIN MODULO MONITOR DE VENTAS */

}