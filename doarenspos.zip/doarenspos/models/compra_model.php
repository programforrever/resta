<?php Session::init(); ?>
<?php

class Compra_Model extends Model
{
	public function __construct()
	{
		parent::__construct();
	}

    public function Tipo_compra()
    {
        try
        {   
            return $this->db->selectAll('SELECT * FROM tm_tipo_compra');
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Tipo_documento()
    {
        try
        { 
            return $this->db->selectAll('SELECT * FROM tm_tipo_doc');
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    /* INICIO MODULO COMPRA*/
    public function compra_list($data)
    {
        try
        {
            $ifecha = date('Y-m-d',strtotime($data['ifecha']));
            $ffecha = date('Y-m-d',strtotime($data['ffecha']));
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');

            $consulta = "call sp_get_compras(:idemp,:idsede,:id_tipo_compra,:id_prov,:id_tipo_doc,:fecha_i,:fecha_f,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_tipo_compra' => $data['id_tipo_compra'],
                ':id_prov' => $data['id_prov'],
                ':id_tipo_doc' => $data['id_tipo_doc'],
                ':fecha_i' => $ifecha,
                ':fecha_f' => $ffecha,
                ':estado' => $data['estado']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Proveedor()
    {
        try
        {
            $idemp=Session::get('idemp');      
            return $this->db->selectAll('SELECT id_prov,ruc,razon_social FROM tm_proveedor WHERE idemp ='.$idemp);
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function compra_det()
    {
        try
        {
            $idemp=Session::get('idemp');
            $stm = $this->db->prepare("SELECT * FROM tm_compra_detalle WHERE id_compra = ?");
            $stm->execute(array($_POST['id_compra']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $consulta = "call sp_get_insprod(:idemp,:idsede,:id_tipo_ins,:id_ins,:cadena);";
                $arrayParam =  array(
                    ':idemp' => $idemp,
                    ':idsede' => '%',
                    ':id_tipo_ins' => $d->id_tp,
                    ':id_ins' => $d->id_pres,
                    ':cadena'=>'%'
                );
                $st1 = $this->db->prepare($consulta);
                $st1->execute($arrayParam);
                $c[$k]->{'Producto'} = $st1->fetch(PDO::FETCH_OBJ);
                $st1->closeCursor();

            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function compra_crud_create($data)
    {
        try
        {   
            date_default_timezone_set($_SESSION["zona_horaria"]);
            setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
            $fecha_reg = date("Y-m-d H:i:s");
            $igv = Session::get('igv');
            $id_usu = Session::get('usuid');
            $fecha_c = date('Y-m-d',strtotime($data['fecha_c']));
            $cantInsumo;
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 
            
            $sql = "INSERT INTO tm_compra (id_prov, id_tipo_compra, id_tipo_doc, id_usu, fecha_c, hora_c, serie_doc, num_doc, igv, total, descuento, fecha_reg, idemp, idsede) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
            $this->db->prepare($sql)
                ->execute(
                    array(
                        $data['id_prov'],
                        $data['id_tipo_compra'],
                        $data['id_tipo_doc'],
                        $id_usu,
                        $fecha_c,
                        $data['hora_c'],
                        $data['serie_doc'],
                        $data['num_doc'],
                        $igv,
                        $data['monto_total'],
                        $data['descuento'],
                        $fecha_reg,
                        $idemp,
                        $idsede
                ));

            /* El ultimo ID que se ha generado */
            $compra_id = $this->db->lastInsertId();

            if($data['id_tipo_compra'] == 2){

                $a = $data['monto_cuota'];
                $c = $data['fecha_cuota'];
                $estado="p";

                for($x=0; $x < sizeof($a); ++$x)
                {
                    $sql = "INSERT INTO tm_compra_credito (id_compra,total,fecha,estado,idemp,idsede) VALUES (?,?,?,?,?,?);";
                    $this->db->prepare($sql)->execute(array($compra_id,$a[$x],date('Y-m-d',strtotime($c[$x])),$estado,$idemp,$idsede));
                }
            }

            /* Recorremos el detalle para insertar */ 
            foreach($data['items'] as $d)
            {
                if($data['actualizaStock']=='i'){
                    $cantInsumo = 0;
                }else{
                    $cantInsumo = $d['cantidad_insumo'];
                }

                $estd="a";

                $sqll = "INSERT INTO tm_compra_detalle (id_compra,id_tp,id_pres,cant,precio,idemp,idsede) VALUES (?,?,?,?,?,?,?)";
                $this->db->prepare($sqll)->execute(array($compra_id,$d['id_tipo_ins_insumo'],$d['id_ins_insumo'],$d['cantidad_insumo'],$d['precio_insumo'],$idemp,$idsede));

                $sql = "INSERT INTO tm_inventario (id_tipo_ope,id_ope,id_tipo_ins,id_ins,cos_uni,cant,fecha_r,estado,idemp,idsede) VALUES (?,?,?,?,?,?,?,?,?,?)";
                $this->db->prepare($sql)->execute(array(1,$compra_id,$d['id_tipo_ins_insumo'],$d['id_ins_insumo'],$d['precio_insumo'],$cantInsumo,$fecha_reg,$estd,$idemp,$idsede));

            }

            return true;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function compra_delete($data)
    {
        try 
        {
            $consulta = "call usp_comprasAnular( :flag, :id_compra);";
            $arrayParam =  array(
                ':flag' => 1,
                ':id_compra' => $data['id_compra']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $row = $st->fetch(PDO::FETCH_ASSOC);
            return $row;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function compra_proveedor_buscar($data)
    {
        try
        {   
            $idemp=Session::get('idemp');     
            $stm = $this->db->prepare("SELECT id_prov,ruc,razon_social FROM tm_proveedor WHERE estado <> 'i' AND (ruc LIKE '%$data%' OR razon_social LIKE '%$data%') AND idemp = ? ORDER BY ruc LIMIT 5");
            $stm->execute(array($idemp));
            return $stm->fetchAll(PDO::FETCH_OBJ);
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function compra_insumo_buscar($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            
            $consulta = "call sp_get_insprod(:idemp,:idsede,:id_tipo_ins,:id_ins,:cadena);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => '%',
                ':id_tipo_ins' => '%',
                ':id_ins' => '%',
                ':cadena'=>'%'.$data.'%'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);

            // Filtrar por estados diferentes de 'c'
            $c = array_filter($c, function ($insprod) {
                return $insprod->est_b == 'a' && $insprod->est_c == 'a' && $insprod->id_tipo_ins !== '3';
            });

            // Limitar el número de respuestas a un máximo de 5
            $c = array_slice($c, 0, 5);

            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function compra_proveedor_nuevo($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $email = "--";
            $contacto = "--";
            $telefono = "999999999";
            if($data['telefono'] != ""){
                $telefono =$data['telefono'];
            }
            if($data['email'] != ""){
                $email =$data['email'];
            }
            if($data['contacto'] != ""){
                $contacto =$data['contacto'];
            }   
            $consulta = "call usp_comprasRegProveedor( :flag, @a, :ruc, :razon_social, :direccion, :telefono, :email, :contacto, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 1,
                ':ruc' => $data['ruc'],
                ':razon_social' => $data['razon_social'],
                ':direccion' => $data['direccion'],
                ':telefono' => $telefono,
                ':email' => $email,
                ':contacto' => $contacto,
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetch(PDO::FETCH_OBJ);
            return $c;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    /* FIN MODULO COMPRA*/

    /* INICIO MODULO PROVEEDOR */

    public function proveedor_list()
    {
        try
        {
            $idemp=Session::get('idemp');
            //$idsede=Session::get('sede_id');      
            $stm = $this->db->prepare("SELECT * FROM tm_proveedor WHERE idemp = ?");    
            $stm->execute(array($idemp));            
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function proveedor_datos($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $stm = $this->db->prepare("SELECT * FROM tm_proveedor WHERE id_prov = ? AND idemp = ?");
            $stm->execute(array($data['id_prov'],$idemp));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function proveedor_crud_create($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $email = "--";
            $contacto = "--";
            $telefono = "999999999";
            if($data['telefono'] != ""){
                $telefono =$data['telefono'];
            }
            if($data['email'] != ""){
                $email =$data['email'];
            }
            if($data['contacto'] != ""){
                $contacto =$data['contacto'];
            }
            $consulta = "call usp_comprasRegProveedor( :flag, @a, :ruc, :razon_social, :direccion, :telefono, :email, :contacto, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 1,
                ':ruc' => $data['ruc'],
                ':razon_social' => $data['razon_social'],
                ':direccion' => $data['direccion'],
                ':telefono' => $telefono,
                ':email' => $email,
                ':contacto' => $contacto,
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $row = $st->fetch(PDO::FETCH_ASSOC);
            return $row;
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function proveedor_crud_update($data)
    {
        try 
        {   
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $email = "--";
            $contacto = "--";
            $telefono = "999999999";
            if($data['telefono'] != ""){
                $telefono =$data['telefono'];
            }
            if($data['email'] != ""){
                $email =$data['email'];
            }
            if($data['contacto'] != ""){
                $contacto =$data['contacto'];
            } 
            $consulta = "call usp_comprasRegProveedor( :flag, :id_prov, :ruc, :razon_social, :direccion, :telefono, :email, :contacto, :idemp, :idsede);";
            $arrayParam =  array(
                ':flag' => 2,
                ':id_prov' => $data['id_prov'],
                ':ruc' => $data['ruc'],
                ':razon_social' => $data['razon_social'],
                ':direccion' => $data['direccion'],
                ':telefono' => $telefono,
                ':email' => $email,
                ':contacto' => $contacto,
                ':idemp' => $idemp,
                ':idsede' => $idsede
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    public function proveedor_estado($data)
    {
        try 
        {
            $idemp=Session::get('idemp');
            $sql = "UPDATE tm_proveedor SET estado = ? WHERE id_prov = ? and idemp = ?";
            $this->db->prepare($sql)->execute(array($data['estado'],$data['id_prov'],$idemp));
        } catch (Exception $e) 
        {
            die($e->getMessage());
        }
    }

    /* FIN MODULO PROVEEDOR */
}