<?php Session::init(); ?>
<?php

class Informe_Model extends Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function TipoPedido()
    {
        try
        {      
            return $this->db->selectAll('SELECT * FROM tm_tipo_pedido');
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function TipoGasto()
    {
        try
        {      
            return $this->db->selectAll('SELECT * FROM tm_tipo_gasto');
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function CajaUsuario()
    {
        try
        {   
            $idemp=Session::get('idemp');   
            return $this->db->selectAll("SELECT id_usu,CONCAT(ape_paterno,' ',ape_materno,' ',nombres) AS nombres FROM tm_usuario WHERE (id_rol = 1 OR id_rol = 2 OR id_rol = 3) AND idEmpresa=" . $idemp);
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Cliente()
    {
        try
        {
            $idemp=Session::get('idemp');
            return $this->db->selectAll('SELECT id_cliente,CASE WHEN tipo_cliente = 1 THEN nombres WHEN tipo_cliente = 2 THEN razon_social END AS nombrecliente FROM tm_cliente WHERE idemp ='.$idemp);
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Sedes()//revisar eliminación
    {
        try
        {
            $idemp=Session::get('idemp');      
            return $this->db->selectAll('SELECT * FROM tm_sedes WHERE id_empresa ='.$idemp);
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Categoria()
    {
        try
        {
            $idemp=Session::get('idemp');       
            return $this->db->selectAll('SELECT * FROM tm_producto_catg WHERE idemp ='.$idemp);
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Producto()
    {
        try
        {
            $idemp=Session::get('idemp');       
            return $this->db->selectAll('SELECT * FROM tm_producto where idemp='.$idemp);
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Presentacion()
    {
        try
        {
            $idemp=Session::get('idemp');       
            return $this->db->selectAll('SELECT * FROM tm_producto_pres WHERE idemp='.$idemp);
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Mozo()
    {
        try
        {
            $idemp=Session::get('idemp');

            $resp= $this->db->selectAll("SELECT id_usu,CONCAT(nombres,' ',ape_paterno,' ',ape_materno) AS nombreCompl FROM tm_usuario WHERE idEmpresa = " . $idemp . " AND id_rol = 5");
            return $resp;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Proveedor()
    {
        try
        {
            $idemp=Session::get('idemp');      
            return $this->db->selectAll("SELECT * FROM tm_proveedor WHERE idemp =".$idemp);
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function TipoCompra()
    {
        try
        {     
            return $this->db->selectAll("SELECT * FROM tm_tipo_compra");
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Cajero()
    {
        try
        {
            $idemp=Session::get('idemp');    
            return $this->db->selectAll("SELECT id_usu,ape_paterno,ape_materno,nombres FROM tm_usuario WHERE idEmpresa =". $idemp ." AND (id_rol = 1 OR id_rol = 2 OR id_rol = 3) AND id_usu <> 1 AND estado = 'a'");
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Personal()
    {
        try
        {
            $idemp=Session::get('idemp');    
            return $this->db->selectAll("SELECT * FROM tm_usuario WHERE idEmpresa = ".$idemp." AND id_usu <> 1 AND estado = 'a' GROUP BY dni");
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Repartidor()
    {
        try
        {  
            $idemp=Session::get('idemp');
            //$idsede=Session::get('sede_id');   
            return $this->db->selectAll("SELECT * FROM tm_usuario WHERE id_rol = 6 AND idEmpresa=".$idemp);
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function TipoDocumento()
    {
        try
        {   
            //return $this->db->selectAll('SELECT * FROM tm_tipo_doc WHERE estado = "a"');
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 
            return $this->db->selectAll('SELECT td.id_tipo_doc,td.descripcion FROM tm_tipo_doc as td
            inner join tm_series as ts on td.id_tipo_doc = ts.id_tipo_doc 
            WHERE ts.estado = "a" AND ts.idemp =' . $idemp .'  AND ts.idsede = '. $idsede . ' ORDER BY td.descripcion DESC	');
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Formapago()
    {
        try
        {
            return $this->db->selectAll('SELECT * FROM tm_tipo_pago WHERE id_tipo_pago IN(1,2,3) AND estado = "a" ORDER BY id_tipo_pago ASC LIMIT 3');
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function GetAllTipoPago(){
        $idemp=Session::get('idemp');

        return $this->db->selectAll('SELECT * FROM (SELECT * FROM tm_tipo_pago WHERE id_tipo_pago IN(1,2) AND estado = "a" ORDER BY id_tipo_pago ASC LIMIT 2) T1
            UNION SELECT * FROM (SELECT * FROM tm_tipo_pago WHERE idemp = '. $idemp .' AND estado = "a" ) T2;');

    }

    public function TipoPago($data)
    {
        try
        {   
            $idemp=Session::get('idemp');
            $id_pago =$data['id_forma_pago'];
            if($id_pago != 3 && $id_pago != "%"){
                $consulta = "AND id_pago = $id_pago";
            }else{
                $consulta = "";
            }
            $datos = $this->db->selectAll('SELECT * FROM (SELECT * FROM tm_tipo_pago WHERE id_tipo_pago IN(1,2) AND estado = "a" '.$consulta.' ORDER BY id_tipo_pago ASC LIMIT 2) T1
            UNION SELECT * FROM (SELECT * FROM tm_tipo_pago WHERE idemp = '. $idemp .' AND estado = "a" '.$consulta.') T2;');
            echo '<option value="%">Mostrar todo</option>';
            foreach ($datos as  $v){
                echo '<option value="'.$v['id_tipo_pago'].'">'.$v['descripcion'].'</option>';

            }
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function Empresa()
    {
        try
        {  
            $idemp=Session::get('idemp');
            //$idsede=Session::get('sede_id');      
            return $this->db->selectOne("SELECT * FROM tm_empresa WHERE id_de=".$idemp);
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    /* INICIO VENTAS */

    public function venta_all_list()
    {
        try
        {   
            // CASE WHEN v.estado = 'a' THEN v.pago_efe + v.pago_tar ELSE 0 END
            $ifecha = date('Y-m-d H:i:s',strtotime($_POST['ifecha']));
            $ffecha = date('Y-m-d H:i:s',strtotime($_POST['ffecha']));
            $idemp=Session::get('idemp');
            $tped = $_POST['tped'];
            $tdoc = $_POST['tdoc'];
            $estado = $_POST['estado'];

            $consulta2 = "call sp_get_ventas_con(:idemp,:idsede,:fecha_i,:fecha_f,:id_vent,:id_cli);";
            $arrayParam2 =  array(
                ':idemp' => $idemp,
                ':idsede' => $_POST['idsede'],
                ':fecha_i' => $ifecha,
                ':fecha_f' => $ffecha,
                ':id_vent' => '%',
                ':id_cli' => $_POST['cliente']

            );
            $stm = $this->db->prepare($consulta2);
            $stm->execute($arrayParam2);
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $stm->closeCursor();

            //filtrar por canal de venta, por tipo documento, por estado

            $c = array_filter($c, function ($vent_con) use ($tped,$tdoc,$estado)  {
                $condicion1 = $tped == "%" || $vent_con->id_tped == $tped;
                $condicion2 = $tdoc == "%" || $vent_con->id_tdoc == $tdoc;
                $condicion3 = $estado == "%" || $vent_con->estado == $estado;
                return $condicion1 && $condicion2 && $condicion3;
            });

            // Reindexar el array
            $c = array_values($c);

            foreach($c as $k => $d)
            {
                if($d->estado == "a"){
                    $c[$k]->{'total'} = number_format( $d->pago_efe + $d->pago_tar, 2, '.', '');
                }else{
                    $c[$k]->{'total'} = number_format(0, 2, '.', '');
                }

                $nombCaja = $this->db->query("SELECT c.descripcion AS desc_caja FROM tm_aper_cierre AS ac  JOIN tm_caja AS c ON ac.id_caja = c.id_caja WHERE ac.id_apc = " . $d->id_apc)
                ->fetch(PDO::FETCH_OBJ);

                $c[$k]->{'desc_caja'} = $nombCaja->desc_caja;

                $c[$k]->{'Pedido'} = $this->db->query("SELECT ts.descripcion AS desc_salon, m.nro_mesa FROM tm_pedido_mesa AS pm JOIN tm_mesa AS m  ON pm.id_mesa = m.id_mesa
                    JOIN tm_salon AS ts ON m.id_salon = ts.id_salon WHERE pm.id_pedido = ".$d->id_ped)
                        ->fetch(PDO::FETCH_OBJ);

            
                $c[$k]->{'Cliente'} = $this->db->query("SELECT id_cliente,
                    CASE
                        WHEN tipo_cliente = 1 THEN nombres
                        WHEN tipo_cliente = 2 THEN razon_social
                    END AS nombrecliente FROM tm_cliente  WHERE id_cliente = ".$d->id_cli)
                        ->fetch(PDO::FETCH_OBJ);
                    

                $c[$k]->{'Personal'} = $this->db->query("SELECT CONCAT(nombres,' ',ape_paterno,' ',ape_materno) AS nombres FROM tm_usuario WHERE id_usu = ".$d->desc_personal)
                    ->fetch(PDO::FETCH_OBJ);
    

                $c[$k]->{'Tipopago'} = $this->db->query("SELECT descripcion AS nombre FROM tm_tipo_pago WHERE id_tipo_pago = " . $d->id_fpag)
                    ->fetch(PDO::FETCH_OBJ);
            }

            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;       
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function venta_all_det($data)
    {
        try
        {
            $id_ped = $data['id_ped'];
            $stm = $this->db->prepare("SELECT id_prod,SUM(cantidad) AS cantidad,precio FROM tm_detalle_venta WHERE id_venta = ? GROUP BY id_prod, precio");
            $stm->execute(array($data['id_venta']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Comision'} = $this->db->query("SELECT comision_delivery AS total FROM tm_venta WHERE id_venta = ".$data['id_venta'])
                    ->fetch(PDO::FETCH_OBJ);
           
                $c[$k]->{'Descuento'} = $this->db->query("SELECT descuento_monto AS total FROM tm_venta WHERE id_venta = ".$data['id_venta'])
                    ->fetch(PDO::FETCH_OBJ);

                $c[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom, pp.presentacion AS pro_pre FROM tm_producto_pres AS pp JOIN tm_producto AS p ON pp.id_prod = p.id_prod WHERE pp.id_pres = ".$d->id_prod)
                    ->fetch(PDO::FETCH_OBJ);

                $c[$k]->{'DetaTopico'} = $this->db->query("SELECT 'TOTAL TOPICO' as descripcion,SUM(precioTopico) AS precioTopico FROM tm_detalle_pedido WHERE id_pedido = $id_ped AND id_pres = ".$d->id_prod." AND estado <> 'z'")
                    ->fetch(PDO::FETCH_OBJ);   
                    
            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function venta_delivery_list()
    {
        try
        {
            $ifecha = date('Y-m-d H:i:s',strtotime($_POST['ifecha']));
            $ffecha = date('Y-m-d H:i:s',strtotime($_POST['ffecha']));
            $idemp=Session::get('idemp');
            $id_repartidor = $_POST['id_repartidor'];
            $tipo_entrega = $_POST['tipo_entrega'];

            $consulta2 = "call sp_get_ventas_con(:idemp,:idsede,:fecha_i,:fecha_f,:id_vent,:id_cli);";
            $arrayParam2 =  array(
                ':idemp' => $idemp,
                ':idsede' => $_POST['idsede'],
                ':fecha_i' => $ifecha,
                ':fecha_f' => $ffecha,
                ':id_vent' => '%',
                ':id_cli' => '%'

            );
            $stm = $this->db->prepare($consulta2);
            $stm->execute($arrayParam2);
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $stm->closeCursor();

            //filtrar por canal de venta delivery

            $c = array_values(array_filter($c, function ($vent_con) {
                return $vent_con->id_tped == "3";
            }));
    
            foreach($c as $k => $d)
            {
                $consulta1 = "call sp_pedido_delivery(:idemp,:idsede,:id_pedido,:estado);";
                $arrayParam1 =  array(
                    ':idemp' => $d->idemp,
                    ':idsede' => $d->idsede,
                    ':id_pedido' => $d->id_ped,
                    ':estado'=>'a'
                );
                $stm1 = $this->db->prepare($consulta1);
                $stm1->execute($arrayParam1);
                $pedidoDeliv = $stm1->fetch(PDO::FETCH_OBJ);
                $stm1->closeCursor();
    
                $c[$k]->{'tipo_entrega'} = $pedidoDeliv->tipo_entrega;
                $c[$k]->{'id_repartidor'} = $pedidoDeliv->id_repartidor;

                if($d->estado == "a"){
                    $c[$k]->{'total'} = number_format( $d->pago_efe + $d->pago_tar, 2, '.', '');
                }else{
                    $c[$k]->{'total'} = number_format(0, 2, '.', '');
                }

                $c[$k]->{'desc_repartidor'} = $pedidoDeliv->desc_repartidor;

                $c[$k]->{'Cliente'} = $this->db->query("SELECT CASE WHEN tipo_cliente = 1 THEN nombres  WHEN tipo_cliente = 2 THEN razon_social END AS nombrecliente FROM tm_cliente WHERE id_cliente = ".$d->id_cli)
                    ->fetch(PDO::FETCH_OBJ);
                
                $c[$k]->{'Caja'} = $this->db->query("SELECT tc.descripcion AS desc_caja FROM tm_aper_cierre AS apc JOIN tm_caja AS tc ON apc.id_caja = tc.id_caja WHERE apc.id_apc = ".$d->id_apc)
                    ->fetch(PDO::FETCH_OBJ);
            }

            // Reindexar el array y filtrar por repartidos y tipo de entrega
            $c = array_values(array_filter($c, function ($vent_con) use ($id_repartidor,$tipo_entrega)  {
                $condicion1 = $id_repartidor == "%" || $vent_con->id_repartidor == $id_repartidor;
                $condicion2 = $tipo_entrega == "%" || $vent_con->tipo_entrega == $tipo_entrega;
                return $condicion1 && $condicion2;
            }));

            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;       
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    /*public function venta_culqi_list()
    {
        try
        {
            $ifecha = date('Y-m-d',strtotime($_POST['ifecha']));
            $ffecha = date('Y-m-d',strtotime($_POST['ffecha']));
            $stm = $this->db->prepare("SELECT v.desc_td,v.ser_doc,v.nro_doc,v.total,v.igv,d.tipo_entrega,d.nombre_cliente,d.email_cliente,d.fecha_pedido FROM v_ventas_con AS v INNER JOIN v_pedido_delivery AS d ON v.id_ped = d.id_pedido WHERE d.tipo_pago = 4 AND (DATE(v.fec_ven) >= ? AND DATE(v.fec_ven) <= ?) AND d.tipo_entrega LIKE ?");
            $stm->execute(array($ifecha,$ffecha,$_POST['tipo_entrega']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;       
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }*/

    public function venta_prod_list($data)
    {
        try
        {
            $ifecha = date('Y-m-d',strtotime($data['ifecha']));
            $ffecha = date('Y-m-d',strtotime($data['ffecha']));
            $idemp=Session::get('idemp');
            //$idsede=Session::get('sede_id');
            $stm = $this->db->prepare("SELECT dp.id_prod,
            SUM(CASE WHEN v.id_tipo_pedido = 1 THEN dp.cantidad ELSE 0 END) AS cantidad_salon,
            SUM(CASE WHEN v.id_tipo_pedido = 2 THEN dp.cantidad ELSE 0 END) AS cantidad_llevar,
            SUM(CASE WHEN v.id_tipo_pedido = 3 THEN dp.cantidad ELSE 0 END) AS cantidad_delivery,
            SUM(dp.cantidad) AS cantidad_total,dp.precio,IFNULL((SUM(dp.cantidad)*dp.precio),0) AS total,v.fecha_venta 
            FROM tm_detalle_venta AS dp 
            JOIN tm_venta AS v ON dp.id_venta = v.id_venta
            JOIN tm_producto_pres AS tpp ON dp.id_prod = tpp.id_pres
            JOIN tm_producto AS tp ON tpp.id_prod = tp.id_prod
            WHERE dp.idemp = ? AND dp.idsede LIKE ? AND (DATE(v.fecha_venta) >= ? AND DATE(v.fecha_venta) <= ?) AND tp.id_catg LIKE ?
            AND tpp.id_prod LIKE ? AND tpp.id_pres LIKE ? AND v.estado = 'a' GROUP BY dp.id_prod, dp.precio
            ORDER BY v.fecha_venta DESC, SUM(dp.cantidad) DESC;");

            $stm->execute(array($idemp,$_POST['idsede'],$ifecha,$ffecha,$data['id_catg'],$data['id_prod'],$data['id_pres']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Producto'} = $this->db->query("SELECT cp.descripcion AS pro_cat,p.nombre AS pro_nom, pp.presentacion AS pro_pre FROM tm_producto_pres pp JOIN tm_producto p ON pp.id_prod = p.id_prod JOIN tm_producto_catg cp ON p.id_catg = cp.id_catg WHERE pp.id_pres = ".$d->id_prod)
                    ->fetch(PDO::FETCH_OBJ);

            }

            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function venta_prod_kardex_list($data)
    {
        try
        {
            $ifecha = date('Y-m-d',strtotime($data['ifecha']));
            $ffecha = date('Y-m-d',strtotime($data['ffecha']));
            $idemp=Session::get('idemp');
            //$idsede=Session::get('sede_id');
            $query = $this->db->prepare("SELECT tv.id_venta,tv.fecha_venta AS fecha_venta, td.descripcion AS documento_venta, 
            CONCAT(tv.serie_doc,'-',tv.nro_doc) AS nro_documento, 
            CONCAT(tp.nombre,' - ',tpp.presentacion) AS producto_presentacion, 
            cp.descripcion AS producto_categoria, dv.cantidad AS cantidad_vendida, 
            dv.precio AS precio_venta, (dv.cantidad*dv.precio) AS total
            FROM tm_detalle_venta AS dv 
            JOIN tm_venta AS tv ON dv.id_venta = tv.id_venta
            JOIN tm_tipo_doc AS td ON tv.id_tipo_doc = td.id_tipo_doc
            JOIN tm_producto_pres AS tpp ON dv.id_prod = tpp.id_pres
            JOIN tm_producto AS tp ON tpp.id_prod = tp.id_prod
            JOIN tm_producto_catg cp ON tp.id_catg = cp.id_catg
            WHERE dv.idemp = ? AND dv.idsede LIKE ? AND (DATE(tv.fecha_venta) >= ? AND DATE(tv.fecha_venta) <= ?) AND tp.id_catg = ?
            AND tpp.id_prod = ? AND tpp.id_pres = ? AND tv.estado = 'a' ORDER BY tv.fecha_venta DESC;");
            $query->execute(array($idemp,$_POST['idsede'],$ifecha,$ffecha,$data['id_catg'],$data['id_prod'],$data['id_pres']));
            $a = $query->fetchAll(PDO::FETCH_OBJ);

            $data = array("data" => $a);
            $json = json_encode($data);
            echo $json;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function venta_prod_kardex_graphic($data)
    {
        try
        {
            $ifecha = date('Y-m-d',strtotime($data['ifecha']));
            $ffecha = date('Y-m-d',strtotime($data['ffecha']));
            $idemp=Session::get('idemp');
            //$idsede=Session::get('sede_id');

            $query = $this->db->prepare("SELECT DATE(tv.fecha_venta) AS y, SUM(dv.cantidad) AS a FROM tm_detalle_venta AS dv 
            JOIN tm_venta AS tv ON dv.id_venta = tv.id_venta
            JOIN tm_producto_pres AS tpp ON dv.id_prod = tpp.id_pres
            JOIN tm_producto AS tp ON tpp.id_prod = tp.id_prod
            WHERE dv.idemp = ? AND dv.idsede LIKE ? AND (DATE(tv.fecha_venta) >= ? AND DATE(tv.fecha_venta) <= ?) 
            AND tp.id_catg = ? AND tpp.id_prod = ? AND tpp.id_pres = ? AND tv.estado = 'a' 
            GROUP BY DATE(tv.fecha_venta) 
            ORDER BY tv.fecha_venta DESC");
            
            $query->execute(array($idemp,$_POST['idsede'],$ifecha,$ffecha,$data['id_catg'],$data['id_prod'],$data['id_pres']));
            $a = $query->fetchAll(PDO::FETCH_OBJ);

            $data = array('data' => $a);
            $json = json_encode($data);
            echo $json;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    
    public function venta_prod_utilidad_list($data)
    {
        try
        {
            $ifecha = date('Y-m-d',strtotime($data['ifecha']));
            $ffecha = date('Y-m-d',strtotime($data['ffecha']));

            $idemp=Session::get('idemp');
            $stm = $this->db->prepare(" SELECT dv.id_prod,CONCAT(p.nombre,' - ',pp.presentacion) AS producto_presentacion,p.id_catg,v.id_tipo_pedido,SUM(dv.precio * dv.cantidad) AS importe,
            SUM(dv.cantidad) AS cantidad_vendida,SUM(dv.costo * dv.cantidad) AS costo_prod_venta,pp.receta FROM tm_detalle_venta AS dv 
            INNER JOIN tm_venta AS v ON dv.id_venta = v.id_venta 
            INNER JOIN tm_producto_pres AS pp ON dv.id_prod = pp.id_pres 
            INNER JOIN tm_producto AS p ON pp.id_prod = p.id_prod
            WHERE (DATE(v.fecha_venta) >= ? AND DATE(v.fecha_venta) <= ?) AND p.id_tipo in (1,2) AND v.estado = 'a' AND dv.idemp = ? AND p.id_catg LIKE ? 
            GROUP BY dv.id_prod;");
            $stm->execute(array($ifecha,$ffecha,$idemp,$data['id_catg']/*$ifecha,$ffecha,$data['id_catg']*/));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);

            foreach($c as $k => $d)
            {
                $c[$k]->{'categoria'} = $this->db->query("SELECT descripcion from tm_producto_catg WHERE id_catg = ".$d->id_catg)
                ->fetch(PDO::FETCH_OBJ);

            }

            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    /**venta_prod_margen_list desabilitado (costo no se encuentra en la tabla tm_detalle_venta --> adecuar) */
    /*public function venta_prod_margen_list($data)
    {
        try
        {
            $ifecha = date('Y-m-d',strtotime($data['ifecha']));
            $ffecha = date('Y-m-d',strtotime($data['ffecha']));
            $stm = $this->db->prepare("SELECT CONCAT(p.pro_nom,' - ',p.pro_pre) AS producto_presentacion, p.pro_cat AS producto_categoria, SUM(dv.cantidad) AS cantidad_vendida, dv.costo AS costo_unitario, (SUM(dv.cantidad)*dv.costo) AS costo_total, dv.precio AS precio_venta, (dv.precio-dv.costo) AS margen_unitario, ((SUM(dv.cantidad)*dv.precio) - (SUM(dv.cantidad)*dv.costo)) AS margen_total, (SUM(dv.cantidad)*dv.precio) AS total 
                FROM tm_detalle_venta AS dv 
                INNER JOIN tm_venta AS v ON v.id_venta = dv.id_venta
                INNER JOIN v_productos AS p ON p.id_pres = dv.id_prod
                WHERE (DATE(v.fecha_venta) >= ? AND DATE(v.fecha_venta) <= ?) AND p.id_catg LIKE ? AND p.id_prod LIKE ? AND p.id_pres LIKE ? AND v.estado = 'a' GROUP BY dv.precio,dv.costo ORDER BY v.fecha_venta DESC;");
            $stm->execute(array($ifecha,$ffecha,$data['id_catg'],$data['id_prod'],$data['id_pres']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);

            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }*/
    /***------------------------------------------------ */
    public function combPro($data)
    {
        try
        {
            $stm = $this->db->prepare("SELECT * FROM tm_producto WHERE id_catg = ?");
            $stm->execute(array($data['cod']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    public function venta_cort_list($data)
    {
        try
        {
            $ifecha = date('Y-m-d H:i:s',strtotime($data['ifecha']));
            $ffecha = date('Y-m-d H:i:s',strtotime($data['ffecha']));
            $idemp=Session::get('idemp');
            //$idsede=Session::get('sede_id');

            $consulta = "call sp_get_ventas_con(:idemp,:idsede,:fecha_i,:fecha_f,:id_vent,:id_cli);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $_POST['idsede'],
                ':fecha_i' => $ifecha,
                ':fecha_f' => $ffecha,
                ':id_vent' => '%',
                ':id_cli' => '%'

            );
            $stm = $this->db->prepare($consulta);
            $stm->execute($arrayParam);
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $stm->closeCursor();
            // Reindexar el array y filtrar por estado y tipo_descuento cortesia
            $c = array_values(array_filter($c, function ($vent_con){
                return $vent_con->estado == "a" && $vent_con->desc_tipo == "1";
            }));

            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;       
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
    public function combPre($data)
    {
        try
        {
            $stm = $this->db->prepare("SELECT * FROM tm_producto_pres WHERE id_prod = ?");
            $stm->execute(array($data['cod']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function venta_mozo_list($data)
    {
        try
        {
            $ifecha = date('Y-m-d H:i:s',strtotime($data['ifecha']));
            $ffecha = date('Y-m-d H:i:s',strtotime($data['ffecha']));
            $idemp=Session::get('idemp');

            $stm = $this->db->prepare("SELECT v.fecha_venta AS fec_ven,td.descripcion AS desc_td,CONCAT(v.serie_doc,'-',v.nro_doc) AS numero,
            SUM(tvp.cant_pago) AS total,v.id_cliente AS id_cli,pm.id_mozo FROM tm_venta AS v 
            JOIN tm_venta_pago tvp ON v.id_venta = tvp.id_venta
            JOIN tm_tipo_pago tp ON tvp.id_tipo_pago = tp.id_tipo_pago
            JOIN tm_tipo_doc AS td ON v.id_tipo_doc = td.id_tipo_doc
            JOIN tm_pedido_mesa AS pm ON v.id_pedido = pm.id_pedido 
            WHERE v.id_venta <> 0 AND v.estado = 'a' AND v.idemp = ? AND v.idsede LIKE ? AND (DATE(v.fecha_venta) >= ? AND DATE(v.fecha_venta) <= ?) AND pm.id_mozo like ? AND v.estado = 'a' GROUP BY v.id_venta ORDER BY v.id_venta DESC");
            $stm->execute(array($idemp,$_POST['idsede'],$ifecha,$ffecha,$data['id_mozo']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);

            foreach($c as $k => $d)
            {
                
                $c[$k]->{'Mozo'} = $this->db->query("SELECT CONCAT(nombres,' ',ape_paterno,' ',' ',ape_materno) AS nombre FROM tm_usuario WHERE id_usu = ".$d->id_mozo)
                    ->fetch(PDO::FETCH_OBJ);


                $c[$k]->{'Cliente'} = $this->db->query("SELECT CASE WHEN tipo_cliente = 1 THEN nombres  WHEN tipo_cliente = 2 THEN razon_social END AS nombrecliente FROM tm_cliente WHERE id_cliente = ".$d->id_cli)
                    ->fetch(PDO::FETCH_OBJ);
            }
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;  
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }


    public function venta_fpago_list($data)
    {
        try
        {
            $ifecha = date('Y-m-d H:i:s',strtotime($data['ifecha']));
            $ffecha = date('Y-m-d H:i:s',strtotime($data['ffecha']));
            $idemp=Session::get('idemp');
            $id_fpag = $data['id_fpag'];
            $id_tpag = $data['id_tpag'];
            $idCajero = $data['idcajero'];
            $estado = "a";
            //$idsede=Session::get('sede_id');

            $consulta2 = "call sp_get_ventas_con(:idemp,:idsede,:fecha_i,:fecha_f,:id_vent,:id_cli);";
            $arrayParam2 =  array(
                ':idemp' => $idemp,
                ':idsede' => $_POST['idsede'],
                ':fecha_i' => $ifecha,
                ':fecha_f' => $ffecha,
                ':id_vent' => '%',
                ':id_cli' => '%'
            );
            $stm = $this->db->prepare($consulta2);
            $stm->execute($arrayParam2);
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $stm->closeCursor();

            //Reindexar el array  filtrar por tipo pago,por tipo pago, por estado

            $c = array_values(array_filter($c, function ($vent_con) use ($id_fpag,$estado,$idCajero)  {
                $condicion1 = $id_fpag == "%" || $vent_con->id_fpag == $id_fpag;
                $condicion2 = $estado == "%" || $vent_con->estado == $estado;
                $condicion3 = $idCajero == "%" || $vent_con->id_usu == $idCajero;
                return $condicion1 && $condicion2 && $condicion3;
            }));
                     
            foreach($c as $k => $d)
            {
                $c[$k]->{'numero'} = utf8_decode( $d->ser_doc ."-". $d->nro_doc);

                $c[$k]->{'total'} = number_format( $d->pago_efe + $d->pago_tar, 2, '.', '');

                $c[$k]->{'Cliente'} = $this->db->query("SELECT CASE WHEN tipo_cliente = 1 THEN nombres  WHEN tipo_cliente = 2 THEN razon_social END AS nombrecliente FROM tm_cliente WHERE id_cliente = ".$d->id_cli)
                    ->fetch(PDO::FETCH_OBJ);
                //trae las formas de pago
                $c[$k]->{'FormaPago'} = $this->db->query("SELECT descripcion AS nomFormaPago,id_pago FROM tm_tipo_pago WHERE id_tipo_pago in (1,2,3) AND id_pago =" .$d->id_fpag)
                ->fetch(PDO::FETCH_OBJ);
                //trae todos los tipos de pago
                $c[$k]->{'Tipopago'} = $this->db->query("SELECT descripcion AS nombre,tvp.cant_pago FROM tm_venta_pago as tvp join tm_tipo_pago as ttp on tvp.id_tipo_pago = ttp.id_tipo_pago WHERE tvp.id_venta = " . $d->id_ven." AND tvp.id_tipo_pago LIKE '".$id_tpag."'")
                    ->fetchAll(PDO::FETCH_OBJ);
            }
            // Filtrar el array para eliminar los elementos con 'Tipopago' vacío
            $nuevoArray = array_values(array_filter($c, function ($elemento) {
                // Verificar si el elemento es un objeto y si 'Tipopago' no está vacío
                return is_object($elemento) && property_exists($elemento, 'Tipopago') && is_array($elemento->Tipopago) && count($elemento->Tipopago) > 0;
            }));
            $data = array("data" => $nuevoArray);
            $json = json_encode($data);
            echo $json;       
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function venta_desc_list($data)
    {
        try
        {
            $ifecha = date('Y-m-d H:i:s',strtotime($data['ifecha']));
            $ffecha = date('Y-m-d H:i:s',strtotime($data['ffecha']));
            $idemp=Session::get('idemp');

            $consulta = "call sp_get_ventas_con(:idemp,:idsede,:fecha_i,:fecha_f,:id_vent,:id_cli);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $_POST['idsede'],
                ':fecha_i' => $ifecha,
                ':fecha_f' => $ffecha,
                ':id_vent' => '%',
                ':id_cli' => '%'

            );
            $stm = $this->db->prepare($consulta);
            $stm->execute($arrayParam);
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $stm->closeCursor();
            // Reindexar el array y filtrar por estado y tipo_descuento cortesia
            $c = array_values(array_filter($c, function ($vent_desc){
                return $vent_desc->estado == "a" && $vent_desc->desc_monto > 0 && $vent_desc->desc_tipo == "2";
            }));

            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;       
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function venta_all_imp($data)
    {
        try
        {
  
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta2 = "call sp_get_ventas_con(:idemp,:idsede,:fecha_i,:fecha_f,:id_vent,:id_cli);";
            $arrayParam2 =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':fecha_i' => '%',
                ':fecha_f' => '%',
                ':id_vent' => $data,
                ':id_cli' => '%'

            );
            $stm = $this->db->prepare($consulta2);
            $stm->execute($arrayParam2);
            $c = $stm->fetch(PDO::FETCH_OBJ);
            $stm->closeCursor();

            $c->{'Empresa'} = $this->db->query("SELECT * FROM tm_empresa WHERE id_de =".$c->idemp)
                ->fetch(PDO::FETCH_OBJ);
            $c->{'Sede'} = $this->db->query("SELECT CONCAT(direccion, ', ', departamento,' - ',provincia,' - ',distrito) AS direccion FROM tm_sedes WHERE id_empresa =".$idemp . " AND id_sede=". $idsede)
                ->fetch(PDO::FETCH_OBJ);
            $c->{'Cliente'} = $this->db->query("SELECT id_cliente,CASE WHEN tipo_cliente = 1 THEN nombres WHEN tipo_cliente = 2 THEN razon_social END AS nombrecliente,tipo_cliente,dni,ruc,telefono,direccion FROM tm_cliente WHERE id_cliente = " . $c->id_cli)
                ->fetch(PDO::FETCH_OBJ);
            //Obteniendo el nombre del cliente en para llevar y delivery
            $c->{'Clientepedido'} = $this->db->query("SELECT nomb_cliente FROM tm_pedido_llevar WHERE id_pedido =" . $c->id_ped)
                ->fetch(PDO::FETCH_OBJ);
            $c->{'Pedido'} = $this->db->query("SELECT cm.descripcion AS desc_salon, m.nro_mesa FROM tm_pedido_mesa AS tpm JOIN tm_mesa AS m ON tpm.id_mesa = m.id_mesa JOIN tm_salon AS cm ON m.id_salon = cm.id_salon WHERE m.id_mesa <> 0 AND tpm.id_pedido = ".$c->id_ped)
                ->fetch(PDO::FETCH_OBJ);   
            $c->{'Mozo'} = $this->db->query("SELECT CONCAT(tu.nombres, ' ', tu.ape_paterno) AS nombre_mozo  FROM tm_pedido_mesa AS pm INNER JOIN tm_usuario AS tu ON pm.id_mozo = tu.id_usu  WHERE pm.id_pedido = " . $c->id_ped)
                ->fetch(PDO::FETCH_OBJ);
            $c->{'Cajero'} = $this->db->query("SELECT CONCAT(tu.ape_paterno,' ', tu.ape_materno,' ',tu.nombres) AS cajero FROM tm_aper_cierre AS tc INNER JOIN tm_usuario AS tu ON tc.id_usu = tu.id_usu WHERE tc.id_apc =" . $c->id_apc)
                ->fetch(PDO::FETCH_OBJ);
            /* Traemos el detalle */
            $c->{'Detalle'} = $this->db->query("SELECT tdv.id_prod, pp.cod_prod AS codigo_producto,
                CONCAT(p.nombre,' ',if(tdv.crt_mod_prod = 1, tdv.nom_prod_pres,pp.presentacion)) AS nombre_producto, 
                IF(pp.impuesto='1','10','20') AS codigo_afectacion, 
                CAST(tdv.cantidad AS DECIMAL(7,2)) AS cantidad, 
                IF(pp.impuesto='1',ROUND((tdv.precio/(1 + $c->igv)),2),tdv.precio) AS valor_unitario,
                tdv.precio AS precio_unitario,
                IF(pp.impuesto='1',ROUND((tdv.precio/(1 + $c->igv))*tdv.cantidad,2),
                ROUND(tdv.precio*tdv.cantidad,2)) AS valor_venta,
                IF(pp.impuesto='1',ROUND((tdv.precio/(1 + $c->igv)*tdv.cantidad)*$c->igv,2),0) AS total_igv,
                pp.crt_icbper 
                FROM tm_detalle_venta AS tdv
                JOIN tm_venta AS v ON tdv.id_venta = v.id_venta
                JOIN tm_producto_pres AS pp ON tdv.id_prod = pp.id_pres
                JOIN tm_producto AS p ON pp.id_prod = p.id_prod
                WHERE v.id_tipo_doc  IN ('1','2','3') AND tdv.precio > 0 AND tdv.id_venta = ".$data)
                ->fetchAll(PDO::FETCH_OBJ);
            $c->{'Medio_pago'} = $this->db->query("SELECT descripcion,tvp.cant_pago FROM tm_venta_pago as tvp join tm_tipo_pago as ttp on tvp.id_tipo_pago = ttp.id_tipo_pago WHERE tvp.id_venta = " . $data)
                ->fetchAll(PDO::FETCH_OBJ);
            $c->{'DetaTopico'} = $this->db->query("SELECT id_pres,SUM(cantidad) AS cantidad, precio, detatopico, SUM(precioTopico) AS precioTopico FROM tm_detalle_pedido WHERE id_pedido = " . $c->id_ped." AND estado <> 'z' GROUP BY id_pres")
                ->fetchAll(PDO::FETCH_OBJ);
            $c->{'Configuracion'} = $this->db->query("SELECT pc_name,enlace_qr,msg_impre FROM tm_configuracion WHERE idemp=".$c->idemp . " AND idsede=".$c->idsede)
                ->fetch(PDO::FETCH_OBJ);
            $c->{'imp_icbper'} = $this->db->query("SELECT icbper FROM tm_configuracion WHERE principal = 1 AND idemp=".$c->idemp . " AND idsede=".$c->idsede)
                ->fetch(PDO::FETCH_OBJ);

            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function get_crt_imp_bol($cod_ven){
        try{

            $stm = $this->db->prepare("SELECT count(tpp.crt_icbper) AS crt_icbper FROM tm_venta tv
            JOIN tm_detalle_pedido tdp ON tv.id_pedido = tdp.id_pedido
            JOIN tm_producto_pres AS tpp ON tdp.id_pres =  tpp.id_pres 
            WHERE tv.id_venta = " .$cod_ven. " AND  tpp.crt_icbper = 1");
            $stm->execute();
            $c = $stm->fetch(PDO::FETCH_OBJ);
            return $c;

        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function venta_all_imp_($data)
    {
        try
        { 

            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');

            $consulta2 = "call sp_get_ventas_con(:idemp,:idsede,:fecha_i,:fecha_f,:id_vent,:id_cli);";
            $arrayParam2 =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':fecha_i' => '%',
                ':fecha_f' => '%',
                ':id_vent' => $data,
                ':id_cli' => '%'

            );
            $stm = $this->db->prepare($consulta2);
            $stm->execute($arrayParam2);
            $c = $stm->fetch(PDO::FETCH_OBJ);
            $stm->closeCursor();
                  
            $c->{'Empresa'} = $this->db->query("SELECT * FROM tm_empresa WHERE id_de =".$c->idemp)
                ->fetch(PDO::FETCH_OBJ);
            $c->{'Cliente'} = $this->db->query("SELECT id_cliente,CASE WHEN tipo_cliente = 1 THEN nombres WHEN tipo_cliente = 2 THEN razon_social END AS nombrecliente,tipo_cliente,dni,ruc,telefono,direccion FROM tm_cliente WHERE id_cliente = " . $c->id_cli)
                ->fetch(PDO::FETCH_OBJ);
            $c->{'Pedido'} = $this->db->query("SELECT cm.descripcion AS desc_salon, m.nro_mesa FROM tm_pedido_mesa AS tpm JOIN tm_mesa AS m ON tpm.id_mesa = m.id_mesa JOIN tm_salon AS cm ON m.id_salon = cm.id_salon WHERE m.id_mesa <> 0 AND tpm.id_pedido = ".$c->id_ped)
                ->fetch(PDO::FETCH_OBJ);
            
            $c->{'Mozo'} = $this->db->query("SELECT CONCAT(tu.nombres, ' ', tu.ape_paterno) AS nombre_mozo FROM tm_pedido_mesa AS pm INNER JOIN tm_usuario AS tu ON pm.id_mozo = tu.id_usu  WHERE pm.id_pedido = " . $c->id_ped)
                ->fetch(PDO::FETCH_OBJ);
            $c->{'Cajero'} = $this->db->query("SELECT CONCAT(tu.ape_paterno,' ', tu.ape_materno,' ',tu.nombres) AS cajero FROM tm_aper_cierre AS tc INNER JOIN tm_usuario AS tu ON tc.id_usu = tu.id_usu WHERE tc.id_apc =" . $c->id_apc)
                ->fetch(PDO::FETCH_OBJ);

            $c->{'Detalle'} = $this->db->query("SELECT tdv.id_prod, pp.cod_prod AS codigo_producto,
                CONCAT(p.nombre,' ',if(tdv.crt_mod_prod = 1, tdv.nom_prod_pres,pp.presentacion)) AS nombre_producto, 
                IF(pp.impuesto='1','10','20') AS codigo_afectacion, 
                CAST(tdv.cantidad AS DECIMAL(7,2)) AS cantidad, 
                IF(pp.impuesto='1',ROUND((tdv.precio/(1 + $c->igv)),2),tdv.precio) AS valor_unitario,
                tdv.precio AS precio_unitario,
                IF(pp.impuesto='1',ROUND((tdv.precio/(1 + $c->igv))*tdv.cantidad,2),
                ROUND(tdv.precio*tdv.cantidad,2)) AS valor_venta,
                IF(pp.impuesto='1',ROUND((tdv.precio/(1 + $c->igv)*tdv.cantidad)*$c->igv,2),0) AS total_igv,
                pp.crt_icbper 
                FROM tm_detalle_venta AS tdv
                JOIN tm_venta AS v ON tdv.id_venta = v.id_venta
                JOIN tm_producto_pres AS pp ON tdv.id_prod = pp.id_pres
                JOIN tm_producto AS p ON pp.id_prod = p.id_prod
                WHERE v.id_tipo_doc  IN ('1','2','3') AND tdv.precio > 0 AND tdv.id_venta = ".$data)
                ->fetchAll(PDO::FETCH_OBJ);
            $c->{'Medio_pago'} = $this->db->query("SELECT tvp.id_venta,tvp.id_tipo_pago,ttp.descripcion,tvp.cant_pago FROM tm_venta_pago AS tvp JOIN tm_tipo_pago AS ttp ON tvp. id_tipo_pago = ttp.id_tipo_pago WHERE tvp.id_venta = " . $data)
                ->fetchAll(PDO::FETCH_OBJ);

            $c->{'DetaTopico'} = $this->db->query("SELECT id_pres,SUM(cantidad) AS cantidad, precio, detatopico, SUM(precioTopico) AS precioTopico FROM tm_detalle_pedido WHERE id_pedido = " . $c->id_ped." AND estado <> 'z' GROUP BY id_pres")
                ->fetchAll(PDO::FETCH_OBJ);
            
            $c->{'Impresora'} = $this->db->query("SELECT nombre FROM tm_impresora WHERE id_imp LIKE '%' and estado = 'a' AND impr_caja='a'  AND idemp=".$idemp . " AND idsede=".$idsede)
                ->fetch(PDO::FETCH_OBJ);

            $c->{'pc_name'} = $this->db->query("SELECT pc_name FROM tm_configuracion WHERE idemp=".$idemp . " AND idsede=".$idsede)
                ->fetch(PDO::FETCH_OBJ);
            
            $c->{'enlace_qr'} = Session::get('enlace_qr');
            $c->{'msg_impre'} = Session::get('msg_impre');
            $c->{'imp_icbper'} = Session::get('imp_icbper');

            $c->{'crt_icbper'} = $this->db->query("SELECT count(tpp.crt_icbper) AS crt_icbper FROM tm_venta tv
            JOIN tm_detalle_pedido tdp ON tv.id_pedido = tdp.id_pedido
            JOIN tm_producto_pres AS tpp ON tdp.id_pres =  tpp.id_pres 
            WHERE tv.id_venta = " .$c->id_ven. " AND  tpp.crt_icbper = 1")
                ->fetch(PDO::FETCH_OBJ);
            

            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    /* FIN MODULO VENTAS */

    /* INICIO MODULO COMPRAS */

    public function compra_all_list($data)
    {
        try
        {
            $ifecha = date('Y-m-d',strtotime($data['ifecha']));
            $ffecha = date('Y-m-d',strtotime($data['ffecha']));
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id'); 
            
            $consulta = "call sp_get_compras(:idemp,:idsede,:id_tipo_compra,:id_prov,:id_tipo_doc,:fecha_i,:fecha_f,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $_POST['idsede'],
                ':id_tipo_compra' => $data['id_tipo_compra'],
                ':id_prov' => $data['id_prov'],
                ':id_tipo_doc' => $data['id_tipo_doc'],
                ':fecha_i' => $ifecha,
                ':fecha_f' => $ffecha,
                ':estado' => $data['estado']
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function compra_all_det($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $stm = $this->db->prepare("SELECT * FROM tm_compra_detalle WHERE id_compra = ?");
            $stm->execute(array($data['id_compra']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $consulta = "call sp_get_insprod(:idemp,:idsede,:id_tipo_ins,:id_ins,:cadena);";
                $arrayParam =  array(
                    ':idemp' => $idemp,
                    ':idsede' => '%',
                    ':id_tipo_ins' => $d->id_tp,
                    ':id_ins' => $d->id_pres,
                    ':cadena'=>'%'
                );
                $st1 = $this->db->prepare($consulta);
                $st1->execute($arrayParam);
                $c[$k]->{'Producto'} = $st1->fetch(PDO::FETCH_OBJ);
                $st1->closeCursor();

            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function compra_all_det_cuota($data)
    {
        try
        {
            $stm = $this->db->prepare("SELECT * FROM tm_compra_credito WHERE id_compra = ?");
            $stm->execute(array($data['id_compra']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function compra_all_det_subcuota($data)
    {
        try
        {
            $stm = $this->db->prepare("SELECT * FROM tm_credito_detalle WHERE id_credito = ?");
            $stm->execute(array($data['id_credito']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Usuario'} = $this->db->query("SELECT CONCAT(u.ape_paterno,' ',u.ape_materno,' ',u.nombres) AS nombre FROM tm_usuario u WHERE u.id_usu = ".$d->id_usu)
                    ->fetch(PDO::FETCH_OBJ);
            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    /* FIN MODULO COMPRAS */

    /* INICIO MODULO FINANZAS */

    public function finanza_arq_list($data)
    {
        try
        {
            $ifecha = date('Y-m-d H:i:s',strtotime($data['ifecha']));
            $ffecha = date('Y-m-d H:i:s',strtotime($data['ffecha']));
            $idemp=Session::get('idemp');

            $consulta = "call sp_get_caja_aper(:idemp,:idsede,:id_usu,:id_apc,:fecha_i,:fecha_f,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $_POST['idsede'],
                ':id_usu' => $data['id_usu'],
                ':id_apc' => '%',
                ':fecha_i' => $ifecha,
                ':fecha_f' => $ffecha,
                ':estado' => '%'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
            $st->closeCursor();

            foreach($c as $k => $d)
            {
                $c[$k]->{'sede'} = $this->db->query("SELECT nombre FROM tm_sedes WHERE id_sede = ".$d->idsede)
                    ->fetch(PDO::FETCH_OBJ);
            }
            
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function finanza_arq_resumen_default($data)
    {
        try
        {    
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $stm = $this->db->prepare("SELECT v.id_apc,
            SUM(CASE WHEN tp.id_pago = 1 THEN tvp.cant_pago ELSE 0 END) AS pago_efe,
            SUM(CASE WHEN tp.id_pago <> 1 THEN tvp.cant_pago ELSE 0 END) AS pago_tar,
            SUM(v.descuento_monto) AS descu,
            SUM(v.comision_tarjeta)  AS comis_tar,
            SUM(v.comision_delivery) AS comis_del,
            SUM(v.total) AS total,
            v.estado AS estado,
            v.idsede AS idsede 
            FROM tm_venta v
            JOIN tm_venta_pago tvp ON v.id_venta = tvp.id_venta
            JOIN tm_tipo_pago tp ON tvp.id_tipo_pago = tp.id_tipo_pago 
            WHERE v.id_venta <> 0 AND v.id_apc = ? AND v.estado <> 'i'");
            $stm->execute(array($data['cod_ape']));
            $c = $stm->fetch(PDO::FETCH_OBJ);

            $consulta = "call sp_get_caja_aper(:idemp,:idsede,:id_usu,:id_apc,:fecha_i,:fecha_f,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_usu' => '%',
                ':id_apc' => $data['cod_ape'],
                ':fecha_i' => '%',
                ':fecha_f' => '%',
                ':estado' => '%'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $data_caja_aper = $st->fetch(PDO::FETCH_OBJ);
            $st->closeCursor();

            $c->{'sede'} = $this->db->query("SELECT id_sede,nombre FROM tm_sedes WHERE id_sede = ".$c->idsede)
                ->fetch(PDO::FETCH_OBJ);

            $c->{'Apertura'} = $data_caja_aper;

            $c->{'Ingresos'} = $this->db->query("SELECT IFNULL(SUM(importe),0) AS total FROM tm_ingresos_adm WHERE id_apc = {$data['cod_ape']} AND estado='a'")
            ->fetch(PDO::FETCH_OBJ);
            $c->{'EgresosA'} = $this->db->query("SELECT IFNULL(SUM(importe),0) AS total FROM tm_gastos_adm WHERE id_apc = {$data['cod_ape']} AND (id_tipo_gasto = 1 OR id_tipo_gasto = 2 OR id_tipo_gasto = 3) AND estado='a'")
            ->fetch(PDO::FETCH_OBJ);
            $c->{'EgresosB'} = $this->db->query("SELECT IFNULL(SUM(importe),0) AS total FROM tm_gastos_adm WHERE id_apc = {$data['cod_ape']} AND id_tipo_gasto = 4 AND estado='a'")
            ->fetch(PDO::FETCH_OBJ);
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function finanza_arq_resumen_venta_list($data)
    {
        try
        {   
            if($data['cod_filtro'] == 1){
                $stm = $this->db->prepare("SELECT v.id_apc, SUM(tvp.cant_pago) AS monto_total,
                v.estado AS estado, v.serie_doc AS ser_doc, v.nro_doc, td.descripcion AS desc_td,v.descuento_monto AS desc_monto FROM tm_venta AS v 
                JOIN tm_venta_pago tvp ON v.id_venta = tvp.id_venta
                JOIN tm_tipo_pago tp ON tvp.id_tipo_pago = tp.id_tipo_pago
                JOIN tm_tipo_doc AS td ON v.id_tipo_doc = td.id_tipo_doc 
                WHERE v.id_venta <> 0 AND v.idsede = ? AND v.id_apc = ? AND v.estado = ? GROUP BY v.id_venta ORDER BY v.id_venta DESC");
            
            }
            $stm->execute(array($data['id_sede'],$data['cod_ape'],$data['estado']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function finanza_arq_resumen_venta_fpago_list($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $id_apc = $data['id_apc'];
            $estado = "a";

            $consulta2 = "call sp_get_ventas_con(:idemp,:idsede,:fecha_i,:fecha_f,:id_vent,:id_cli);";
            $arrayParam2 =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':fecha_i' => '%',
                ':fecha_f' => '%',
                ':id_vent' => '%',
                ':id_cli' => '%'
            );
            $stm = $this->db->prepare($consulta2);
            $stm->execute($arrayParam2);
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $stm->closeCursor();

             // Filtrar por estados diferentes de 'c'
             $c = array_values(array_filter($c, function ($venta) use ($id_apc,$estado) {
                $condicion1 = $id_apc == "%" || $venta->id_apc == $id_apc;
                $condicion2 = $estado == "%" || $venta->estado == $estado;
                return $condicion1 && $condicion2;
            }));
                     
            foreach($c as $k => $d)
            {
                $c[$k]->{'numero'} = utf8_decode( $d->ser_doc ."-". $d->nro_doc);

                $c[$k]->{'total'} = number_format( $d->pago_efe + $d->pago_tar, 2, '.', '');

                $c[$k]->{'Cliente'} = $this->db->query("SELECT CASE WHEN tipo_cliente = 1 THEN nombres  WHEN tipo_cliente = 2 THEN razon_social END AS nombrecliente FROM tm_cliente WHERE id_cliente = ".$d->id_cli)
                    ->fetch(PDO::FETCH_OBJ);
                //trae las formas de pago
                $c[$k]->{'FormaPago'} = $this->db->query("SELECT descripcion AS nomFormaPago,id_pago FROM tm_tipo_pago WHERE id_tipo_pago in (1,2,3) AND id_pago =" .$d->id_fpag)
                ->fetch(PDO::FETCH_OBJ);
                //trae todos los tipos de pago
                $c[$k]->{'Tipopago'} = $this->db->query("SELECT descripcion AS nombre,tvp.cant_pago FROM tm_venta_pago as tvp join tm_tipo_pago as ttp on tvp.id_tipo_pago = ttp.id_tipo_pago WHERE tvp.id_venta = " . $d->id_ven)
                    ->fetchAll(PDO::FETCH_OBJ);
            }
            return $c;
            /*$data = array($c);
            $json = json_encode($data);
            echo $json;*/       
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function finanza_arq_resumen_venta_delivery_list($data)
    {
        try
        {   
            $stm = $this->db->prepare("SELECT SUM(tvp.cant_pago) AS monto_total,
            v.estado AS estado, v.serie_doc AS ser_doc, v.nro_doc, td.descripcion AS desc_td,v.descuento_monto AS desc_monto,v.idsede FROM tm_venta AS v 
            JOIN tm_venta_pago tvp ON v.id_venta = tvp.id_venta
            JOIN tm_tipo_pago tp ON tvp.id_tipo_pago = tp.id_tipo_pago
            JOIN tm_tipo_doc AS td ON v.id_tipo_doc = td.id_tipo_doc
            WHERE v.id_venta <> 0 AND v.id_tipo_pedido = 3  AND v.idsede = ? AND v.id_apc = ? AND v.estado = ? GROUP BY v.id_venta ORDER BY v.id_venta DESC");
            $stm->execute(array($data['id_sede'],$data['cod_ape'],$data['estado']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function finanza_arq_resumen_caja_list_i($data)
    {
        try
        {   
            $stm = $this->db->prepare("SELECT * FROM tm_ingresos_adm WHERE id_apc = ? AND estado = ?");
            $stm->execute(array($data['id_apc'],$data['estado']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function finanza_arq_resumen_caja_list_e($data)
    {
        try
        {   
            $idemp = Session::get('idemp');
            $consulta = "call sp_get_gastosadm(:idemp,:idsede,:id_usu,:id_per,:id_tg,:estado,:idapc,:fechai,:fechaf);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => '%',
                ':id_usu' => '%',
                ':id_per' => '%',
                ':id_tg' => '%',
                ':estado' => $data['estado'],
                ':idapc' => $data['id_apc'],
                ':fechai' => '%',
                ':fechaf' => '%'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function finanza_arq_resumen_productos($data)
    {
        try
        {
            $stm = $this->db->prepare("SELECT d.id_prod,SUM(d.cantidad) AS cantidad, d.precio FROM tm_venta AS v INNER JOIN tm_detalle_venta AS d ON v.id_venta = d.id_venta WHERE v.id_apc = ? AND v.estado = 'a' GROUP BY d.id_prod, d.precio ORDER BY cantidad DESC");
            $stm->execute(array($data['id_apc']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom, pp.presentacion AS pro_pre FROM tm_producto_pres AS pp JOIN tm_producto AS p ON pp.id_prod = p.id_prod WHERE pp.id_pres = ".$d->id_prod)
                    ->fetch(PDO::FETCH_OBJ);

            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function finanza_arq_resumen_anulaciones($data)
    {
        try
        {
            $stm = $this->db->prepare("SELECT d.id_prod,SUM(d.cantidad) AS cant, d.precio FROM tm_venta AS v INNER JOIN tm_detalle_venta AS d ON v.id_venta = d.id_venta WHERE v.id_apc = ? AND v.estado = 'i' GROUP BY d.id_prod, d.precio ORDER BY cantidad DESC");
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom, pp.presentacion AS pro_pre FROM tm_producto_pres AS pp JOIN tm_producto AS p ON pp.id_prod = p.id_prod WHERE pp.id_pres = ".$d->id_prod)
                    ->fetch(PDO::FETCH_OBJ);
            }
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function finanza_ing_list($data)
    {
        try
        {
            $ifecha = date('Y-m-d',strtotime($data['ifecha']));
            $ffecha = date('Y-m-d',strtotime($data['ffecha']));
            $idemp=Session::get('idemp');
            $stm = $this->db->prepare("SELECT * FROM tm_ingresos_adm WHERE idemp = ? AND idsede LIKE ? AND (DATE(fecha_reg) >= ? AND DATE(fecha_reg) <= ?) AND id_usu LIKE ? AND estado LIKE ? ORDER BY id_ing DESC");
            $stm->execute(array($idemp,$_POST['id_sede'],$ifecha,$ffecha,$data['id_usu'],$data['estado']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Caja'} = $this->db->query("SELECT  tc.descripcion AS desc_caja FROM tm_aper_cierre AS apc JOIN tm_caja AS tc ON apc.id_caja = tc.id_caja WHERE apc.id_apc = ".$d->id_apc)
                    ->fetch(PDO::FETCH_OBJ);

                $c[$k]->{'Cajero'} = $this->db->query("SELECT CONCAT(nombres,' ',ape_paterno,' ',ape_materno) AS desc_usu FROM tm_usuario WHERE id_usu = ".$d->id_usu)
                    ->fetch(PDO::FETCH_OBJ);
            }
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function finanza_egr_list($data)
    {
        try
        {
            $ifecha = date('Y-m-d',strtotime($data['ifecha']));
            $ffecha = date('Y-m-d',strtotime($data['ffecha']));
            $idemp=Session::get('idemp');
            $consulta = "call sp_get_gastosadm(:idemp,:idsede,:id_usu,:id_per,:id_tg,:estado,:idapc,:fechai,:fechaf);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $_POST['id_sede'],
                ':id_usu' => $data['id_usu'],
                ':id_per' => '%',
                ':id_tg' => $data['tipo_gasto'],
                ':estado' => $data['estado'],
                ':idapc' => '%',
                ':fechai' => $ifecha,
                ':fechaf' => $ffecha
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
            $st->closeCursor();

            foreach($c as $k => $d)
            {
                $c[$k]->{'Caja'} = $this->db->query("SELECT tc.descripcion AS desc_caja FROM tm_aper_cierre AS apc JOIN tm_caja AS tc ON apc.id_caja = tc.id_caja WHERE apc.id_apc = ".$d->id_apc)
                    ->fetch(PDO::FETCH_OBJ);
            }
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function finanza_rem_list($data)
    {
        try
        {
            $ifecha = date('Y-m-d',strtotime($data['ifecha']));
            $ffecha = date('Y-m-d',strtotime($data['ffecha']));
            $idemp=Session::get('idemp');

            $consulta = "call sp_get_gastosadm(:idemp,:idsede,:id_usu,:id_per,:id_tg,:estado,:idapc,:fechai,:fechaf);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => '%',
                ':id_usu' => '%',
                ':id_per' => $data['id_per'],
                ':id_tg' => '%',
                ':estado' => $data['estado'],
                ':idapc' => '%',
                ':fechai' => $ifecha,
                ':fechaf' => $ffecha
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);
            $st->closeCursor();

            $c = array_filter($c, function ($gasto) {
                return $gasto->id_per !== '0';
            });

            foreach($c as $k => $d)
            {
                $c[$k]->{'Caja'} = $this->db->query("SELECT tc.descripcion AS desc_caja FROM tm_aper_cierre AS apc JOIN tm_caja AS tc ON apc.id_caja = tc.id_caja WHERE apc.id_apc = ".$d->id_apc)
                    ->fetch(PDO::FETCH_OBJ);
            }
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function oper_anul_list($data)
    {
        try
        {
            $ifecha = date('Y-m-d H:i:s',strtotime($data['ifecha']));
            $ffecha = date('Y-m-d H:i:s',strtotime($data['ffecha']));
            $idemp=Session::get('idemp');
            $stm = $this->db->prepare("SELECT *,(cant*precio) AS total  FROM tm_detalle_pedido WHERE idemp = ? AND idsede LIKE ? AND (DATE(fecha_pedido) >= ? AND DATE(fecha_pedido) <= ?) AND id_usu like ? AND estado = 'z' ORDER BY fecha_pedido DESC");
            $stm->execute(array($idemp,$_POST['id_sede'],$ifecha,$ffecha,$data['id_usu']));
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($c as $k => $d)
            {
                $c[$k]->{'Personal'} = $this->db->query("SELECT id_usu,CONCAT(ape_paterno,' ',ape_materno,' ',nombres) AS nombres FROM tm_usuario WHERE id_usu = ".$d->id_usu)
                    ->fetch(PDO::FETCH_OBJ);

                $c[$k]->{'Sede'} = $this->db->query("SELECT nombre FROM tm_sedes WHERE id_sede = ".$d->idsede)
                    ->fetch(PDO::FETCH_OBJ);

                $c[$k]->{'TipoPedido'} = $this->db->query("SELECT id_tipo_pedido FROM tm_pedido WHERE id_pedido = ".$d->id_pedido)
                    ->fetch(PDO::FETCH_OBJ);

                $c[$k]->{'Producto'} = $this->db->query("SELECT p.nombre AS pro_nom, pp.presentacion AS pro_pre FROM tm_producto_pres AS pp JOIN tm_producto AS p ON pp.id_prod = p.id_prod WHERE pp.id_pres = ".$d->id_pres)
                ->fetch(PDO::FETCH_OBJ);
            }
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json;       
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function finanza_arq_imp($data)
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $consulta = "call sp_get_caja_aper(:idemp,:idsede,:id_usu,:id_apc,:fecha_i,:fecha_f,:estado);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':id_usu' => '%',
                ':id_apc' =>  $data,
                ':fecha_i' => '%',
                ':fecha_f' => '%',
                ':estado' => '%'
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetch(PDO::FETCH_OBJ);
            $st->closeCursor();

            $c->{'Principal'} = $this->db->query("SELECT v.id_apc,
            SUM(CASE WHEN tp.id_pago = 1 THEN tvp.cant_pago ELSE 0 END) AS pago_efe,
            SUM(CASE WHEN tp.id_pago <> 1 THEN tvp.cant_pago ELSE 0 END) AS pago_tar,
            SUM(v.descuento_monto) AS descu,
            SUM(v.comision_tarjeta)  AS comis_tar,
            SUM(v.comision_delivery) AS comis_del,
            SUM(tvp.cant_pago) AS total,
            v.estado AS estado FROM  tm_venta v
            JOIN tm_venta_pago tvp ON v.id_venta = tvp.id_venta
            JOIN tm_tipo_pago tp ON tvp.id_tipo_pago = tp.id_tipo_pago 
            WHERE v.id_venta <> 0 AND v.id_apc = {$data} AND v.estado <> 'i' ")
            ->fetch(PDO::FETCH_OBJ);

            $c->{'Pagos'} = $this->db->query(" SELECT v.id_venta,v.id_pago AS id_tpag,tp.descripcion AS DESCRIPCION, 
            sum(tvp.cant_pago) AS MONTO
           FROM tm_venta v
           JOIN tm_venta_pago AS tvp ON v.id_venta = tvp.id_venta
           JOIN tm_tipo_pago AS tp ON v.id_pago = tp.id_tipo_pago
           WHERE v.id_venta <> 0 AND v.id_apc = $data
           GROUP BY v.id_venta ORDER BY v.id_pago DESC")
            ->fetchAll(PDO::FETCH_OBJ);

            $c->{'Tipopago'} = $this->db->query("SELECT descripcion AS nombre,SUM(tvp.cant_pago) as cant_pago  FROM tm_venta AS v
            JOIN tm_venta_pago AS tvp ON v.id_venta = tvp.id_venta 
            JOIN tm_tipo_pago AS ttp ON tvp.id_tipo_pago = ttp.id_tipo_pago
            WHERE v.id_apc =  $data 
            GROUP BY ttp.id_tipo_pago;")
                    ->fetchAll(PDO::FETCH_OBJ);
    
            $c->{'Glovo'} = $this->db->query("SELECT IFNULL(SUM(v.comision_delivery),0) AS total, COUNT(*) AS cant FROM tm_venta AS v LEFT JOIN tm_pedido_delivery AS d ON v.id_pedido = d.id_pedido WHERE v.id_apc = {$data} AND v.estado <> 'i' AND d.id_repartidor = 4444")
            ->fetch(PDO::FETCH_OBJ);

            $c->{'Rappi'} = $this->db->query("SELECT IFNULL(SUM(v.comision_delivery),0) AS total, COUNT(*) AS cant FROM tm_venta AS v LEFT JOIN tm_pedido_delivery AS d ON v.id_pedido = d.id_pedido WHERE v.id_apc = {$data} AND v.estado <> 'i' AND d.id_repartidor = 2222")
            ->fetch(PDO::FETCH_OBJ);

            $c->{'Ingresos'} = $this->db->query("SELECT IFNULL(SUM(importe),0) AS total FROM tm_ingresos_adm WHERE id_apc = {$data} AND estado='a'")
            ->fetch(PDO::FETCH_OBJ);

            $c->{'Egresos'} = $this->db->query("SELECT IFNULL(SUM(importe),0) AS total FROM tm_gastos_adm WHERE id_apc = {$data} AND (id_tipo_gasto = 1 OR id_tipo_gasto = 2 OR id_tipo_gasto = 3 OR id_tipo_gasto = 4) AND estado='a'")
            ->fetch(PDO::FETCH_OBJ);

            $c->{'EgresosA'} = $this->db->query("SELECT IFNULL(SUM(importe),0) AS total FROM tm_gastos_adm WHERE id_apc = {$data} AND id_tipo_gasto = 1 AND estado='a'")
            ->fetch(PDO::FETCH_OBJ);

            $c->{'EgresosB'} = $this->db->query("SELECT IFNULL(SUM(importe),0) AS total FROM tm_gastos_adm WHERE id_apc = {$data} AND id_tipo_gasto = 2 AND estado='a'")
            ->fetch(PDO::FETCH_OBJ);

            $c->{'EgresosC'} = $this->db->query("SELECT IFNULL(SUM(importe),0) AS total FROM tm_gastos_adm WHERE id_apc = {$data} AND id_tipo_gasto = 3 AND estado='a'")
            ->fetch(PDO::FETCH_OBJ);

            $c->{'EgresosD'} = $this->db->query("SELECT IFNULL(SUM(importe),0) AS total FROM tm_gastos_adm WHERE id_apc = {$data} AND id_tipo_gasto = 4 AND estado='a'")
            ->fetch(PDO::FETCH_OBJ);

            $c->{'Descuentos'} = $this->db->query("SELECT COUNT(id_venta) AS cant FROM tm_venta WHERE id_apc = {$data} AND descuento_monto > '0.00' AND estado <> 'i'")
            ->fetch(PDO::FETCH_OBJ);

            $c->{'ComisionDelivery'} = $this->db->query("SELECT COUNT(id_venta) AS cant FROM tm_venta WHERE id_apc = {$data} AND id_tipo_pedido = 3 AND estado <> 'i'")
            ->fetch(PDO::FETCH_OBJ);

            $c->{'Anulaciones'} = $this->db->query("SELECT COUNT(*) AS cant, SUM(tvp.cant_pago) total FROM tm_venta AS v
            JOIN tm_venta_pago AS tvp ON v.id_venta = tvp.id_venta WHERE v.estado = 'i' AND v.id_apc = {$data}"." GROUP BY tvp.id_venta" )
            ->fetch(PDO::FETCH_OBJ);

            /*$c->{'Deliverys'} = $this->db->query("SELECT SUM(IFNULL((v.pago_efe+v.pago_tar),0)) AS total, COUNT(*) AS cant FROM v_ventas_con AS v INNER JOIN tm_pedido_delivery AS d ON v.id_ped = d.id_pedido WHERE v.id_apc = {$data} AND v.estado = 'a'")
            ->fetch(PDO::FETCH_OBJ);*/

            $c->{'Detalle'} = $this->db->query("SELECT d.id_prod,SUM(d.cantidad) AS cantidad, d.precio FROM tm_venta AS v INNER JOIN tm_detalle_venta AS d ON v.id_venta = d.id_venta WHERE v.id_apc = {$data} AND v.estado = 'a' GROUP BY d.id_prod, d.precio ORDER BY 2 DESC")
                ->fetchAll(PDO::FETCH_OBJ);
            foreach($c->Detalle as $k => $d)
            {
                $c->Detalle[$k]->{'Producto'} = $this->db->query("SELECT cp.descripcion AS pro_cat,p.nombre AS pro_nom,pp.presentacion AS pro_pre
                FROM tm_producto_pres pp
                JOIN tm_producto p ON pp.id_prod = p.id_prod
                JOIN tm_producto_catg cp ON p.id_catg = cp.id_catg 
                WHERE pp.id_pres = " . $d->id_prod)
                    ->fetch(PDO::FETCH_OBJ);
            }

            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function finanza_adel_list_a($data)
    {
        try
        {
            $ifecha = date('Y-m-d H:i:s',strtotime($data['ifecha']));
            $ffecha = date('Y-m-d H:i:s',strtotime($data['ffecha']));
            $idemp=Session::get('idemp');

            $consulta = "call sp_get_gastosadm(:idemp,:idsede,:id_usu,:id_per,:id_tg,:estado,:idapc,:fechai,:fechaf);";
            $arrayParam =  array(
                ':idemp' => $idemp,
                ':idsede' => '%',
                ':id_usu' => '%',
                ':id_per' => $data['id_personal'],
                ':id_tg' => '3',
                ':estado' => 'a',
                ':idapc' => '%',
                ':fechai' => $ifecha,
                ':fechaf' => $ffecha
            );
            $st = $this->db->prepare($consulta);
            $st->execute($arrayParam);
            $c = $st->fetchAll(PDO::FETCH_OBJ);

            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function finanza_adel_list_b($data)
    {
        try
        {
            $ifecha = date('Y-m-d H:i:s',strtotime($data['ifecha']));
            $ffecha = date('Y-m-d H:i:s',strtotime($data['ffecha']));

            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            $id_personal = $data['id_personal']; 
            $consulta2 = "call sp_get_ventas_con(:idemp,:idsede,:fecha_i,:fecha_f,:id_vent,:id_cli);";
            $arrayParam2 =  array(
                ':idemp' => $idemp,
                ':idsede' => $idsede,
                ':fecha_i' => $ifecha,
                ':fecha_f' => $ffecha,
                ':id_vent' => '%',
                ':id_cli' => '%'
            );
            $stm = $this->db->prepare($consulta2);
            $stm->execute($arrayParam2);
            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $stm->closeCursor();

             //Reindexar el array filtrar por canal id personal, tipo de descuento, estado

             $c = array_values(array_filter($c, function ($finPer) use ($id_personal)  {
                $condicion1 = $id_personal == "%" || $finPer->desc_personal == $id_personal;
                $condicion2 = $finPer->desc_tipo == '3';
                $condicion3 = $finPer->estado == 'a';
                return $condicion1 && $condicion2 && $condicion3;
            }));

            foreach($c as $k => $d)
            {
            
                $c[$k]->{'total_venta'} = number_format($d->total + $d->comis_del  - $d->desc_monto, 2, '.', '');
                
            }

            $c = $stm->fetchAll(PDO::FETCH_OBJ);
            $data = array("data" => $c);
            $json = json_encode($data);
            echo $json; 
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    /* FIN MODULO FINANZAS */
   /* KARDEX VALORIZADO */
   public function kardex_list()
   {
       try
       {
           $idemp=Session::get('idemp');
           $idsede=Session::get('sede_id');
           $tipo_ip = $_POST['tipo_ip'];
           $id_ip = $_POST['id_ip'];
           $ifecha = date('Y-m-d',strtotime($_POST['ifecha']));
           $ffecha = date('Y-m-d',strtotime($_POST['ffecha']));
        //    $ed     = ($tipo_ip == '2') ? 'id_tipo_ins = "2"': 'id_tipo_ins = "1"' ;
           $stm = $this->db->prepare("SELECT id_inv,id_tipo_ope,id_ope,id_tipo_ins,id_ins,cos_uni,cant,fecha_r,estado,
                   IF(id_tipo_ope = 1 OR id_tipo_ope = 3,FORMAT(cant,6),0) AS cantidad_entrada, 
                   IF(id_tipo_ope = 1 OR id_tipo_ope = 3,cos_uni,0) AS costo_entrada, 
                   IF(id_tipo_ope = 1 OR id_tipo_ope = 3,(cant*cos_uni),0) AS total_entrada, 
                   IF(id_tipo_ope = 2 OR id_tipo_ope = 4,FORMAT(cant,6),0) AS cantidad_salida, 
                   IF(id_tipo_ope = 2 OR id_tipo_ope = 4,cos_uni,'-') AS costo_salida, 
                   IF(id_tipo_ope = 2 OR id_tipo_ope = 4,(cant*cos_uni),0) AS total_salida
               FROM tm_inventario WHERE idemp = ? AND idsede = ? AND id_ins = ? AND (date(fecha_r) >= ? AND date(fecha_r) <= ?)");
           $stm->execute(array($idemp,$idsede,$id_ip,$ifecha,$ffecha));
           $c = $stm->fetchAll(PDO::FETCH_OBJ);
           foreach($c as $k => $d)
           {
               $c[$k]->{'Precio'} = $this->db->query("SELECT ROUND(AVG(cos_uni),2) AS cos_pro FROM tm_inventario WHERE id_tipo_ins = ".$d->id_tipo_ins." AND id_ins = ".$d->id_ins)
                   ->fetch(PDO::FETCH_OBJ);

                if($d->id_tipo_ins == 1){
                    $c[$k]->{'Medida'} = $this->db->query("SELECT m.descripcion AS ins_med FROM tm_insumo i JOIN tm_tipo_medida m ON i.id_med = m.id_med WHERE id_ins = ".$d->id_ins)
                   ->fetch(PDO::FETCH_OBJ);
                }else{
                    $c[$k]->{'Medida'} = array("ins_med"=>"UNIDAD");
                }

                $consulta = "call sp_get_inventario(:idemp,:idsede,:id_ins,:id_tipo_ins);";
                $arrayParam =  array(
                    ':idemp' => $idemp,
                    ':idsede' => $idsede,
                    ':id_ins' => $id_ip,
                    ':id_tipo_ins' => $tipo_ip
                );
                $st = $this->db->prepare($consulta);
                $st->execute($arrayParam);

                $c[$k]->{'Stock'} = $st->fetch(PDO::FETCH_OBJ);
                $st->closeCursor();

               if($d->id_tipo_ope == 1){
                   $c[$k]->{'Comp'} = $this->db->query("SELECT c.serie_doc AS ser_doc,c.num_doc AS nro_doc,td.descripcion AS desc_td FROM tm_compra AS c JOIN tm_tipo_doc AS td ON c.id_tipo_doc = td.id_tipo_doc WHERE c.id_compra = ".$d->id_ope)
                   ->fetch(PDO::FETCH_OBJ);
               } else if($d->id_tipo_ope == 2){
                    $c[$k]->{'Comp'} = $this->db->query("SELECT v.serie_doc AS ser_doc,v.nro_doc,td.descripcion AS desc_td FROM tm_venta AS v JOIN tm_tipo_doc AS td ON v.id_tipo_doc = td.id_tipo_doc WHERE v.id_venta = ".$d->id_ope)
                    ->fetch(PDO::FETCH_OBJ);
               } else if($d->id_tipo_ope == 3 OR $d->id_tipo_ope == 4){
                   $c[$k]->{'Comp'} = $this->db->query("SELECT i.motivo, CONCAT(u.nombres,' ',u.ape_paterno,' ',u.ape_materno) AS responsable FROM tm_inventario_entsal AS i INNER JOIN tm_usuario AS u ON i.id_responsable = u.id_usu WHERE i.id_es = ".$d->id_ope)
                   ->fetch(PDO::FETCH_OBJ);
               }
           }
           
           $data = array("data" => $c);
           $json = json_encode($data);
           echo $json; 
       }
       catch(Exception $e)
       {
           die($e->getMessage());
       }
   }

   public function ComboInsumoProducto($data)
   {
       try
       {
        $idemp=Session::get('idemp');
        $consulta = "call sp_get_insprod(:idemp,:idsede,:id_tipo_ins,:id_ins,:cadena);";
        $arrayParam =  array(
            ':idemp' => $idemp,
            ':idsede' => '%',
            ':id_tipo_ins' => $data['id_tipo_ins'],
            ':id_ins' => '%',
            ':cadena'=>'%'
        );
        $st = $this->db->prepare($consulta);
        $st->execute($arrayParam);
        $var=$st->fetchAll(PDO::FETCH_ASSOC);

        $var = array_filter($var, function ($insprod) {
            return $insprod['est_b'] == 'a' && $insprod['est_c'] == 'a';
        });

        foreach($var as $v){
            echo '<option value="'.$v['id_ins'].'">'.$v['ins_cod'].' | '.$v['ins_cat'].' | '.$v['ins_nom'].'</option>';
        }
        
       }
       catch(Exception $e)
       {
           die($e->getMessage());
       }
   }



}