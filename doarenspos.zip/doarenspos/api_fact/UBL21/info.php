<?php 
echo phpinfo();