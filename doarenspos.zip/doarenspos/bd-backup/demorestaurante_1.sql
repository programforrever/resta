-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 02-05-2025 a las 21:19:01
-- Versión del servidor: 9.1.0
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `demorestaurante_1`
--

DELIMITER $$
--
-- Procedimientos
--
DROP PROCEDURE IF EXISTS `sp_actualizar_cdr_baja`$$
CREATE PROCEDURE `sp_actualizar_cdr_baja` (`p_id_comunicacion` INT, `p_hash_cpe` VARCHAR(100), `p_hash_cdr` VARCHAR(100), `p_code_respuesta_sunat` VARCHAR(5), `p_descripcion_sunat_cdr` VARCHAR(300), `p_name_file_sunat` VARCHAR(80), OUT `mensaje` VARCHAR(100))   BEGIN
	IF(NOT EXISTS(SELECT * FROM comunicacion_baja WHERE id_comunicacion=p_id_comunicacion))THEN
		SET mensaje='No existe la comunicación de baja';
	ELSE
		UPDATE comunicacion_baja SET enviado_sunat=1,hash_cpe=p_hash_cpe,hash_cdr=p_hash_cdr,code_respuesta_sunat=p_code_respuesta_sunat,descripcion_sunat_cdr=p_descripcion_sunat_cdr,name_file_sunat=p_name_file_sunat WHERE id_comunicacion=p_id_comunicacion;
		SET mensaje='Actualizado correctamente';
	END IF;
END$$

DROP PROCEDURE IF EXISTS `sp_actualizar_cdr_resumen`$$
CREATE PROCEDURE `sp_actualizar_cdr_resumen` (`p_id_resumen` INT, `p_hash_cpe` VARCHAR(100), `p_hash_cdr` VARCHAR(100), `p_code_respuesta_sunat` VARCHAR(5), `p_descripcion_sunat_cdr` VARCHAR(300), `p_name_file_sunat` VARCHAR(80), OUT `mensaje` VARCHAR(100))   BEGIN
	IF(NOT EXISTS(SELECT * FROM resumen_diario WHERE id_resumen=p_id_resumen))THEN
		SET mensaje='No existe el resumen diario';
	ELSE
		UPDATE resumen_diario SET enviado_sunat=1,hash_cpe=p_hash_cpe,hash_cdr=p_hash_cdr,code_respuesta_sunat=p_code_respuesta_sunat,descripcion_sunat_cdr=p_descripcion_sunat_cdr,name_file_sunat=p_name_file_sunat WHERE id_resumen=p_id_resumen;
		SET mensaje='Actualizado correctamente';
		
		block:BEGIN
		DECLARE done INT DEFAULT FALSE;
		DECLARE idven BIGINT;
		DECLARE venta CURSOR FOR SELECT dr.id_venta FROM resumen_diario AS rd INNER JOIN resumen_diario_detalle AS dr ON rd.id_resumen = dr.id_resumen WHERE dr.id_resumen = p_id_resumen;
		DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=TRUE;
		OPEN venta;
		
			read_loop: LOOP
			FETCH venta INTO idven;
				IF done THEN
					LEAVE read_loop;
				END IF;
				UPDATE tm_venta SET code_respuesta_sunat=p_code_respuesta_sunat,descripcion_sunat_cdr=p_descripcion_sunat_cdr,name_file_sunat=p_name_file_sunat,hash_cpe=p_hash_cpe,hash_cdr=p_hash_cdr WHERE id_venta = idven;
			END LOOP;
			
		CLOSE venta;
		END block;
	END IF;
    END$$

DROP PROCEDURE IF EXISTS `sp_cocina_de`$$
CREATE PROCEDURE `sp_cocina_de` (IN `_idemp` INT, IN `_idsede` INT, IN `_id_areap` INT, IN `_estado` VARCHAR(5))   BEGIN
	DECLARE _cod_areap varchar(10) DEFAULT 0;
	IF _id_areap = 0 THEN
		SET _cod_areap = "%";
	ELSE
		SET _cod_areap = _id_areap;
	END IF;

  SELECT 
		3 AS `tipo_atencion`, 
        `dp`.`id_pedido` AS `id_pedido`,
        `tpd`.`id_areap` AS `id_areap`,
        `tpd`.`id_tipo` AS `id_tipo`,
        `dp`.`id_pres` AS `id_pres`,
        IF(`dp`.`cantidad` < `dp`.`cant`,
            `dp`.`cant`,
            `dp`.`cantidad`) AS `cantidad`,
        `dp`.`comentario` AS `comentario`,
        `dp`.`fecha_pedido` AS `fecha_pedido`,
        `dp`.`fecha_envio` AS `fecha_envio`,
        `dp`.`estado` AS `estado`,
        `dp`.`detatopico` AS `detatopico`,
        `dp`.`idemp` AS `idemp`,
        `dp`.`idsede` AS `idsede`,
        0 AS `id_mesa`,
        0 AS `id_mozo`,
        `tpd`.`nombre` AS `nombre_prod`,
        `cp`.`descripcion` AS `pro_cat`,
        `tpp`.`presentacion` AS `pres_prod`,
		`pd`.`nro_pedido` AS `nro_mesa`,/**/
        'DELIVERY' AS `desc_salon`,
        /*`tp`.`id_usu` AS `id_usu`,*/
        `u`.`ape_paterno` AS `ape_paterno`,
        `u`.`ape_materno` AS `ape_materno`,
        `u`.`nombres` AS `nombres`,
        `tp`.`estado` AS `estado_pedido`
    FROM
        `tm_detalle_pedido` `dp`
        JOIN `tm_pedido_delivery` `pd` ON `dp`.`id_pedido` = `pd`.`id_pedido`
        JOIN `tm_pedido` `tp` ON `dp`.`id_pedido` = `tp`.`id_pedido`
        JOIN `tm_producto_pres` `tpp` ON `dp`.`id_pres` = `tpp`.`id_pres`
        JOIN `tm_producto` `tpd` ON `tpp`.`id_prod` = `tpd`.`id_prod`
        JOIN `tm_producto_catg` `cp` ON `tpd`.`id_catg` = `cp`.`id_catg`
        JOIN `tm_usuario` `u` ON `tp`.`id_usu` = `u`.`id_usu`
        WHERE `dp`.`idemp` = _idemp AND `dp`.`idsede`= _idsede AND `tpd`.`id_areap` LIKE _cod_areap AND
		CASE
			WHEN _estado = 'c' THEN dp.estado = 'c'
			WHEN _estado = '%' THEN dp.estado like '%'
			ELSE tp.estado <> 'd' AND tp.estado <> 'z' AND (dp.estado = 'a' OR dp.estado = 'b')
		END
         ORDER BY dp.fecha_pedido ASC;
END$$

DROP PROCEDURE IF EXISTS `sp_cocina_me`$$
CREATE PROCEDURE `sp_cocina_me` (IN `_idemp` INT, IN `_idsede` INT, IN `_id_areap` INT, IN `_estado` VARCHAR(5))   BEGIN
	DECLARE _cod_areap varchar(10) DEFAULT 0;
	IF _id_areap = 0 THEN
		SET _cod_areap = "%";
	ELSE
		SET _cod_areap = _id_areap;
	END IF;
    
SELECT 
		1 AS `tipo_atencion`, 
        `dp`.`id_pedido` AS `id_pedido`,
        `tpd`.`id_areap` AS `id_areap`,
        `tpd`.`id_tipo` AS `id_tipo`,
        `dp`.`id_pres` AS `id_pres`,
        `dp`.`cantidad` AS `cantidad`,
        `dp`.`comentario` AS `comentario`,
        `dp`.`fecha_pedido` AS `fecha_pedido`,
        `dp`.`fecha_envio` AS `fecha_envio`,
        `dp`.`estado` AS `estado`,
        `dp`.`detatopico` AS `detatopico`,
        `dp`.`idemp` AS `idemp`,
        `dp`.`idsede` AS `idsede`,
        `pm`.`id_mesa` AS `id_mesa`,
        `pm`.`id_mozo` AS `id_mozo`,
        `tpd`.`nombre` AS `nombre_prod`,
        `cp`.`descripcion` AS `pro_cat`,
        `tpp`.`presentacion` AS `pres_prod`,
        `tm`.`nro_mesa` AS `nro_mesa`,
        `ts`.`descripcion` AS `desc_salon`,
        `u`.`ape_paterno` AS `ape_paterno`,
        `u`.`ape_materno` AS `ape_materno`,
        `u`.`nombres` AS `nombres`,
        `tp`.`estado` AS `estado_pedido`
    FROM `tm_detalle_pedido` `dp`
        JOIN `tm_pedido_mesa` `pm` ON `dp`.`id_pedido` = `pm`.`id_pedido`
        JOIN `tm_pedido` `tp` ON `dp`.`id_pedido` = `tp`.`id_pedido`
        JOIN `tm_producto_pres` `tpp` ON `dp`.`id_pres` = `tpp`.`id_pres`
        JOIN `tm_producto` `tpd` ON `tpp`.`id_prod` = `tpd`.`id_prod`
        JOIN `tm_producto_catg` `cp` ON `tpd`.`id_catg` = `cp`.`id_catg`
        JOIN `tm_mesa` `tm` ON `pm`.`id_mesa` = `tm`.`id_mesa`
		JOIN `tm_salon` `ts` ON `tm`.`id_salon` = `ts`.`id_salon`
        JOIN `tm_usuario` `u` ON `pm`.`id_mozo` = `u`.`id_usu`
        WHERE `dp`.`idemp` = _idemp AND `dp`.`idsede`= _idsede AND `tpd`.`id_areap` LIKE _cod_areap AND
        CASE
        WHEN _estado = 'c' THEN dp.estado = 'c'/*pedidos preparados en produccion*/
        WHEN _estado = '%' THEN dp.estado like '%'/*todos*/
        ELSE tp.estado <> 'd' AND tp.estado <> 'z' AND (dp.estado = 'a' OR dp.estado = 'b') /*lista de pedidos en espera a preparar*/
		END
        ORDER BY dp.fecha_pedido ASC;
END$$

DROP PROCEDURE IF EXISTS `sp_cocina_mo`$$
CREATE PROCEDURE `sp_cocina_mo` (IN `_idemp` INT, IN `_idsede` INT, IN `_id_areap` INT, IN `_estado` VARCHAR(5))   BEGIN
	DECLARE _cod_areap varchar(10) DEFAULT 0;
	IF _id_areap = 0 THEN
		SET _cod_areap = "%";
	ELSE
		SET _cod_areap = _id_areap;
	END IF;
SELECT 
		2 AS `tipo_atencion`, 
        `dp`.`id_pedido` AS `id_pedido`,
        `tpd`.`id_areap` AS `id_areap`,
        `tpd`.`id_tipo` AS `id_tipo`,
        `dp`.`id_pres` AS `id_pres`,
        IF(`dp`.`cantidad` < `dp`.`cant`,
            `dp`.`cant`,
            `dp`.`cantidad`) AS `cantidad`,
        `dp`.`comentario` AS `comentario`,
        `dp`.`fecha_pedido` AS `fecha_pedido`,
        `dp`.`fecha_envio` AS `fecha_envio`,
        `dp`.`estado` AS `estado`,
        `dp`.`detatopico` AS `detatopico`,
        `dp`.`idemp` AS `idemp`,
        `dp`.`idsede` AS `idsede`,
        0 AS `id_mesa`,
        0 AS `id_mozo`,
        `tpd`.`nombre` AS `nombre_prod`,
		`cp`.`descripcion` AS `pro_cat`,
		`tpp`.`presentacion` AS `pres_prod`,
        `pm`.`nro_pedido` AS `nro_mesa`,
        'PARA LLEVAR' AS `desc_salon`,
        `u`.`ape_paterno` AS `ape_paterno`,
        `u`.`ape_materno` AS `ape_materno`,
        `u`.`nombres` AS `nombres`,
        `tp`.`estado` AS `estado_pedido`
    FROM
        `tm_detalle_pedido` `dp`
        JOIN `tm_pedido_llevar` `pm` ON `dp`.`id_pedido` = `pm`.`id_pedido`
        JOIN `tm_pedido` `tp` ON `dp`.`id_pedido` = `tp`.`id_pedido`
        JOIN `tm_producto_pres` `tpp` ON `dp`.`id_pres` = `tpp`.`id_pres`
        JOIN `tm_producto` `tpd` ON `tpp`.`id_prod` = `tpd`.`id_prod`
        JOIN `tm_producto_catg` `cp` ON `tpd`.`id_catg` = `cp`.`id_catg`
        JOIN `tm_usuario` `u` ON `tp`.`id_usu` = `u`.`id_usu`
        WHERE `dp`.`idemp` = _idemp AND `dp`.`idsede`= _idsede AND `tpd`.`id_areap` LIKE _cod_areap AND
		CASE
			WHEN _estado = 'c' THEN dp.estado = 'c'/*pedidos preparados en produccion*/
			WHEN _estado = '%' THEN dp.estado like '%'/*todos*/
			ELSE tp.estado <> 'd' AND tp.estado <> 'z' AND (dp.estado = 'a' OR dp.estado = 'b') /*lista de pedidos en espera a preparar*/
		END
		 
        ORDER BY dp.fecha_pedido ASC;
END$$

DROP PROCEDURE IF EXISTS `sp_consultar_boletas_resumen`$$
CREATE PROCEDURE `sp_consultar_boletas_resumen` (`p_fecha_resumen` DATE)   BEGIN
	SELECT
		'03' AS 'tipo_comprobante',DATE_FORMAT(v.fecha_venta,'%Y-%m-%d') AS 'fecha_resumen',IF(c.dni="" OR c.dni="-",0,1) AS 'tipo_documento',
		IF(c.dni="" OR c.dni="-","00000000",c.dni) AS "dni",CONCAT(c.nombres," ",c.ape_paterno," ",c.ape_materno) AS 'cliente',v.serie_doc AS 'serie_doc',
		v.nro_doc AS 'nro_doc',"PEN" AS 'tipo_moneda',ROUND((v.total/(1 + v.igv)) *(v.igv),2) AS 'total_igv',
		ROUND((v.total/(1 + v.igv)),2) AS 'total_gravadas',ROUND(v.total,2) AS 'total_facturado',IF(v.estado="a",1,3) AS 'status_code',v.id_venta
	FROM tm_venta v INNER JOIN tm_cliente c ON c.id_cliente=v.id_cliente
	WHERE v.id_tipo_doc=1 AND v.code_respuesta_sunat="" AND DATE_FORMAT(v.fecha_venta,"%Y-%m-%d") = p_fecha_resumen
	ORDER BY v.fecha_venta ASC;
    END$$

DROP PROCEDURE IF EXISTS `sp_consultar_documento`$$
CREATE PROCEDURE `sp_consultar_documento` (`p_id_venta` INT)   BEGIN
	SELECT
		IF(id_tipo_doc='1','03','01') AS tipo_comprobante, IF(c.dni="" OR c.dni="-",0,1) AS 'tipo_documento',
		IF(c.dni="" OR c.dni="-","00000000",c.dni) AS "dni",v.serie_doc AS 'serie_doc', v.nro_doc AS 'nro_doc',"PEN" AS 'tipo_moneda',ROUND((v.total/(1 + v.igv)) *(v.igv),2) AS 'total_igv',
		ROUND((v.total/(1 + v.igv)),2) AS 'total_gravadas',ROUND(v.total,2) AS 'total_facturado',v.id_venta, v.estado
	FROM tm_venta v INNER JOIN tm_cliente c ON c.id_cliente=v.id_cliente
	WHERE v.id_venta = p_id_venta;
    END$$

DROP PROCEDURE IF EXISTS `sp_generar_numerobaja`$$
CREATE PROCEDURE `sp_generar_numerobaja` (`p_tipo_doc` CHAR(3), OUT `numerobaja` CHAR(5))   BEGIN
	DECLARE contador INT;
	IF(NOT EXISTS(SELECT * FROM comunicacion_baja WHERE tipo_doc = p_tipo_doc))THEN
		SET contador:= (SELECT IFNULL(MAX(correlativo), 0)+1 AS 'codigo' FROM comunicacion_baja WHERE tipo_doc = p_tipo_doc);
		SET numerobaja:= (SELECT LPAD(contador,5,'0') AS 'correlativo');
	ELSE		
		SET contador:= (SELECT IFNULL(MAX(correlativo), 0)+1 AS 'codigo' FROM comunicacion_baja WHERE tipo_doc = p_tipo_doc);
		SET numerobaja:= (SELECT LPAD(contador,5,'0') AS 'correlativo');
	END IF;
END$$

DROP PROCEDURE IF EXISTS `sp_generar_numeroresumen`$$
CREATE PROCEDURE `sp_generar_numeroresumen` (OUT `numeroresumen` CHAR(5))   BEGIN
	DECLARE contador INT;
	IF(NOT EXISTS(SELECT * FROM resumen_diario))THEN
		SET contador:= (SELECT IFNULL(MAX(correlativo), 0)+1 AS 'codigo' FROM resumen_diario);
		SET numeroresumen:= (SELECT LPAD(contador,5,'0') AS 'correlativo');
	ELSE		
		SET contador:= (SELECT IFNULL(MAX(correlativo), 0)+1 AS 'codigo' FROM resumen_diario);
		SET numeroresumen:= (SELECT LPAD(contador,5,'0') AS 'correlativo');
	END IF;
    END$$

DROP PROCEDURE IF EXISTS `sp_get_caja_aper`$$
CREATE PROCEDURE `sp_get_caja_aper` (IN `_idemp` INT, IN `_idsede` VARCHAR(10), IN `_id_usu` VARCHAR(10), IN `_id_apc` VARCHAR(10), IN `_fecha_i` VARCHAR(20), IN `_fecha_f` VARCHAR(20), IN `_estado` VARCHAR(10))   BEGIN
	DECLARE _cod0 INT DEFAULT 0;
    DECLARE _fecha_inicio DATE;
    DECLARE _fecha_fin DATE;
    IF _fecha_i = '%' THEN
		SET _cod0 = 1;
	ELSE
		SET _cod0 = 2;
        SET _fecha_inicio = _fecha_i;
		SET _fecha_fin =  _fecha_f;
	END IF;

	  SELECT 
        apc.id_apc AS id_apc,
        apc.id_usu AS id_usu,
        apc.id_caja AS id_caja,
        apc.id_turno AS id_turno,
        apc.fecha_aper AS fecha_aper,
        apc.monto_aper AS monto_aper,
        apc.fecha_cierre AS fecha_cierre,
        apc.monto_cierre AS monto_cierre,
        apc.monto_sistema AS monto_sistema,
        apc.estado AS estado,
        apc.idemp AS idemp,
        apc.idsede AS idsede,
        CONCAT(tp.nombres,' ',tp.ape_paterno,' ',tp.ape_materno) AS desc_per,
        tc.descripcion AS desc_caja,
        tt.descripcion AS desc_turno
    FROM
        tm_aper_cierre apc
        JOIN tm_usuario tp ON apc.id_usu = tp.id_usu
        JOIN tm_caja tc ON apc.id_caja = tc.id_caja
        JOIN tm_turno tt ON apc.id_turno = tt.id_turno
        WHERE apc.idemp = _idemp AND apc.idsede LIKE _idsede AND apc.id_usu LIKE _id_usu AND apc.id_apc LIKE _id_apc AND apc.estado LIKE _estado 
        AND  CASE
        WHEN _cod0 = 2 THEN ((DATE_FORMAT(apc.fecha_aper ,'%Y-%m-%d')) >= _fecha_inicio AND (DATE_FORMAT(apc.fecha_aper ,'%Y-%m-%d')) <= _fecha_fin)
        ELSE _cod0 <> 0
        END
    ORDER BY apc.id_apc DESC;

END$$

DROP PROCEDURE IF EXISTS `sp_get_clientes`$$
CREATE PROCEDURE `sp_get_clientes` (IN `_idemp` INT, IN `_id_cliente` VARCHAR(15), IN `_tipo_cliente` VARCHAR(10), IN `_estado` VARCHAR(10), IN `_buscar` VARCHAR(100))   BEGIN
	SELECT tc.id_cliente AS id_cliente,tc.tipo_cliente AS tipo_cliente,tc.dni AS dni,tc.ruc AS ruc,
	CASE
		WHEN tc.tipo_cliente = 1 THEN tc.nombres
		WHEN tc.tipo_cliente = 2 THEN tc.razon_social
	END AS nombrecliente,
	tc.telefono AS telefono,tc.fecha_nac AS fecha_nac,
	tc.direccion AS direccion,tc.referencia AS referencia,
	tc.estado AS estado,tc.idemp AS idemp  FROM tm_cliente AS tc
	WHERE tc.id_cliente <> 1 AND tc.idemp = _idemp AND tc.id_cliente LIKE _id_cliente 
    AND tc.tipo_cliente LIKE _tipo_cliente AND tc.estado LIKE _estado AND
	(tc.dni LIKE _buscar OR tc.ruc LIKE _buscar OR CASE
		WHEN tc.tipo_cliente = 1 THEN tc.nombres LIKE _buscar
		WHEN tc.tipo_cliente = 2 THEN tc.razon_social LIKE _buscar
		ELSE tc.nombres LIKE _buscar
	END OR tc.telefono LIKE _buscar)
	ORDER BY tc.id_cliente DESC;
END$$

DROP PROCEDURE IF EXISTS `sp_get_compras`$$
CREATE PROCEDURE `sp_get_compras` (IN `_idemp` INT, IN `_idsede` VARCHAR(10), IN `_id_tipo_compra` VARCHAR(10), IN `_id_prov` VARCHAR(10), IN `_id_tipo_doc` VARCHAR(10), IN `_fecha_i` DATE, IN `_fecha_f` DATE, IN `_estado` VARCHAR(10))   BEGIN
	SELECT c.id_compra AS id_compra,
        c.id_prov AS id_prov,
        c.id_tipo_compra AS id_tipo_compra,
        c.id_tipo_doc AS id_tipo_doc,
        c.fecha_c AS fecha_c,
        c.fecha_reg AS fecha_r,
        c.hora_c AS hora_c,
        c.serie_doc AS serie_doc,
        c.num_doc AS num_doc,
        c.igv AS igv,
        c.total AS total,
        c.estado AS estado,
        c.idemp AS idemp,
        c.idsede AS idsede,
        tc.descripcion AS desc_tc,
        td.descripcion AS desc_td,
        tp.razon_social AS desc_prov
	FROM tm_compra c
			JOIN tm_tipo_compra tc ON c.id_tipo_compra = tc.id_tipo_compra
			JOIN tm_tipo_doc td ON c.id_tipo_doc = td.id_tipo_doc
			JOIN tm_proveedor tp ON c.id_prov = tp.id_prov
	WHERE c.id_compra <> 0 AND ((DATE_FORMAT(c.fecha_reg,'%Y-%m-%d')) >= _fecha_i AND (DATE_FORMAT(c.fecha_reg,'%Y-%m-%d')) <= _fecha_f) 
	AND c.idemp = _idemp AND c.idsede LIKE _idsede AND c.id_tipo_compra LIKE _id_tipo_compra AND c.id_prov LIKE _id_prov AND c.id_tipo_doc LIKE _id_tipo_doc AND c.estado LIKE _estado 
	ORDER BY c.id_compra DESC;

END$$

DROP PROCEDURE IF EXISTS `sp_get_gastosadm`$$
CREATE PROCEDURE `sp_get_gastosadm` (IN `_idemp` INT, IN `_idsede` VARCHAR(10), IN `_id_usu` VARCHAR(10), IN `_id_per` VARCHAR(10), IN `_id_tg` VARCHAR(10), IN `_estado` VARCHAR(10), IN `_id_apc` VARCHAR(10), IN `_fecha_i` VARCHAR(20), IN `_fecha_f` VARCHAR(20))   BEGIN
	DECLARE _cod0 INT DEFAULT 0;
    DECLARE _cod1 INT DEFAULT 0;
    DECLARE _fecha_inicio DATE;
    DECLARE _fecha_fin DATE;
    IF _fecha_i = '%' THEN
		SET _cod0 = 1;
	ELSE
		SET _cod0 = 2;
        SET _fecha_inicio = _fecha_i;
		SET _fecha_fin =  _fecha_f;
	END IF;
    
	  SELECT 
        ga.id_ga AS id_ga,
        ga.id_tipo_gasto AS id_tg,
        COALESCE(ga.id_per, '0') AS id_per,
        ga.id_usu AS id_usu,
        ga.id_apc AS id_apc,
        ga.importe AS importe,
        ga.responsable AS responsable,
        ga.motivo AS motivo,
        ga.fecha_registro AS fecha_re,
        ga.estado AS estado,
        ga.idemp AS idemp,
        ga.idsede AS idsede,
        tg.descripcion AS des_tg
    FROM tm_gastos_adm ga
        JOIN tm_tipo_gasto tg ON ga.id_tipo_gasto = tg.id_tipo_gasto

    WHERE
        ga.id_ga <> 0 AND ga.id_usu LIKE _id_usu AND COALESCE(ga.id_per, '0') LIKE _id_per AND ga.id_tipo_gasto LIKE _id_tg AND  ga.estado like _estado AND ga.idemp = _idemp AND ga.idsede LIKE _idsede AND ga.id_apc LIKE _id_apc 
        AND  CASE
        WHEN _cod0 = 2 THEN ((DATE_FORMAT(ga.fecha_registro,'%Y-%m-%d')) >= _fecha_inicio AND (DATE_FORMAT(ga.fecha_registro,'%Y-%m-%d')) <= _fecha_fin)
        ELSE _cod0 <> 0
        END
    ORDER BY ga.id_ga DESC;

END$$

DROP PROCEDURE IF EXISTS `sp_get_insprod`$$
CREATE PROCEDURE `sp_get_insprod` (IN `_idemp` INT, IN `_idsede` VARCHAR(10), IN `_id_tipo_ins` VARCHAR(10), IN `_id_ins` VARCHAR(10), IN `_cadena` VARCHAR(60))   BEGIN
	DROP TEMPORARY TABLE IF EXISTS TempInsumos;
	DROP TEMPORARY TABLE IF EXISTS TempProducto;
	CREATE TEMPORARY TABLE TempInsumos (
		id_tipo_ins INT,
		id_ins INT,
        id_med INT,
        id_gru INT,
        ins_cod VARCHAR(10),
        ins_nom VARCHAR(50),
        ins_cat VARCHAR(50),
        ins_med VARCHAR(50),
        ins_rec INT ,
        ins_cos DECIMAL(10,2),
        ins_sto INT,
        id_areap INT,
        est_a VARCHAR(5),
        est_b VARCHAR(5),
		est_c VARCHAR(5),
        crt_stock INT,
        idemp INT
	);

	INSERT INTO TempInsumos (id_tipo_ins, id_ins,id_med,id_gru,ins_cod,ins_nom,ins_cat,ins_med,ins_rec,ins_cos,ins_sto,id_areap,est_a,est_b,
    est_c,crt_stock,idemp)SELECT 1 AS id_tipo_ins,
        i.id_ins,
        i.id_med,
        m.grupo AS id_gru,
        i.cod_ins AS ins_cod,
        i.nomb_ins AS ins_nom,
        ic.descripcion AS ins_cat,
        m.descripcion AS ins_med,
        1 AS ins_rec,
        i.cos_uni AS ins_cos,
        i.stock_min AS ins_sto,
        '0' AS id_areap,
        i.estado AS est_a,
        'a' AS est_b,
        'a' AS est_c,
        0 AS crt_stock,
        i.idemp
    FROM tm_insumo AS i
    JOIN tm_insumo_catg AS ic ON (i.id_catg = ic.id_catg)
	JOIN tm_tipo_medida AS m ON (i.id_med = m.id_med)
    WHERE i.idemp=_idemp;
        
    DROP TEMPORARY TABLE IF EXISTS TempProducto;
	CREATE TEMPORARY TABLE TempProducto(
		id_tipo_ins INT,
		id_ins INT,
        id_med INT,
        id_gru INT,
        ins_cod VARCHAR(10),
        ins_nom VARCHAR(50),
        ins_cat VARCHAR(50),
        ins_med VARCHAR(50),
        ins_rec INT ,
        ins_cos DECIMAL(10,2),
        ins_sto INT,
        id_areap INT,
        est_a VARCHAR(5),
        est_b VARCHAR(5),
		est_c VARCHAR(5),
        crt_stock INT,
        idemp INT
	);
    
	INSERT INTO TempProducto (id_tipo_ins, id_ins,id_med,id_gru,ins_cod,ins_nom,ins_cat,ins_med,ins_rec,ins_cos,ins_sto,id_areap,est_a,est_b,
    est_c,crt_stock,idemp)SELECT 
        2 AS id_tipo_ins,
         pp.id_pres,
        '1' AS id_med,
        '1' AS id_gru,
        pp.cod_prod AS pro_cod,
        CONCAT(p.nombre , ' ', pp.presentacion) AS pro_nom,
        cp.descripcion AS pro_cat,
        'UNIDAD' AS ins_med,
        pp.receta AS pro_rec,
        pp.precio AS pro_cos,
        pp.stock_min AS pro_sto,
        p.id_areap AS id_areap,
        cp.estado AS est_a,
        p.estado AS est_b,
        pp.estado AS est_c,
        pp.crt_stock ,
        pp.idemp 
    FROM tm_producto_pres pp
        JOIN tm_producto p ON pp.id_prod = p.id_prod
        JOIN tm_producto_catg cp ON p.id_catg = cp.id_catg
    WHERE pp.id_pres <> 0 AND p.id_tipo = 2 AND p.id_catg <> 1 AND pp.idemp = _idemp;
    
    
    INSERT INTO TempProducto (id_tipo_ins, id_ins,id_med,id_gru,ins_cod,ins_nom,ins_cat,ins_med,ins_rec,ins_cos,ins_sto,id_areap,est_a,est_b,
    est_c,crt_stock,idemp) SELECT 
        3 AS id_tipo_ins,
         pp.id_pres,
        '1' AS id_med,
        '1' AS id_gru,
        pp.cod_prod AS pro_cod,
        CONCAT(p.nombre , ' ', pp.presentacion) AS pro_nom,
        cp.descripcion AS pro_cat,
        'UNIDAD' AS ins_med,
        pp.receta AS pro_rec,
        pp.precio AS pro_cos,
        pp.stock_min AS pro_sto,
        p.id_areap AS id_areap,
        cp.estado AS est_a,
        p.estado AS est_b,
        pp.estado AS est_c,
        pp.crt_stock ,
        pp.idemp 
    FROM tm_producto_pres pp
        JOIN tm_producto p ON pp.id_prod = p.id_prod
        JOIN tm_producto_catg cp ON p.id_catg = cp.id_catg
    WHERE pp.id_pres <> 0 AND p.id_tipo = 1 AND p.id_catg <> 1 AND pp.idemp = _idemp;
    

	SELECT * FROM TempInsumos WHERE id_tipo_ins LIKE _id_tipo_ins AND id_ins LIKE _id_ins AND (ins_nom LIKE _cadena OR ins_cod LIKE _cadena)
    UNION SELECT * FROM TempProducto WHERE id_tipo_ins LIKE _id_tipo_ins AND id_ins LIKE _id_ins AND (ins_nom LIKE _cadena OR ins_cod LIKE _cadena);

END$$

DROP PROCEDURE IF EXISTS `sp_get_inventario`$$
CREATE PROCEDURE `sp_get_inventario` (IN `_idemp` INT, IN `_idsede` INT, IN `_id_ins` VARCHAR(10), IN `_id_tipo_ins` VARCHAR(10))   BEGIN

	DROP TEMPORARY TABLE IF EXISTS TempVInventario;
    /**LLENANDO TABLA TEMPORAL INVENTARIO POR EMPRESA Y SEDE**/
	CREATE TEMPORARY TABLE TempVInventario(
		id_tipo_ins INT,
		id_ins INT,
        ent FLOAT,
        sal FLOAT,
        idemp INT,
        idsede INT
	);
    
	INSERT INTO TempVInventario(id_tipo_ins,id_ins,ent,sal,idemp,idsede)SELECT id_tipo_ins,id_ins, IF(id_tipo_ope = 1 OR id_tipo_ope = 3,SUM(cant),0) AS ent, 0 AS sal,
        idemp AS idemp,idsede AS idsede FROM tm_inventario
    WHERE id_tipo_ope <> 2 AND id_tipo_ope <> 4 AND estado <> 'i' AND idemp = _idemp AND idsede = _idsede
    GROUP BY id_tipo_ins , id_ins , idsede;
    
    INSERT INTO TempVInventario(id_tipo_ins,id_ins,ent,sal,idemp,idsede)SELECT id_tipo_ins,id_ins,0 AS ent,
        IF(id_tipo_ope = 2 OR id_tipo_ope = 4,SUM(cant),0) AS sal,
        idemp AS idemp,idsede AS idsede
    FROM tm_inventario
    WHERE id_tipo_ope <> 1 AND id_tipo_ope <> 3 AND estado <> 'i' AND idemp = _idemp AND idsede = _idsede
    GROUP BY id_tipo_ins , id_ins , idsede;
    
    
     SELECT id_tipo_ins, id_ins,SUM(ent) AS ent, SUM(sal) AS sal, idemp,idsede FROM TempVInventario 
	 WHERE id_ins LIKE _id_ins AND id_tipo_ins LIKE _id_tipo_ins
	 GROUP BY id_tipo_ins, id_ins;
    
END$$

DROP PROCEDURE IF EXISTS `sp_get_listar_mesas`$$
CREATE PROCEDURE `sp_get_listar_mesas` (IN `_idemp` INT, IN `_idsede` INT)   BEGIN
	DROP TEMPORARY TABLE IF EXISTS TempPedidoMesa;
	DROP TEMPORARY TABLE IF EXISTS TempMesas;
	CREATE TEMPORARY TABLE TempMesas (
		id_mesa INT PRIMARY KEY,
		id_salon INT,
        nro_mesa VARCHAR(5),
        estado VARCHAR(5),
		desc_salon VARCHAR(45)
	);
	INSERT INTO TempMesas (id_mesa, id_salon,nro_mesa,estado,desc_salon)SELECT 
        m.id_mesa,
        m.id_salon,
        m.nro_mesa,
        m.estado,
        cm.descripcion
	FROM tm_mesa AS m
	JOIN tm_salon AS cm ON m.id_salon = cm.id_salon
	WHERE m.id_mesa <> 0 AND cm.estado <> 'i' AND m.idemp = _idemp AND m.idsede = _idsede
	ORDER BY m.id_mesa;
    
    
    DROP TEMPORARY TABLE IF EXISTS TempPedidoMesa;
	CREATE TEMPORARY TABLE TempPedidoMesa (
		id_pedido INT PRIMARY KEY,
		id_mesa INT,
        fecha_pedido DATETIME,
        nro_personas INT,
		nombre_mozo VARCHAR(100),
        total DECIMAL(10,2),
        preciotopi DECIMAL(10,2)
	);
    
	INSERT INTO TempPedidoMesa (id_pedido, id_mesa,fecha_pedido,nro_personas,nombre_mozo,total,preciotopi)SELECT 
        p.id_pedido,
        pm.id_mesa,
        p.fecha_pedido,
        pm.nro_personas,
        CONCAT(u.nombres, ' ', u.ape_paterno) AS nombre_mozo,
        SUM(IF(tdp.estado <> 'z',tdp.precio*tdp.cant,0)) AS total,
        SUM(IF(tdp.estado <> 'z',tdp.precioTopico,0)) AS preciotopi
    FROM tm_pedido p
        JOIN tm_pedido_mesa pm ON p.id_pedido = pm.id_pedido
        LEFT JOIN tm_detalle_pedido tdp on p.id_pedido = tdp.id_pedido
        JOIN tm_usuario u ON pm.id_mozo = u.id_usu
    WHERE
        p.id_pedido <> 0 AND p.estado = 'a' AND p.idemp = _idemp AND p.idsede = _idsede
	GROUP BY pm.id_mesa,p.id_pedido
    ORDER BY p.id_pedido DESC;
    
    SELECT tm.id_mesa,tm.id_salon,tm.nro_mesa,tm.estado,tm.desc_salon,tpm.id_pedido,tpm.fecha_pedido,tpm.nro_personas,tpm.nombre_mozo,tpm.total,tpm.preciotopi FROM TempMesas as tm
	LEFT JOIN TempPedidoMesa as tpm ON tm.id_mesa = tpm.id_mesa
    ORDER BY tm.id_mesa ASC;

END$$

DROP PROCEDURE IF EXISTS `sp_get_listaTopico`$$
CREATE PROCEDURE `sp_get_listaTopico` (IN `_idemp` INT, IN `_id_pres` INT)   BEGIN
	set @idProd =(select id_prod from tm_producto_pres where id_pres = _id_pres);
	select tp.id_prod, _id_pres, tt.id_topicos, t.nombre, t.precio,t.estado from tm_producto tp 
	inner join tm_produc_topicos tt on tp.id_prod = tt.id_producto
	inner join tm_topicos t on tt.id_topicos = t.id_topicos where tp.idemp = _idemp AND tp.id_prod = @idProd and t.estado = "a";

END$$

DROP PROCEDURE IF EXISTS `sp_get_stock`$$
CREATE PROCEDURE `sp_get_stock` (IN `_idemp` INT, IN `_idsede` INT, IN `_id_ins` VARCHAR(10), IN `_id_tipo_ins` VARCHAR(10))   BEGIN

	DROP TEMPORARY TABLE IF EXISTS TempInventario;
	DROP TEMPORARY TABLE IF EXISTS TempInsprod;
    /**LLENANDO LA TABLA TEMPORAL INVENTARIO POR EMPRESA Y SEDE**/
	CREATE TEMPORARY TABLE TempInventario(
		id_tipo_ins INT,
		id_ins INT,
        ent FLOAT,
        sal FLOAT,
        idemp INT,
        idsede INT
	);
    
	INSERT INTO TempInventario(id_tipo_ins,id_ins,ent,sal,idemp,idsede)SELECT id_tipo_ins,id_ins, IF(id_tipo_ope = 1 OR id_tipo_ope = 3,SUM(cant),0) AS ent, 0 AS sal,
        idemp AS idemp,idsede AS idsede FROM tm_inventario
    WHERE id_tipo_ope <> 2 AND id_tipo_ope <> 4 AND estado <> 'i' AND idemp = _idemp AND idsede = _idsede
    GROUP BY id_tipo_ins , id_ins , idsede;
    
    INSERT INTO TempInventario(id_tipo_ins,id_ins,ent,sal,idemp,idsede)SELECT id_tipo_ins,id_ins,0 AS ent,
        IF(id_tipo_ope = 2 OR id_tipo_ope = 4,SUM(cant),0) AS sal,
        idemp AS idemp,idsede AS idsede
    FROM tm_inventario
    WHERE id_tipo_ope <> 1 AND id_tipo_ope <> 3 AND estado <> 'i' AND idemp = _idemp AND idsede = _idsede
    GROUP BY id_tipo_ins , id_ins , idsede;
    
    /**LLENANDO TABLA TEMPORAL INSUMOS PRODUCTOS POR EMPRESA**/
	CREATE TEMPORARY TABLE TempInsprod (
		id_tipo_ins INT,
		id_ins INT,
        id_med INT,--





        id_gru INT,--





        ins_cod VARCHAR(10),--





        ins_nom VARCHAR(50),
        ins_cat VARCHAR(50),
        ins_med VARCHAR(50),--





        ins_rec INT ,
        ins_cos DECIMAL(10,2),
        ins_sto INT,
        est_a VARCHAR(5),
        est_b VARCHAR(5),
		est_c VARCHAR(5),
        crt_stock INT,
        idemp INT
	);

	INSERT INTO TempInsprod (id_tipo_ins, id_ins,id_med,id_gru,ins_cod,ins_nom,ins_cat,ins_med,ins_rec,ins_cos,ins_sto ,est_a,est_b,
    est_c,crt_stock,idemp)SELECT 1 AS id_tipo_ins,
        i.id_ins,
        i.id_med,
        m.grupo AS id_gru,
        i.cod_ins AS ins_cod,
        i.nomb_ins AS ins_nom,
        ic.descripcion AS ins_cat,
        m.descripcion AS ins_med,
        1 AS ins_rec,
        i.cos_uni AS ins_cos,
        i.stock_min AS ins_sto,
        i.estado AS est_a,
        'a' AS est_b,
        'a' AS est_c,
        0 AS crt_stock,
        i.idemp
    FROM tm_insumo AS i
    JOIN tm_insumo_catg AS ic ON (i.id_catg = ic.id_catg)
	JOIN tm_tipo_medida AS m ON (i.id_med = m.id_med)
    WHERE i.idemp=_idemp;
        
	INSERT INTO TempInsprod (id_tipo_ins, id_ins,id_med,id_gru,ins_cod,ins_nom,ins_cat,ins_med,ins_rec,ins_cos,ins_sto ,est_a,est_b,
    est_c,crt_stock,idemp)SELECT 
        2 AS id_tipo_ins,
         pp.id_pres,
        '1' AS id_med,
        '1' AS id_gru,
        pp.cod_prod AS pro_cod,
        CONCAT(p.nombre , ' ', pp.presentacion) AS pro_nom,
        cp.descripcion AS pro_cat,
        'UNIDAD' AS ins_med,
        pp.receta AS pro_rec,
        pp.precio AS pro_cos,
        pp.stock_min AS pro_sto,
        cp.estado AS est_a,
        p.estado AS est_b,
        pp.estado AS est_c,
        pp.crt_stock ,
        pp.idemp 
    FROM tm_producto_pres pp
        JOIN tm_producto p ON pp.id_prod = p.id_prod
        JOIN tm_producto_catg cp ON p.id_catg = cp.id_catg
    WHERE pp.id_pres <> 0 AND p.id_tipo = 2 AND p.id_catg <> 1 AND pp.idemp = _idemp;
    
    
    INSERT INTO TempInsprod (id_tipo_ins, id_ins,id_med,id_gru,ins_cod,ins_nom,ins_cat,ins_med,ins_rec,ins_cos,ins_sto ,est_a,est_b,
    est_c,crt_stock,idemp) SELECT 
        3 AS id_tipo_ins,
         pp.id_pres,
        '1' AS id_med,
        '1' AS id_gru,
        pp.cod_prod AS pro_cod,
        CONCAT(p.nombre , ' ', pp.presentacion) AS pro_nom,
        cp.descripcion AS pro_cat,
        'UNIDAD' AS ins_med,
        pp.receta AS pro_rec,
        pp.precio AS pro_cos,
        pp.stock_min AS pro_sto,
        cp.estado AS est_a,
        p.estado AS est_b,
        pp.estado AS est_c,
        pp.crt_stock ,
        pp.idemp 
    FROM tm_producto_pres pp
        JOIN tm_producto p ON pp.id_prod = p.id_prod
        JOIN tm_producto_catg cp ON p.id_catg = cp.id_catg
    WHERE pp.id_pres <> 0 AND p.id_tipo = 1 AND p.id_catg <> 1 AND pp.idemp = _idemp;
    
	/****SELECT STOCK****/

	SELECT 
        a.id_tipo_ins AS id_tipo_ins,
        a.id_ins AS id_ins,
        SUM(a.ent) AS ent,
        SUM(a.sal) AS sal,
        b.ins_sto as ins_sto,
        a.idemp AS idemp,
        a.idsede AS idsede,
        b.ins_cod AS ins_cod,
		b.ins_nom AS ins_nom,
        b.ins_cat AS ins_cat,
        b.ins_med AS ins_med,
        b.ins_sto AS ins_sto,
        b.est_a AS est_a,
        b.est_b AS est_b,
        IF(SUM(a.ent) - SUM(a.sal) > b.ins_sto,
            1,
            0) AS debajo_stock,
        b.crt_stock AS crt_stock
    FROM TempInventario a
	JOIN TempInsprod b ON a.id_tipo_ins = b.id_tipo_ins AND a.id_ins = b.id_ins
    WHERE b.est_a = 'a' AND b.est_b = 'a' AND a.idemp = _idemp AND a.idsede =_idsede AND a.id_ins LIKE _id_ins AND a.id_tipo_ins LIKE _id_tipo_ins
    GROUP BY a.id_tipo_ins , a.id_ins , a.idsede;

END$$

DROP PROCEDURE IF EXISTS `sp_get_usuarios`$$
CREATE PROCEDURE `sp_get_usuarios` (IN `_idemp` INT, IN `_idsede` VARCHAR(10), IN `_id_usu` VARCHAR(10), IN `_id_rol` VARCHAR(10), IN `_estado` VARCHAR(10))   BEGIN
	 SELECT 
        u.id_usu AS id_usu,
        u.id_rol AS id_rol,
        u.id_areap AS id_areap,
        u.dni AS dni,
        CONCAT(u.ape_paterno,' ',u.ape_materno,' ',u.nombres) AS nombreCompl,
        u.ape_paterno AS ape_paterno,
        u.ape_materno AS ape_materno,
        u.nombres AS nombres,
        u.email AS email,
        u.usuario AS usuario,
        u.contrasena AS contrasena,
        u.estado AS estado,
        u.imagen AS imagen,
        u.idEmpresa AS idEmpresa,
        r.descripcion AS desc_r,
        p.nombre AS desc_ap
    FROM
        tm_usuario u
        JOIN tm_rol r ON u.id_rol = r.id_rol
        LEFT JOIN tm_area_prod p ON u.id_areap = p.id_areap
    WHERE u.id_usu <> 0 AND u.idEmpresa LIKE _idemp AND u.id_usu LIKE _id_usu AND u.id_rol LIKE _id_rol
    ORDER BY u.id_usu DESC;
END$$

DROP PROCEDURE IF EXISTS `sp_get_ventas_con`$$
CREATE PROCEDURE `sp_get_ventas_con` (IN `_idemp` VARCHAR(8), IN `_idsede` VARCHAR(8), IN `_fecha_i` VARCHAR(20), IN `_fecha_f` VARCHAR(20), IN `id_vent` VARCHAR(10), IN `_id_cli` VARCHAR(10))   BEGIN

	DECLARE _cod0 INT DEFAULT 0;
	DECLARE _fecha_inicio DATETIME; 
	DECLARE _fecha_fin DATETIME; 
    IF _fecha_i = '%' THEN
		SET _cod0 = 1;
	ELSE
		SET _cod0 = 2;
		SET _fecha_inicio = STR_TO_DATE(_fecha_i, '%Y-%m-%d %H:%i:%s'); 
        SET _fecha_fin = STR_TO_DATE(_fecha_f, '%Y-%m-%d %H:%i:%s'); 
	END IF;

	SELECT 
        v.id_venta AS id_ven,
        v.id_pedido AS id_ped,
        v.id_tipo_pedido AS id_tped,
        v.id_cliente AS id_cli,
        v.id_tipo_doc AS id_tdoc,
        v.id_pago AS id_fpag,
        v.id_usu AS id_usu,
        v.id_apc AS id_apc,
        v.serie_doc AS ser_doc,
        v.nro_doc AS nro_doc,
        v.pago_efe_none AS pago_efe_none,
        SUM(tvp.cant_pago) AS cant_total,
        SUM(CASE
            WHEN tp.id_pago = 1 THEN tvp.cant_pago
            ELSE 0
        END) AS pago_efe,
        SUM(CASE
            WHEN tp.id_pago <> 1 THEN tvp.cant_pago
            ELSE 0
        END) AS pago_tar,
        v.descuento_monto AS desc_monto,
        v.descuento_tipo AS desc_tipo,
        v.descuento_personal AS desc_personal,
        v.descuento_motivo AS desc_motivo,
        v.comision_tarjeta AS comis_tar,
        v.comision_delivery AS comis_del,
        v.igv AS igv,
        v.total AS total,
        v.codigo_operacion AS codigo_operacion,
        v.fecha_venta AS fec_ven,
        v.estado AS estado,
        v.hash_cdr AS hash_cdr,
        v.hash_cpe AS hash_cpe,
        v.fecha_vencimiento AS fecha_vencimiento,
        v.idemp AS idemp,
        v.idsede AS idsede,
        v.crt_fac_cons AS crt_fac_cons,
        COALESCE(NULLIF(v.external_id, ''), '0') AS external_id,
        COALESCE(NULLIF(v.msg_fact, ''), '--') AS msg_fact,
        td.descripcion AS desc_td,
        tp.descripcion AS desc_tp,
        CONCAT(tu.ape_paterno,
                ' ',
                tu.ape_materno,
                ' ',
                tu.nombres) AS desc_usu
    FROM
        ((((tm_venta v
        JOIN tm_venta_pago tvp ON (v.id_venta = tvp.id_venta))
        JOIN tm_tipo_doc td ON (v.id_tipo_doc = td.id_tipo_doc))
        JOIN tm_tipo_pago tp ON (tvp.id_tipo_pago = tp.id_tipo_pago))
        JOIN tm_usuario tu ON (v.id_usu = tu.id_usu))
    WHERE
        v.id_venta <> 0 AND v.idemp LIKE _idemp AND v.idsede LIKE _idsede
        AND CASE
        WHEN _cod0 = 2 THEN (v.fecha_venta BETWEEN _fecha_inicio AND _fecha_fin)
        ELSE _cod0 <> 0
        END
        AND v.id_venta LIKE id_vent AND v.id_cliente LIKE _id_cli
    GROUP BY tvp.id_venta
    ORDER BY v.id_venta DESC;
    
END$$

DROP PROCEDURE IF EXISTS `sp_limpiezaDatos`$$
CREATE PROCEDURE `sp_limpiezaDatos` ()   BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

   START TRANSACTION;
	-- Script de limpieza de datos
	/***************TRUNCATE comunicacion_baja****************/
	DELETE FROM comunicacion_baja;
    ALTER TABLE comunicacion_baja AUTO_INCREMENT = 1;
	/***************TRUNCATE horarioatencion****************/
	DELETE FROM horarioatencion;
    ALTER TABLE horarioatencion AUTO_INCREMENT = 1;
	/***************TRUNCATE resumen_diario_detalle****************/
	DELETE FROM resumen_diario_detalle;
    ALTER TABLE horarioatencion AUTO_INCREMENT = 1;
	/***************TRUNCATE resumen_diario****************/
	DELETE FROM resumen_diario;
    ALTER TABLE resumen_diario AUTO_INCREMENT = 1;
	/***************TRUNCATE tm_gastos_adm****************/
	DELETE FROM tm_gastos_adm;
    ALTER TABLE tm_gastos_adm AUTO_INCREMENT = 1;
	/***************TRUNCATE tm_ingresos_adm****************/
	DELETE FROM tm_ingresos_adm;
    ALTER TABLE tm_ingresos_adm AUTO_INCREMENT = 1;
	/***************TRUNCATE tm_detalle_venta****************/
	DELETE FROM tm_detalle_venta;
    ALTER TABLE tm_detalle_venta AUTO_INCREMENT = 1;
	/***************TRUNCATE tm_venta****************/
	DELETE FROM tm_venta;
	/***************DELETE tm_aper_cierre****************/
	DELETE FROM tm_aper_cierre;
    ALTER TABLE tm_aper_cierre AUTO_INCREMENT = 1;
	/***************DELETE tm_producto_ingr****************/
	DELETE FROM tm_producto_ingr;
    ALTER TABLE tm_producto_ingr AUTO_INCREMENT = 1;
	/***************DELETE tm_detalle_pedido****************/
	DELETE FROM tm_detalle_pedido;
    ALTER TABLE tm_detalle_pedido AUTO_INCREMENT = 1;
	/***************DELETE tm_pedido_delivery****************/
	TRUNCATE TABLE tm_pedido_delivery;
	/***************DELETE tm_pedido_llevar****************/
	TRUNCATE TABLE tm_pedido_llevar;
	/***************DELETE tm_pedido_mesa****************/
	DELETE FROM tm_pedido_mesa;
    ALTER TABLE tm_pedido_mesa AUTO_INCREMENT = 1;
	/***************DELETE tm_pedido****************/
	DELETE FROM tm_pedido;
    ALTER TABLE tm_pedido AUTO_INCREMENT = 1;
	/***************DELETE tm_producto_pres****************/
	DELETE FROM tm_producto_pres;
    ALTER TABLE tm_producto_pres AUTO_INCREMENT = 1;
	/***************DELETE tm_produc_topicos****************/
	DELETE FROM tm_produc_topicos;
    ALTER TABLE tm_produc_topicos AUTO_INCREMENT = 1;
	/***************DELETE tm_producto****************/
	DELETE FROM tm_producto;
    ALTER TABLE tm_producto AUTO_INCREMENT = 1;
	/***************DELETE tm_impresora****************/
	DELETE FROM tm_impresora;
    ALTER TABLE tm_impresora AUTO_INCREMENT = 1;
	/***************DELETE tm_area_prod****************/
	DELETE FROM tm_area_prod;
    ALTER TABLE tm_area_prod AUTO_INCREMENT = 1;
	/***************DELETE tm_topicos****************/
	DELETE FROM tm_topicos;
    ALTER TABLE tm_topicos AUTO_INCREMENT = 1;
	/***************DELETE tm_producto_catg****************/
	DELETE FROM tm_producto_catg where id_catg not in (1);
    ALTER TABLE tm_producto_catg AUTO_INCREMENT = 1;
	/***************DELETE tm_caja****************/
	DELETE FROM tm_caja;
    ALTER TABLE tm_caja AUTO_INCREMENT = 1;
	/***************DELETE tm_cliente****************/
	DELETE FROM tm_cliente where id_cliente not in (1);
    ALTER TABLE tm_cliente AUTO_INCREMENT = 1;
	/***************DELETE tm_compra_detalle****************/
	DELETE FROM tm_compra_detalle;
    ALTER TABLE tm_compra_detalle AUTO_INCREMENT = 1;
	/***************DELETE tm_credito_detalle****************/
	DELETE FROM tm_credito_detalle;
    ALTER TABLE tm_credito_detalle AUTO_INCREMENT = 1;
	/***************DELETE tm_compra_credito****************/
	DELETE FROM tm_compra_credito;
    ALTER TABLE tm_compra_credito AUTO_INCREMENT = 1;
	/***************DELETE tm_compra****************/
	DELETE FROM tm_compra;
    ALTER TABLE tm_compra AUTO_INCREMENT = 1;
	/***************DELETE tm_insumo****************/
	DELETE FROM tm_insumo;
    ALTER TABLE tm_insumo AUTO_INCREMENT = 1;
	/***************DELETE tm_insumo_catg****************/
	DELETE FROM tm_insumo_catg;
    ALTER TABLE tm_insumo_catg AUTO_INCREMENT = 1;
	/***************DELETE tm_inventario_entsal****************/
	DELETE FROM tm_inventario_entsal;
    ALTER TABLE tm_inventario_entsal AUTO_INCREMENT = 1;
	/***************DELETE tm_inventario****************/
	DELETE FROM tm_inventario;
    ALTER TABLE tm_inventario AUTO_INCREMENT = 1;
	/***************DELETE tm_mesa****************/
	DELETE FROM tm_mesa;
    ALTER TABLE tm_mesa AUTO_INCREMENT = 1;
	/***************DELETE tm_salon****************/
	DELETE FROM tm_salon;
    ALTER TABLE tm_salon AUTO_INCREMENT = 1;
	/***************DELETE tm_sede_usuario****************/
	DELETE FROM tm_sede_usuario;
    ALTER TABLE tm_sede_usuario AUTO_INCREMENT = 1;
	/***************DELETE tm_sedes****************/
	DELETE FROM tm_sedes;
    ALTER TABLE tm_sedes AUTO_INCREMENT = 1;
	/***************DELETE tm_modulos****************/
	DELETE FROM tm_modulos;
    ALTER TABLE tm_modulos AUTO_INCREMENT = 1;
	/***************DELETE tm_plan****************/
	DELETE FROM tm_plan;
    ALTER TABLE tm_plan AUTO_INCREMENT = 1;
	/***************DELETE tm_proveedor************/
	DELETE FROM tm_proveedor;
    ALTER TABLE tm_proveedor AUTO_INCREMENT = 1;
	/***************DELETE tm_series****************/
	DELETE FROM tm_series;
	ALTER TABLE tm_series AUTO_INCREMENT = 1;
	/***************DELETE tm_tipo_pago****************/
	DELETE FROM tm_tipo_pago where id_tipo_pago not in (1,2,3);
    ALTER TABLE tm_tipo_pago AUTO_INCREMENT = 3;
	/***************DELETE tm_landing****************/
	DELETE FROM tm_landing;
    ALTER TABLE tm_landing AUTO_INCREMENT = 1;
	/***************DELETE tm_configuracion****************/
	DELETE FROM tm_configuracion;
    ALTER TABLE tm_configuracion AUTO_INCREMENT = 1;
	/***************DELETE tm_empresa****************/
	DELETE FROM tm_empresa;
    ALTER TABLE tm_empresa AUTO_INCREMENT = 1;
	/***************DELETE tm_usuario****************/
	DELETE FROM tm_usuario where id_usu not in (1);
	ALTER TABLE tm_usuario AUTO_INCREMENT = 1;

    COMMIT;
END$$

DROP PROCEDURE IF EXISTS `sp_pedido_delivery`$$
CREATE PROCEDURE `sp_pedido_delivery` (IN `_idemp` INT, IN `_idsede` INT, IN `_id_pedido` VARCHAR(10), IN `_estado` VARCHAR(10))   BEGIN
  SELECT
 
        p.id_pedido AS id_pedido,
        p.id_tipo_pedido AS id_tipo_pedido,
        p.idemp AS idemp,
        p.idsede AS idsede,
        p.id_usu AS id_usu,
        pd.id_repartidor AS id_repartidor,
        p.fecha_pedido AS fecha_pedido,
        p.estado AS estado_pedido,
        pd.tipo_entrega AS tipo_entrega,
        pd.pedido_programado AS pedido_programado,
        pd.hora_entrega AS hora_entrega,
        pd.amortizacion AS amortizacion,
        pd.tipo_pago AS tipo_pago,
        pd.paga_con AS paga_con,
        pd.comision_delivery AS comision_delivery,
        pd.nro_pedido AS nro_pedido,
        pd.id_cliente AS id_cliente,
        c.tipo_cliente AS tipo_cliente,
        c.dni AS dni_cliente,
        c.ruc AS ruc_cliente,
        pd.nombre_cliente AS nombre_cliente,
'DELIVERY' AS desc_salon,
        pd.telefono_cliente AS telefono_cliente,
        pd.direccion_cliente AS direccion_cliente,
        pd.referencia_cliente AS referencia_cliente,
        pd.email_cliente AS email_cliente,
        r.desc_repartidor AS desc_repartidor
    FROM
        (((tm_pedido p
        JOIN tm_pedido_delivery pd ON (p.id_pedido = pd.id_pedido))
        JOIN tm_cliente c ON (pd.id_cliente = c.id_cliente))
		LEFT JOIN v_repartidores r ON (pd.id_repartidor = r.id_repartidor))
    WHERE
        p.id_pedido <> 0 AND p.id_pedido LIKE _id_pedido AND p.idemp = _idemp AND p.idsede = _idsede
    ORDER BY p.id_pedido DESC;
END$$

DROP PROCEDURE IF EXISTS `sp_pedido_llevar`$$
CREATE PROCEDURE `sp_pedido_llevar` (IN `_idemp` INT, IN `_idsede` INT, IN `_id_pedido` VARCHAR(10), IN `_estado` VARCHAR(10))   BEGIN

  SELECT 
        p.id_pedido AS id_pedido,
        p.id_tipo_pedido AS id_tipo_pedido,
        p.id_usu AS id_usu,
        p.fecha_pedido AS fecha_pedido,
        p.estado AS estado_pedido,
        pl.nro_pedido AS nro_pedido,
        pl.nomb_cliente AS nombre_cliente,
'PARA LLEVAR' AS desc_salon,
        pl.idemp AS idemp,
        pl.idsede AS idsede
    FROM
        (tm_pedido p
        JOIN tm_pedido_llevar pl ON (p.id_pedido = pl.id_pedido))
    WHERE
        p.id_pedido <> 0 AND p.id_pedido LIKE _id_pedido AND p.idemp = _idemp AND p.idsede = _idsede
    ORDER BY p.id_pedido DESC;
 
END$$

DROP PROCEDURE IF EXISTS `sp_pedido_mesa`$$
CREATE PROCEDURE `sp_pedido_mesa` (IN `_idemp` INT, IN `_idsede` INT, IN `_id_pedido` VARCHAR(10), IN `_estado` VARCHAR(10))   BEGIN
  SELECT 
        p.id_pedido AS id_pedido,
        p.id_tipo_pedido AS id_tipo_pedido,
        p.id_usu AS id_usu,
        pm.id_mesa AS id_mesa,
        p.fecha_pedido AS fecha_pedido,
        p.estado AS estado_pedido,
        p.idemp AS idemp,
        p.idsede AS idsede,
        pm.nomb_cliente AS nombre_cliente,
        pm.nro_personas AS nro_personas,
        tm.nro_mesa AS nro_mesa,
        ts.descripcion AS desc_salon,
        tm.estado AS estado_mesa,
        CONCAT(u.nombres, ' ', u.ape_paterno) AS nombre_mozo
    FROM
        tm_pedido p
        JOIN tm_pedido_mesa pm ON p.id_pedido = pm.id_pedido
        JOIN tm_mesa tm ON pm.id_mesa = tm.id_mesa
        JOIN tm_salon ts ON tm.id_salon = ts.id_salon
        JOIN tm_usuario u ON pm.id_mozo = u.id_usu
    WHERE
        p.id_pedido <> 0 AND p.id_pedido LIKE _id_pedido AND p.idemp = _idemp AND p.idsede = _idsede
            AND p.estado LIKE _estado
    ORDER BY p.id_pedido DESC;
END$$

DROP PROCEDURE IF EXISTS `usp_cajaAperturar`$$
CREATE PROCEDURE `usp_cajaAperturar` (IN `_flag` INT, IN `_id_usu` INT, IN `_id_caja` INT, IN `_id_turno` INT, IN `_fecha_aper` DATETIME, IN `_monto_aper` DECIMAL(10,2), IN `_idemp` INT, IN `_idsede` INT)   BEGIN
	DECLARE _filtro INT DEFAULT 1;
	
	IF _flag = 1 THEN
	
		SELECT COUNT(*) INTO _filtro FROM tm_aper_cierre WHERE (id_usu = _id_usu or id_caja = _id_caja) AND estado = 'a' AND idemp = _idemp AND idsede = _idsede;
		
		IF _filtro = 0 THEN
            INSERT INTO tm_aper_cierre(id_usu, id_caja, id_turno, fecha_aper, monto_aper, fecha_cierre, monto_cierre, monto_sistema, stock_pollo, estado, idemp, idsede) 
            VALUES (_id_usu,_id_caja,_id_turno,_fecha_aper,_monto_aper,'1000-01-01 00:00:00',0.00,0.00,'0','a',_idemp,_idsede);
			UPDATE tm_caja SET estado = 'c' WHERE id_caja = _id_caja;
			SELECT @@IDENTITY INTO @id;
			
			SELECT @id AS id_apc, _filtro AS cod;
		ELSE
			SELECT _filtro AS cod;
		END IF;
		
	END IF;
    END$$

DROP PROCEDURE IF EXISTS `usp_cajaCerrar`$$
CREATE PROCEDURE `usp_cajaCerrar` (IN `_flag` INT(11), IN `_id_apc` INT(11), IN `_fecha_cierre` DATETIME, IN `_monto_cierre` DECIMAL(10,2), IN `_monto_sistema` DECIMAL(10,2), IN `_stock_pollo` VARCHAR(11), IN `_idemp` INT, IN `_idsede` INT)   BEGIN
		DECLARE _filtro INT DEFAULT 0;
		DECLARE _id_usu INT DEFAULT 0;
		
		IF _flag = 1 THEN
		
			SELECT COUNT(*) INTO _filtro FROM tm_aper_cierre WHERE id_apc = _id_apc AND estado = 'a';
			SELECT id_usu INTO _id_usu FROM tm_aper_cierre WHERE id_apc = _id_apc AND estado = 'a';
			
			IF _filtro = 1 THEN
			
				SET @idCaja =  (SELECT id_caja FROM tm_aper_cierre WHERE id_apc = _id_apc AND idemp = _idemp);
                UPDATE tm_caja SET estado = 'a' WHERE id_caja = @idCaja AND idemp = _idemp;
                
				UPDATE tm_aper_cierre SET fecha_cierre = _fecha_cierre, monto_cierre = _monto_cierre, monto_sistema = _monto_sistema, stock_pollo = _stock_pollo, estado = 'c' 
				WHERE id_apc = _id_apc AND idemp = _idemp;
				
				SELECT _filtro AS cod, _id_usu AS id_usu;
			ELSE
				SELECT _filtro AS cod, _id_usu AS id_usu;
			END IF;
		END IF;
	END$$

DROP PROCEDURE IF EXISTS `usp_comprasAnular`$$
CREATE PROCEDURE `usp_comprasAnular` (IN `_flag` INT(11), IN `_id_compra` INT(11))   BEGIN
	DECLARE _filtro INT DEFAULT 0;
	if _flag = 1 then
	
		SELECT COUNT(*) INTO _filtro FROM tm_compra WHERE estado = 'a' AND id_compra = _id_compra;
		
		IF _filtro = 1 THEN
			UPDATE tm_compra SET estado = 'i' WHERE id_compra = _id_compra;
			DELETE FROM tm_inventario WHERE id_tipo_ope = 1 AND id_ope = _id_compra;
			SELECT _filtro AS cod;
		ELSE
			SELECT _filtro AS cod;
		END IF;
	end if;
    END$$

DROP PROCEDURE IF EXISTS `usp_comprasCreditoCuotas`$$
CREATE PROCEDURE `usp_comprasCreditoCuotas` (IN `_flag` INT(11), IN `_id_credito` INT(11), IN `_id_usu` INT(11), IN `_id_apc` INT(11), IN `_importe` DECIMAL(10,2), IN `_fecha` DATETIME, IN `_egreso` INT(11), IN `_monto_egreso` DECIMAL(10,2), IN `_monto_amortizado` DECIMAL(10,2), IN `_total_credito` DECIMAL(10,2), IN `_idemp` INT, IN `_idsede` INT)   BEGIN
	DECLARE tcuota DECIMAL(10,2) DEFAULT 0;
	DECLARE motivo VARCHAR(100);
	
	IF _flag = 1 THEN
	
		INSERT INTO tm_credito_detalle (id_credito,id_usu,importe,fecha,egreso,idemp,idsede)
		VALUES (_id_credito, _id_usu, _importe, _fecha, _egreso, _idemp, _idsede);
	
			IF (_egreso = 1) THEN
	
				SELECT v.desc_prov INTO @descP
				FROM v_compras AS v INNER JOIN tm_compra_credito AS c ON v.id_compra = c.id_compra
				WHERE c.id_credito = _id_credito;
		
				SET motivo = @descP;
		
				INSERT INTO tm_gastos_adm (id_tipo_gasto,id_usu,id_apc,importe,motivo,fecha_registro,idemp,idsede)
				VALUES (4,_id_usu,_id_apc,_monto_egreso,motivo,_fecha,_idemp,_idsede);
	
			END IF;
	
		SET tcuota = _monto_amortizado + _importe;
	
		UPDATE tm_compra_credito SET estado = 'a' WHERE id_credito = _id_credito;
	
	END IF;
	
END$$

DROP PROCEDURE IF EXISTS `usp_comprasRegProveedor`$$
CREATE PROCEDURE `usp_comprasRegProveedor` (IN `_flag` INT(11), IN `_id_prov` INT(11), IN `_ruc` VARCHAR(13), IN `_razon_social` VARCHAR(100), IN `_direccion` VARCHAR(300), IN `_telefono` INT(9), IN `_email` VARCHAR(45), IN `_contacto` VARCHAR(45), IN `_idemp` INT, IN `_idsede` INT)   BEGIN
		DECLARE _filtro INT DEFAULT 1;

		IF _flag = 1 THEN
		
			SELECT count(*) INTO _filtro FROM tm_proveedor WHERE ruc = _ruc;
		
			IF _filtro = 0 THEN
			
				INSERT INTO tm_proveedor (ruc,razon_social,direccion,telefono,email,contacto,estado,idemp,idsede) 
				VALUES (_ruc, _razon_social, _direccion, _telefono, _email, _contacto, 'a', _idemp, _idsede);
				
				SELECT @@IDENTITY INTO @id;
			
				SELECT _filtro AS cod,@id AS id_prov;
			ELSE
				SELECT _filtro AS cod;
			END IF;	
			
		END IF;
		
		if _flag = 2 then
		
			UPDATE tm_proveedor SET ruc = _ruc, razon_social = _razon_social, direccion = _direccion, telefono = _telefono, email = _email, contacto = _contacto
			WHERE id_prov = _id_prov;
			
		end if;
	END$$

DROP PROCEDURE IF EXISTS `usp_configAlmacenes`$$
CREATE PROCEDURE `usp_configAlmacenes` (IN `_flag` INT(11), IN `_nombre` VARCHAR(45), IN `_estado` VARCHAR(5), IN `_idAlm` INT(11))   BEGIN
	DECLARE _cont INT DEFAULT 0;
	DECLARE _cod0 INT DEFAULT 0;
	DECLARE	_cod1 INT DEFAULT 1;
	DECLARE	_cod2 INT DEFAULT 2;
	
	IF _flag = 1 THEN
		SELECT COUNT(*) INTO _cont FROM tm_almacen WHERE nombre = _nombre;
	
		IF _cont = 0 THEN
			INSERT INTO tm_almacen (nombre,estado) VALUES (_nombre, _estado);
			SELECT _cod1 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
	END IF;
	
	IF _flag = 2 THEN
		SELECT COUNT(*) INTO _cont FROM tm_almacen WHERE nombre = _nombre AND estado = _estado;
	
		IF _cont = 0 THEN
			UPDATE tm_almacen SET nombre = _nombre, estado = _estado WHERE id_alm = _idAlm;
			SELECT _cod2 AS cod;
		ELSE
			SELECT _cod2 AS cod;
		END IF;
	END IF;
	END$$

DROP PROCEDURE IF EXISTS `usp_configAreasProd`$$
CREATE PROCEDURE `usp_configAreasProd` (IN `_flag` INT(11), IN `_id_areap` INT(11), IN `_id_imp` INT(11), IN `_nombre` VARCHAR(45), IN `_estado` VARCHAR(5), IN `_idemp` INT, IN `_idsede` INT)   BEGIN
	DECLARE _cont INT DEFAULT 0;
	DECLARE _cod0 INT DEFAULT 0;
	DECLARE	_cod1 INT DEFAULT 1;
	DECLARE	_cod2 INT DEFAULT 2;
	
	IF _flag = 1 THEN
		SELECT COUNT(*) INTO _cont FROM tm_area_prod WHERE nombre = _nombre AND idemp = _idemp;
	
		IF _cont = 0 THEN
			INSERT INTO tm_area_prod (id_imp,nombre,estado,idemp,idsede) VALUES (_id_imp, _nombre, _estado, _idemp, _idsede);
			SELECT _cod1 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
	END IF;
	
	IF _flag = 2 THEN
		SELECT COUNT(*) INTO _cont FROM tm_area_prod WHERE id_areap = _id_areap AND idemp = _idemp;
	
		IF _cont = 1 THEN
			UPDATE tm_area_prod SET id_imp = _id_imp, nombre = _nombre, estado = _estado WHERE id_areap = _id_areap AND idemp = _idemp;
			SELECT _cod2 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
	END IF;
	END$$

DROP PROCEDURE IF EXISTS `usp_configCajas`$$
CREATE PROCEDURE `usp_configCajas` (IN `_flag` INT(11), IN `_id_caja` INT(11), IN `_descripcion` VARCHAR(45), IN `_estado` VARCHAR(5), IN `_idemp` INT, IN `_idsede` INT)   BEGIN
	DECLARE _filtro INT DEFAULT 0;
	DECLARE _cod0 INT DEFAULT 0;
	DECLARE	_cod1 INT DEFAULT 1;
	DECLARE	_cod2 INT DEFAULT 2;
	
	IF _flag = 1 THEN
		SELECT COUNT(*) INTO _filtro FROM tm_caja WHERE descripcion = _descripcion AND idemp = _idemp AND idsede = _idsede;
	
		IF _filtro = 0 THEN
			INSERT INTO tm_caja (descripcion,estado, idemp, idsede) VALUES (_descripcion, _estado, _idemp, _idsede);
			SELECT _cod1 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
	END IF;
	
	IF _flag = 2 THEN
	
		SELECT COUNT(*) INTO _filtro FROM tm_caja WHERE id_caja = _id_caja AND idemp = _idemp AND idsede = _idsede;
	
		IF _filtro = 1 THEN
			UPDATE tm_caja SET descripcion = _descripcion, estado = _estado WHERE id_caja = _id_caja AND idemp = _idemp;
			SELECT _cod2 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
	END IF;
	END$$

DROP PROCEDURE IF EXISTS `usp_configEliminarCategoriaIns`$$
CREATE PROCEDURE `usp_configEliminarCategoriaIns` (IN `_id_catg` INT(11))   BEGIN
	DECLARE _filtro INT DEFAULT 0;
	DECLARE _cod0 INT DEFAULT 0;
	DECLARE	_cod1 INT DEFAULT 1;
	
	SELECT COUNT(*) INTO _filtro FROM tm_insumo WHERE id_catg = _id_catg;
	IF _filtro = 0 THEN
		DELETE FROM tm_insumo_catg WHERE id_catg = _id_catg;
		SELECT _cod1 AS cod;
	ELSE
		SELECT _cod0 AS cod;
	END IF;
    END$$

DROP PROCEDURE IF EXISTS `usp_configEliminarCategoriaProd`$$
CREATE PROCEDURE `usp_configEliminarCategoriaProd` (IN `_id_catg` INT(11))   BEGIN
	DECLARE _filtro INT DEFAULT 0;
	DECLARE _cod0 INT DEFAULT 0;
	DECLARE	_cod1 INT DEFAULT 1;
	
	SELECT COUNT(*) INTO _filtro FROM tm_producto WHERE id_catg = _id_catg;
	IF _filtro = 0 THEN
		DELETE FROM tm_producto_catg WHERE id_catg = _id_catg;
		SELECT _cod1 AS cod;
	ELSE
		SELECT _cod0 AS cod;
	END IF;
    END$$

DROP PROCEDURE IF EXISTS `usp_configImpresoras`$$
CREATE PROCEDURE `usp_configImpresoras` (IN `_flag` INT, IN `_id_imp` INT, IN `_id_areap` INT, IN `_nombre` VARCHAR(50), IN `_estado` VARCHAR(5), IN `_impr_caja` VARCHAR(5), IN `_idemp` INT, IN `_idsede` INT)   BEGIN
	DECLARE _filtro INT DEFAULT 0;
	DECLARE _cod0 INT DEFAULT 0;
	DECLARE	_cod1 INT DEFAULT 1;
	DECLARE	_cod2 INT DEFAULT 2;
	
	IF _flag = 1 THEN
		SELECT COUNT(*) INTO _filtro FROM tm_impresora WHERE id_areap = _id_areap AND idemp = _idemp AND idsede = _idsede;
	
		IF _filtro = 0 THEN
			INSERT INTO tm_impresora (id_areap,nombre,estado,impr_caja,idemp,idsede) VALUES (_id_areap,_nombre,_estado,_impr_caja,_idemp,_idsede);
			SELECT _cod1 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
	END IF;
	
	IF _flag = 2 THEN
		SELECT COUNT(*) INTO _filtro FROM tm_impresora WHERE id_areap = _id_areap AND idemp = _idemp AND idsede = _idsede AND estado = 'a';
	
		IF _filtro = 0 OR _filtro = 1 THEN
			UPDATE tm_impresora SET id_areap = _id_areap, nombre = _nombre, estado = _estado, impr_caja = _impr_caja WHERE id_imp = _id_imp AND idemp=_idemp;
			SELECT CASE 
			WHEN COUNT(*) > 1 THEN 3 
			ELSE 2
			END INTO _cod2
			FROM tm_impresora  WHERE id_areap = _id_areap AND idemp = _idemp AND idsede = _idsede AND estado = 'a';
            SELECT _cod2 AS cod;
		ELSE
			SET _cod2 = 3;
			SELECT _cod2 AS cod;
		END IF;
	END IF;
    END$$

DROP PROCEDURE IF EXISTS `usp_configInsumo`$$
CREATE PROCEDURE `usp_configInsumo` (IN `_flag` INT, IN `_idCatg` INT, IN `_idMed` INT, IN `_cod` VARCHAR(10), IN `_nombre` VARCHAR(45), IN `_stock` INT, IN `_costo` DECIMAL(10,2), IN `_estado` VARCHAR(5), IN `_idIns` INT, IN `_idemp` INT)   BEGIN
	DECLARE _cont INT DEFAULT 0;
	DECLARE _cod0 INT DEFAULT 0;
	DECLARE	_cod1 INT DEFAULT 1;
	DECLARE	_cod2 INT DEFAULT 2;
	
	IF _flag = 1 THEN
	
		SELECT COUNT(*) INTO _cont FROM tm_insumo WHERE nomb_ins = _nombre and cod_ins = _cod AND idemp = _idemp;
	
		IF _cont = 0 THEN
			INSERT INTO tm_insumo (id_catg,id_med,cod_ins,nomb_ins,stock_min,cos_uni,idemp) VALUES ( _idCatg, _idMed, _cod, _nombre, _stock, _costo, _idemp);
			SELECT _cod1 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
		
	END IF;
	
	IF _flag = 2 THEN
	
		SELECT COUNT(*) INTO _cont FROM tm_insumo WHERE id_catg = _idCatg AND id_med = _idMed AND cod_ins = _cod AND nomb_ins = _nombre AND stock_min = _stock AND cos_uni = _costo AND estado = _estado AND idemp = _idemp;
	
		IF _cont = 0 THEN
			UPDATE tm_insumo SET id_catg = _idCatg, id_med = _idMed, cod_ins = _cod, nomb_ins = _nombre, stock_min = _stock, cos_uni = _costo, estado = _estado WHERE id_ins = _idIns AND idemp = _idemp;
			SELECT _cod2 AS cod;
		ELSE
			SELECT _cod2 AS cod;
		END IF;
	END IF;
    END$$

DROP PROCEDURE IF EXISTS `usp_configInsumoCatgs`$$
CREATE PROCEDURE `usp_configInsumoCatgs` (IN `_flag` INT(11), IN `_descC` VARCHAR(45), IN `_idCatg` INT(11), IN `_idemp` INT)   BEGIN
	DECLARE _cont INT DEFAULT 0;
	DECLARE _cod0 INT DEFAULT 0;
	DECLARE	_cod1 INT DEFAULT 1;
	DECLARE	_cod2 INT DEFAULT 2;
	
	IF _flag = 1 THEN
	
		SELECT COUNT(*) INTO _cont FROM tm_insumo_catg WHERE descripcion = _descC AND idemp = _idemp;
		
		IF _cont = 0 THEN
			INSERT INTO tm_insumo_catg (descripcion,idemp) VALUES (_descC,_idemp);
			SELECT _cod1 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
	
	END IF;
	
	IF _flag = 2 THEN
	
		SELECT COUNT(*) INTO _cont FROM tm_insumo_catg WHERE id_catg = _idCatg AND idemp = _idemp;
		
		IF _cont = 1 THEN
			UPDATE tm_insumo_catg SET descripcion = _descC WHERE id_catg = _idCatg AND idemp = _idemp;
			SELECT _cod2 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
	
	END IF;
    END$$

DROP PROCEDURE IF EXISTS `usp_configMesas`$$
CREATE PROCEDURE `usp_configMesas` (IN `_flag` INT(11), IN `_id_mesa` INT(11), IN `_id_salon` INT(11), IN `_nro_mesa` VARCHAR(5), IN `_estado` VARCHAR(45), IN `_idemp` INT, IN `_idsede` INT)   BEGIN
	DECLARE _filtro INT DEFAULT 0;
	DECLARE _cod0 INT DEFAULT 0;
	DECLARE	_cod1 INT DEFAULT 1;
	DECLARE	_cod2 INT DEFAULT 2;
	
	IF _flag = 1 THEN
	
		SELECT COUNT(*) INTO _filtro FROM tm_mesa WHERE id_salon = _id_salon AND nro_mesa = _nro_mesa AND idemp = _idemp AND idsede = _idsede;
	
		IF _filtro = 0 THEN
			INSERT INTO tm_mesa (id_salon,nro_mesa,estado,idemp,idsede) VALUES (_id_salon, _nro_mesa, _estado, _idemp, _idsede);
			SELECT _cod1 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
	
	END IF;
	
	IF _flag = 2 THEN
	
		SELECT COUNT(*) INTO _filtro FROM tm_mesa WHERE id_mesa = _id_mesa AND  idemp = _idemp AND idsede = _idsede;
	
		IF _filtro = 1 THEN
			UPDATE tm_mesa SET nro_mesa = _nro_mesa, estado = _estado WHERE id_mesa = _id_mesa;
			SELECT _cod2 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
	
	END IF;
	
	IF _flag = 3 THEN
	
		SELECT count(*) INTO _filtro FROM tm_pedido_mesa WHERE id_mesa = _id_mesa;
	
		IF _filtro = 0 THEN
			DELETE FROM tm_mesa WHERE id_mesa = _id_mesa;
			SELECT _cod1 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
	
	END IF;
	END$$

DROP PROCEDURE IF EXISTS `usp_configProducto`$$
CREATE PROCEDURE `usp_configProducto` (IN `_flag` INT(11), IN `_id_prod` INT(11), IN `_id_tipo` INT(11), IN `_id_catg` INT(11), IN `_id_areap` INT(11), IN `_nombre` VARCHAR(45), IN `_notas` VARCHAR(200), IN `_delivery` INT(1), IN `_estado` VARCHAR(1), IN `_idemp` INT, IN `_idsede` INT)   BEGIN
	DECLARE _filtro INT DEFAULT 0;
	DECLARE _cod0 INT DEFAULT 0;
	DECLARE	_cod1 INT DEFAULT 1;
	DECLARE	_cod2 INT DEFAULT 2;
	
	IF _flag = 1 THEN
		SELECT COUNT(*) INTO _filtro FROM tm_producto WHERE id_catg = _id_catg AND nombre = _nombre AND idemp = _idemp;
		IF _filtro = 0 THEN
			INSERT INTO tm_producto(id_tipo,id_catg,id_areap,nombre,notas,delivery, cod_pro,idemp, idsede) 
            VALUES (_id_tipo, _id_catg, _id_areap, _nombre, _notas, _delivery, '',_idemp, _idsede);
            SELECT @@identity AS id;
		else
			SELECT _cod0 AS cod;
		end if;
	end if;
	
	if _flag = 2 then
		SELECT COUNT(*) INTO _filtro FROM tm_producto WHERE id_prod = _id_prod AND idemp = _idemp;
		IF _filtro = 1 THEN
			UPDATE tm_producto SET id_tipo = _id_tipo, id_catg = _id_catg, id_areap = _id_areap, nombre = _nombre, notas = _notas, delivery = _delivery, estado = _estado 
			WHERE id_prod = _id_prod AND idemp = _idemp;
			SELECT _cod2 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
	end if;
	
	END$$

DROP PROCEDURE IF EXISTS `usp_configProductoCatgs`$$
CREATE PROCEDURE `usp_configProductoCatgs` (IN `_flag` INT(11), IN `_id_catg` INT(11), IN `_descripcion` VARCHAR(45), IN `_delivery` INT(1), IN `_orden` INT(11), IN `_imagen` VARCHAR(200), IN `_estado` VARCHAR(1), IN `_idemp` INT, IN `_idsede` INT)   BEGIN	
	DECLARE _filtro INT DEFAULT 0;
	DECLARE _cod0 INT DEFAULT 0;
	DECLARE	_cod1 INT DEFAULT 1;
	DECLARE	_cod2 INT DEFAULT 2;
	
	IF _flag = 1 THEN	
		
		SELECT COUNT(*) INTO _filtro FROM tm_producto_catg WHERE descripcion = _descripcion AND idemp = _idemp;
		IF _filtro = 0 THEN
			INSERT INTO tm_producto_catg (descripcion,delivery,orden,imagen,estado, idemp, idsede) VALUES (_descripcion,_delivery,100,_imagen,_estado, _idemp, _idsede);
			SELECT _cod1 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
	end if;
		
	IF _flag = 2 THEN
		SELECT COUNT(*) INTO _filtro FROM tm_producto_catg WHERE descripcion = _descripcion and delivery = _delivery and orden = _orden AND imagen = _imagen AND estado = _estado AND idemp = _idemp;
		IF _filtro = 0 THEN
			UPDATE tm_producto_catg SET descripcion = _descripcion, delivery = _delivery, orden =_orden, imagen = _imagen, estado = _estado WHERE id_catg = _id_catg;
			SELECT _cod2 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
	END IF;
	
	END$$

DROP PROCEDURE IF EXISTS `usp_configProductoIngrs`$$
CREATE PROCEDURE `usp_configProductoIngrs` (IN `_flag` INT(11), IN `_id_pi` INT(11), IN `_id_pres` INT(11), IN `_id_tipo_ins` INT(11), IN `_id_ins` INT(11), IN `_id_med` INT(11), IN `_cant` FLOAT, IN `_idemp` INT, IN `_idsede` INT, IN `_costo` FLOAT, IN `_id_areap` INT)   BEGIN
	if _flag = 1 then
		INSERT INTO tm_producto_ingr (id_pres,id_tipo_ins,id_ins,id_med,cant,idemp,idsede,costo,id_areap) VALUES (_id_pres, _id_tipo_ins, _id_ins, _id_med, _cant, _idemp, _idsede,_costo,_id_areap);
	end if;
	if _flag = 2 then
		UPDATE tm_producto_ingr SET cant = _cant WHERE id_pi = _id_pi;
	end if;
	if _flag = 3 then
		DELETE FROM tm_producto_ingr WHERE id_pi = _id_pi;
	end if;
END$$

DROP PROCEDURE IF EXISTS `usp_configProductoPres`$$
CREATE PROCEDURE `usp_configProductoPres` (IN `_flag` INT, IN `_id_pres` INT, IN `_id_prod` INT, IN `_cod_prod` VARCHAR(45), IN `_presentacion` VARCHAR(45), IN `_descripcion` VARCHAR(200), IN `_precio` DECIMAL(10,2), IN `_precio_delivery` DECIMAL(10,2), IN `_receta` INT, IN `_stock_min` INT, IN `_stock_limit` INT, IN `_impuesto` INT, IN `_delivery` INT, IN `_margen` INT, IN `_igv` DECIMAL(10,2), IN `_imagen` VARCHAR(200), IN `_estado` VARCHAR(1), IN `_idemp` INT, IN `_idsede` INT, IN `_crt_icbper` INT)   BEGIN
	DECLARE _cont INT DEFAULT 0;
	DECLARE _cod0 INT DEFAULT 0;
	DECLARE	_cod1 INT DEFAULT 1;
	DECLARE	_cod2 INT DEFAULT 2;
	IF _flag = 1 THEN
	
		SELECT COUNT(*) INTO _cont FROM tm_producto_pres WHERE presentacion = _presentacion AND id_prod = _id_prod AND idemp = _idemp;
		
		IF _cont = 0 THEN
			INSERT INTO tm_producto_pres(id_prod,cod_prod,presentacion,descripcion,precio,precio_delivery,receta,stock_min,crt_stock,impuesto,delivery,margen,igv,imagen,estado,idemp,idsede,crt_icbper) 
					VALUES (_id_prod, _cod_prod, _presentacion, _descripcion, _precio, _precio_delivery, _receta, _stock_min, _stock_limit, _impuesto, _delivery, _margen, _igv, _imagen, _estado, _idemp, _idsede, _crt_icbper);
			SELECT _cod1 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
		
	END IF;
	
	IF _flag = 2 THEN
		UPDATE tm_producto_pres SET cod_prod = _cod_prod, presentacion = _presentacion, descripcion = _descripcion, precio = _precio, precio_delivery = _precio_delivery, receta = _receta, stock_min = _stock_min, crt_stock = _stock_limit, impuesto = _impuesto, delivery = _delivery, margen = _margen, igv = _igv, imagen = _imagen, estado = _estado, crt_icbper = _crt_icbper
		WHERE id_pres = _id_pres AND idemp = _idemp;
		SELECT _cod2 AS cod;
		
	END IF;
END$$

DROP PROCEDURE IF EXISTS `usp_configRol`$$
CREATE PROCEDURE `usp_configRol` (IN `_flag` INT(11), IN `_desc` VARCHAR(45), IN `_idRol` INT(11))   BEGIN
		DECLARE _duplicado INT DEFAULT 1;
		
		IF _flag = 1 THEN
		
				SELECT count(*) INTO _duplicado FROM tm_rol WHERE descripcion = _desc;
			
			IF _duplicado = 0 THEN
				INSERT INTO tm_rol (descripcion) VALUES (_desc);
				
				SELECT _duplicado AS dup;
			ELSE
				SELECT _duplicado AS dup;
			END IF;
		
		end if;
		
		IF _flag = 2 THEN
		
				SELECT COUNT(*) INTO _duplicado FROM tm_rol WHERE descripcion = _desc;
			
			IF _duplicado = 0 THEN
				UPDATE tm_rol SET descripcion = _desc WHERE id_rol = _idRol;
				
				SELECT _duplicado AS dup;
			ELSE
				SELECT _duplicado AS dup;
			END IF;
		
		END IF;
	END$$

DROP PROCEDURE IF EXISTS `usp_configSalones`$$
CREATE PROCEDURE `usp_configSalones` (IN `_flag` INT(11), IN `_id_salon` INT(11), IN `_descripcion` VARCHAR(45), IN `_estado` VARCHAR(5), IN `_idemp` INT, IN `_idsede` INT)   BEGIN
	DECLARE _filtro INT DEFAULT 0;
	DECLARE _filtro2 INT DEFAULT 0;
	DECLARE _cod0 INT DEFAULT 0;
	DECLARE	_cod1 INT DEFAULT 1;
	DECLARE	_cod2 INT DEFAULT 2;
	
	IF _flag = 1 THEN
	
		SELECT COUNT(*) INTO _filtro FROM tm_salon WHERE descripcion = _descripcion AND idemp = _idemp AND idsede = _idsede;
	
		IF _filtro = 0 THEN
			INSERT INTO tm_salon (descripcion,estado,idemp,idsede) VALUES (_descripcion,_estado,_idemp,_idsede);
			SELECT _cod1 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
	
	end if;
	
	IF _flag = 2 THEN
	
		SELECT COUNT(*) INTO _filtro FROM tm_salon WHERE id_salon = _id_salon AND idemp = _idemp AND idsede = _idsede;
	
		IF _filtro = 1 THEN
			UPDATE tm_salon SET descripcion = _descripcion, estado = _estado WHERE id_salon = _id_salon AND idemp = _idemp;
			SELECT _cod2 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
	
	END IF;
	
	IF _flag = 3 THEN
	
		SELECT count(*) INTO _filtro FROM tm_mesa WHERE id_salon = _id_salon;
	
		IF _filtro = 0 THEN
			
			SELECT COUNT(*) AS _filtro2 FROM tm_salon;
			
			if _filtro2 = 1 then
			
				DELETE FROM tm_salon WHERE id_salon = _id_salon;
				ALTER TABLE tm_salon AUTO_INCREMENT = 1;
				SELECT _cod1 AS cod;
			else 
				DELETE FROM tm_salon WHERE id_salon = _id_salon;
				SELECT _cod1 AS cod;
			end if;		
			
		ELSE
			SELECT _cod0 AS cod;
		END IF;
	
	END IF;
	END$$

DROP PROCEDURE IF EXISTS `usp_configUsuario`$$
CREATE PROCEDURE `usp_configUsuario` (IN `_flag` INT(11), IN `_id_usu` INT(11), IN `_id_rol` INT(11), IN `_id_areap` INT(11), IN `_dni` VARCHAR(10), IN `_ape_paterno` VARCHAR(45), IN `_ape_materno` VARCHAR(45), IN `_nombres` VARCHAR(45), IN `_email` VARCHAR(100), IN `_usuario` VARCHAR(45), IN `_contrasena` VARCHAR(45), IN `_imagen` VARCHAR(45), IN `_cod_mozo` VARCHAR(50), IN `_id_emp` VARCHAR(50))   BEGIN
		DECLARE _filtro INT DEFAULT 1;
        DECLARE _filtr INT DEFAULT 1;
        DECLARE _filtrContr INT DEFAULT 1;
        DECLARE _resp INT DEFAULT 1;
        DECLARE _respusu INT DEFAULT 2;
		
		IF _flag = 1 THEN
			SELECT count(*) INTO _filtro  FROM tm_usuario WHERE usuario = _usuario AND idEmpresa = _id_emp;
		
			IF _filtro = 0 THEN
				INSERT INTO tm_usuario (id_rol,id_areap,dni,ape_paterno,ape_materno,nombres,email,usuario,contrasena,estado,imagen,idEmpresa) 
				VALUES (_id_rol,_id_areap,_dni,_ape_paterno,_ape_materno,_nombres,_email,_usuario,_contrasena,'a',_imagen,_id_emp);
				SELECT @@identity AS cod;
			ELSE
				SELECT _filtro AS cod;
			END IF;
		
		END IF;
        IF _flag = 2 THEN
			SELECT count(*) INTO _filtr  FROM tm_usuario WHERE usuario = _usuario AND idEmpresa = _id_emp;
            
			IF _filtr = 0 THEN
				UPDATE tm_usuario SET id_rol = _id_rol, id_areap = _id_areap, dni = _dni, ape_paterno = _ape_paterno, ape_materno = _ape_materno, nombres = _nombres, email = _email, usuario = _usuario, contrasena = _contrasena, imagen = _imagen
				WHERE id_usu = _id_usu;
				SELECT _resp AS cod;
			ELSE
				UPDATE tm_usuario SET id_rol = _id_rol, id_areap = _id_areap, dni = _dni, ape_paterno = _ape_paterno, ape_materno = _ape_materno, nombres = _nombres, email = _email, contrasena = _contrasena,imagen = _imagen
				WHERE id_usu = _id_usu;
				SELECT _respusu AS cod;
			END IF;
            
		END IF;
	END$$

DROP PROCEDURE IF EXISTS `usp_invESAnular`$$
CREATE PROCEDURE `usp_invESAnular` (IN `_flag` INT(11), IN `_id_es` INT(11), IN `_id_tipo` INT(11))   BEGIN
	DECLARE _filtro INT DEFAULT 0;
	IF _flag = 1 THEN
	
		SELECT COUNT(*) INTO _filtro FROM tm_inventario_entsal WHERE estado = 'a' AND id_es = _id_es;
		
		IF _filtro = 1 THEN
			UPDATE tm_inventario_entsal SET estado = 'i' WHERE id_es = _id_es;
			UPDATE tm_inventario SET estado = 'i' WHERE id_tipo_ope = _id_tipo AND id_ope = _id_es;
			SELECT _filtro AS cod;
		ELSE
			SELECT _filtro AS cod;
		END IF;
	END IF;
    END$$

DROP PROCEDURE IF EXISTS `usp_listaTopico`$$
CREATE PROCEDURE `usp_listaTopico` (IN `_id_pres` INT(11))   BEGIN
	set @idProd =(select id_prod from tm_producto_pres where id_pres = _id_pres);
	select tp.id_prod, _id_pres, tt.id_topicos, t.nombre, t.precio,t.estado from tm_producto tp 
	inner join tm_produc_topicos tt on tp.id_prod = tt.id_producto
	inner join tm_topicos t on tt.id_topicos = t.id_topicos where tp.id_prod = @idProd and t.estado = "a";

END$$

DROP PROCEDURE IF EXISTS `usp_optPedidos`$$
CREATE PROCEDURE `usp_optPedidos` (IN `_flag` INT(11), IN `_idemp` INT, IN `_idsede` INT)   BEGIN
	DECLARE _cont INT DEFAULT 0;
	DECLARE _cod0 INT DEFAULT 0;
	DECLARE	_cod1 INT DEFAULT 1;
	
	IF _flag = 1 THEN
	
		/*SELECT COUNT(*) FROM tm_aper_cierre WHERE estado = 'a';*/
		/*Limpiar pedidos*/
		IF _cont = 0 THEN
			DELETE FROM tm_detalle_pedido WHERE idemp = _idemp;
			UPDATE tm_pedido SET estado = 'z' WHERE estado = 'a' AND idemp = _idemp;
			/*mostrador*/
			UPDATE tm_pedido SET estado = 'd' WHERE estado = 'b' AND id_tipo_pedido = 2 AND idemp = _idemp;
			/*delivery*/
			UPDATE tm_pedido SET estado = 'd' WHERE estado = 'c' AND id_tipo_pedido = 3 AND idemp = _idemp;
			UPDATE tm_pedido SET estado = 'z' WHERE estado = 'b' AND id_tipo_pedido = 3 AND idemp = _idemp;
			UPDATE tm_mesa SET estado = 'a' WHERE idemp = _idemp;
			SELECT _cod1 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
	
	END IF;
	
	IF _flag = 2 THEN
		
        DELETE FROM tm_gastos_adm WHERE idemp = _idemp;

		DELETE FROM tm_ingresos_adm WHERE idemp = _idemp;

		DELETE FROM tm_detalle_venta WHERE idemp = _idemp;
		/*DELETE FROM comunicacion_baja;

		DELETE FROM resumen_diario_detalle;

		DELETE FROM resumen_diario;*/

		DELETE FROM tm_venta WHERE idemp = _idemp;

		DELETE FROM tm_aper_cierre WHERE idemp = _idemp;
        
		DELETE FROM tm_detalle_pedido WHERE idemp = _idemp;
		DELETE FROM tm_pedido_mesa WHERE idemp = _idemp;
		DELETE FROM tm_pedido_llevar WHERE idemp = _idemp;
		DELETE FROM tm_pedido_delivery WHERE idemp = _idemp;
		DELETE FROM tm_pedido WHERE idemp = _idemp;

		DELETE FROM tm_compra_detalle WHERE idemp = _idemp;
		DELETE FROM tm_credito_detalle WHERE idemp = _idemp;
		DELETE FROM tm_compra_credito WHERE idemp = _idemp;

		DELETE FROM tm_compra WHERE idemp = _idemp;
		
		DELETE FROM tm_inventario_entsal WHERE idemp = _idemp;

		DELETE FROM tm_inventario WHERE idemp = _idemp;

		UPDATE tm_mesa SET estado = 'a' WHERE estado <> 'm' AND idemp = _idemp;
		SELECT _cod1 AS cod;
		
	END IF;
	
	IF _flag = 3 THEN
	
		SELECT COUNT(*) INTO _cont FROM tm_detalle_venta WHERE idemp = _idemp;
		
		IF _cont = 0 THEN
			DELETE FROM tm_producto_ingr WHERE idemp = _idemp;
			/*ALTER TABLE tm_producto_ingr AUTO_INCREMENT = 1;*/
			DELETE FROM tm_producto_pres WHERE idemp = _idemp;
			/*ALTER TABLE tm_producto_pres AUTO_INCREMENT = 1;*/
            DELETE FROM tm_produc_topicos WHERE idemp = _idemp;
			DELETE FROM tm_producto WHERE idemp = _idemp;
			/*ALTER TABLE tm_producto AUTO_INCREMENT = 1;*/
			DELETE FROM tm_producto_catg WHERE id_catg <> 1 AND idemp = _idemp;
			/*ALTER TABLE tm_producto_catg AUTO_INCREMENT = 1;*/
			SELECT _cod1 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
		
	END IF;
	
	IF _flag = 4 THEN
	
		SELECT COUNT(*) INTO _cont FROM tm_producto_ingr WHERE idemp = _idemp;
		
		IF _cont = 0 THEN
			
			DELETE FROM tm_inventario WHERE id_tipo_ins = 1 AND idemp = _idemp;
			DELETE FROM tm_insumo WHERE idemp = _idemp;
			/*ALTER TABLE tm_insumo AUTO_INCREMENT = 1;*/
			DELETE FROM tm_insumo_catg WHERE idemp = _idemp;
			/*ALTER TABLE tm_insumo_catg AUTO_INCREMENT = 1;*/
			SELECT _cod1 AS cod;
		ELSE
			SELECT _cod0 AS cod;
		END IF;
		
	END IF;
	
	IF _flag = 5 THEN
	
		DELETE FROM tm_cliente where id_cliente <> 1 AND idemp = _idemp;
		/*ALTER TABLE tm_cliente AUTO_INCREMENT = 2;*/
		SELECT _cod1 AS cod;
		
	END IF;
	
	IF _flag = 6 THEN
	
		DELETE FROM tm_proveedor WHERE idemp = _idemp;
		/*ALTER TABLE tm_proveedor AUTO_INCREMENT = 1;*/
		SELECT _cod1 AS cod;
		
	END IF;
	
	IF _flag = 7 THEN
		DELETE FROM tm_pedido_mesa WHERE idemp = _idemp;
        DELETE FROM tm_pedido WHERE idemp = _idemp AND id_tipo_pedido = 1;
        
		DELETE FROM tm_mesa WHERE idemp = _idemp;
		/*ALTER TABLE tm_mesa AUTO_INCREMENT = 1;*/
		DELETE FROM tm_salon WHERE idemp = _idemp;
		/*ALTER TABLE tm_salon AUTO_INCREMENT = 1;*/
		SELECT _cod1 AS cod;
		
	END IF;
    
    IF _flag = 8 THEN
		DELETE FROM tm_produc_topicos WHERE idemp = _idemp;
		
		DELETE FROM tm_topicos WHERE idemp = _idemp;

		SELECT _cod1 AS cod;
		
	END IF;
			
    END$$

DROP PROCEDURE IF EXISTS `usp_resgClienteEmp`$$
CREATE PROCEDURE `usp_resgClienteEmp` (IN `_ruc` VARCHAR(20), IN `_razon_social` VARCHAR(200), IN `_nombre_comercial` VARCHAR(200), IN `_direccion_comercial` VARCHAR(200), IN `_direccion_fiscal` VARCHAR(200), IN `_ubigeo` VARCHAR(8), IN `_departamento` VARCHAR(50), IN `_provincia` VARCHAR(50), IN `_distrito` VARCHAR(50), IN `_sunat` INT, IN `_modo` INT, IN `_optimiproceso` VARCHAR(10), IN `_logo` VARCHAR(45), IN `_celular` VARCHAR(50), IN `_email` VARCHAR(120), IN `_namesubdominio` VARCHAR(50), IN `_urlapi` VARCHAR(100), IN `_passentorno` VARCHAR(200), IN `_usuario` VARCHAR(50), IN `_passusu` VARCHAR(50), IN `_crt_plan` INT, IN `_crt_sede` INT)   BEGIN
	DECLARE _filtro INT DEFAULT 1;
    DECLARE _filtr INT DEFAULT 1;
	DECLARE _resp INT DEFAULT 3;
	DECLARE idemp INT;
    DECLARE idusu INT;
    DECLARE idsed INT;

    SELECT count(*) INTO _filtr FROM tm_empresa WHERE ruc = _ruc;
		IF _filtr = 0 THEN
			INSERT INTO tm_empresa(ruc,razon_social,nombre_comercial,direccion_comercial,direccion_fiscal,ubigeo,departamento,provincia,distrito,sunat,modo,usuariosol,clavesol,clavecertificado,client_id,client_secret,logo,celular,email,namesubdominio,urlapi,passentorno,optimiproceso,crt_plan,crt_sede) VALUES (_ruc,_razon_social,_nombre_comercial,_direccion_comercial,_direccion_fiscal,_ubigeo,_departamento,_provincia,_distrito,_sunat,_modo,'','','','','',_logo,_celular,_email,_namesubdominio,_urlapi,_passentorno,_optimiproceso,_crt_plan,_crt_sede);
			SET	@idemp =(SELECT @@identity AS idEmp);

            INSERT INTO tm_usuario(id_rol,id_areap,dni,ape_paterno,ape_materno,nombres,email,usuario,contrasena,estado,imagen,idEmpresa) VALUES (2,0,'00000000','ADM','ADM','ADM',_email,_usuario,_passusu,'a','default-avatar.png',@idemp);
            SET	@idusu =(SELECT @@identity AS idUsu);
            
            INSERT INTO tm_sedes(id_empresa,nombre,direccion,departamento,provincia,distrito,estado,telefono) VALUES (@idemp,'principal',_direccion_fiscal,_departamento,_provincia,_distrito,'a','');
            SET	@idsed =(SELECT @@identity AS idsed);
            
            INSERT INTO tm_sede_usuario(id_sede,id_usu) VALUES (@idsed,@idusu);
            
			INSERT INTO tm_configuracion(zona_hora,trib_acr,trib_car,di_acr,di_car,imp_acr,imp_val,mon_acr,mon_val,pc_name,pc_ip,print_com,print_pre,print_cpe,opc_01,opc_02,opc_03,bloqueo,cod_seg,idemp,idsede,principal)
            VALUES ('America/Lima','RUC',11,'DNI',8,'IGV',18.00,'Soles','S/','ADMIN-PC','',0,0,0,0,0,1,0,'123456',@idemp,@idsed,1);
            
            SELECT _filtro AS cod;
		ELSE
			SELECT _resp AS cod;
		END IF;
    
END$$

DROP PROCEDURE IF EXISTS `usp_restCancelarPedido`$$
CREATE PROCEDURE `usp_restCancelarPedido` (IN `_flag` INT(11), IN `_id_usu` INT(11), IN `_id_pres` INT(11), IN `_id_pedido` INT(11), IN `_estado_pedido` VARCHAR(5), IN `_fecha_pedido` DATETIME, IN `_fecha_envio` DATETIME, IN `_codigo_seguridad` VARCHAR(50), IN `_filtro_seguridad` VARCHAR(50), IN `_motivo_anulacion` VARCHAR(300))   BEGIN
	DECLARE _filtro INT DEFAULT 0;
	DECLARE _cod0 INT DEFAULT 0;
	DECLARE	_cod1 INT DEFAULT 1;
	DECLARE	_cod2 INT DEFAULT 2;
	
	IF _flag = 1 THEN
		/*
		SELECT COUNT(*) INTO _filtro FROM tm_detalle_pedido WHERE id_pedido = _id_pedido AND id_pres = _id_pres AND fecha_pedido = _fecha_pedido AND (_estado_pedido = 'a' OR _estado_pedido = 'y');
		*/
		/*iF _estado_pedido = 'a' or _estado_pedido = 'y' THEN	*/	
			if _codigo_seguridad = _filtro_seguridad then
				UPDATE tm_detalle_pedido SET estado = 'z', id_usu = _id_usu, fecha_envio = _fecha_envio, motivo_anulacion=_motivo_anulacion WHERE id_pedido = _id_pedido AND id_pres = _id_pres AND fecha_pedido = _fecha_pedido AND estado = _estado_pedido LIMIT 1;
				SELECT _cod1 AS cod;			
			else
				SELECT _cod0 AS cod;
			end if;			
		/*ELSE
			SELECT _cod2 AS cod;
		END IF;	*/
	END IF;
	
    END$$

DROP PROCEDURE IF EXISTS `usp_restDesocuparMesa`$$
CREATE PROCEDURE `usp_restDesocuparMesa` (`_flag` INT(11), `_id_pedido` INT(11))   BEGIN
	DECLARE result INT DEFAULT 1;
	IF _flag = 1 THEN
		SELECT id_mesa INTO @codmesa FROM tm_pedido_mesa WHERE id_pedido = _id_pedido;
		UPDATE tm_mesa SET estado = 'a' WHERE id_mesa = @codmesa;
		UPDATE tm_pedido SET estado = 'z' WHERE id_pedido = _id_pedido;
		SELECT result AS resultado;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `usp_restEditarVentaDocumento`$$
CREATE PROCEDURE `usp_restEditarVentaDocumento` (`_flag` INT(11), `_id_venta` INT(11), `_id_cliente` INT(11), `_id_tipo_documento` INT(11))   BEGIN
	DECLARE _cod INT DEFAULT 1;
	
	IF _flag = 1 THEN
		SELECT td.serie,CONCAT(LPAD(COUNT(id_venta)+(td.numero),8,'0')) AS numero INTO @serie, @numero
		FROM tm_venta AS v INNER JOIN tm_tipo_doc AS td ON v.id_tipo_doc = td.id_tipo_doc
		WHERE v.id_tipo_doc = _id_tipo_documento AND v.serie_doc = td.serie;
		UPDATE tm_venta SET id_cliente = _id_cliente, id_tipo_doc = _id_tipo_documento, serie_doc = @serie, nro_doc = @numero WHERE id_venta = _id_venta;
	END IF;
    END$$

DROP PROCEDURE IF EXISTS `usp_restEmitirVenta`$$
CREATE PROCEDURE `usp_restEmitirVenta` (`_flag` INT(11), `_dividir_cuenta` INT(11), `_id_pedido` INT(11), `_tipo_pedido` INT(11), `_tipo_entrega` VARCHAR(1), `_id_cliente` INT(11), `_id_tipo_doc` INT(11), `_id_pago` INT(11), `_id_usu` INT(11), `_id_apc` INT(11), `_pago_efe_none` DECIMAL(10,2), `_descuento_tipo` CHAR(1), `_descuento_personal` INT(11), `_descuento_monto` DECIMAL(10,2), `_descuento_motivo` VARCHAR(200), `_comision_tarjeta` DECIMAL(10,2), `_comision_delivery` DECIMAL(10,2), `_igv` DECIMAL(10,2), `_total` DECIMAL(10,2), `_codigo_operacion` VARCHAR(20), `_fecha_venta` DATETIME, `_idemp` INT, `_idsede` INT, `_crt_fac_cons` INT)   BEGIN

    DECLARE _id_venta INT;
    DECLARE _filtro INT DEFAULT 0;
    DECLARE _filtro2 INT DEFAULT 0;
    DECLARE nro_documento VARCHAR(8);
    DECLARE cod0 INT DEFAULT 1;
    DECLARE err INT DEFAULT 0;
	
	IF _flag = 1 THEN

        SET @serie = (select ts.serie from tm_series ts where ts.id_tipo_doc = _id_tipo_doc  AND ts.idemp = _idemp AND ts.idsede = _idsede);

        SET @numerov =(SELECT numero FROM tm_series WHERE id_tipo_doc = _id_tipo_doc AND idemp = _idemp AND idsede = _idsede);

		SELECT COUNT(*) INTO _filtro FROM tm_venta WHERE serie_doc = @serie AND nro_doc = @numerov AND id_tipo_doc = _id_tipo_doc AND idemp = _idemp AND idsede = _idsede;
        IF _filtro = 0 THEN
			SET nro_documento = (@numerov);
		ELSE
			SET @nro_documento = (SELECT LPAD((@numerov+1),8,'0'));
            SELECT COUNT(*) INTO _filtro2 FROM tm_venta WHERE serie_doc = @serie AND nro_doc = @nro_documento AND estado <> "i" AND id_tipo_doc = _id_tipo_doc AND idemp = _idemp AND idsede = _idsede;
            IF _filtro2 = 0 THEN 
				SET nro_documento = (@nro_documento);
            ELSE
				SET cod0 =(err);/*Serie correlatio ya existe*/
            END IF;
            
		END IF;
        
        IF cod0 = 0 THEN
			SELECT cod0 AS id_venta;
		ELSE
			INSERT INTO tm_venta (id_pedido, id_tipo_pedido, id_cliente, id_tipo_doc, id_pago, id_usu, id_apc, serie_doc, nro_doc, pago_efe_none, descuento_tipo, descuento_personal, descuento_monto, descuento_motivo, comision_tarjeta, comision_delivery, igv, total, codigo_operacion, fecha_venta, idemp, idsede, crt_fac_cons)
			VALUES (_id_pedido, _tipo_pedido, _id_cliente, _id_tipo_doc, _id_pago,_id_usu,_id_apc, @serie, nro_documento, _pago_efe_none, _descuento_tipo, _descuento_personal, _descuento_monto, _descuento_motivo, _comision_tarjeta, _comision_delivery, _igv, _total, _codigo_operacion, _fecha_venta, _idemp, _idsede, _crt_fac_cons);
			SELECT @@IDENTITY INTO @id;
            
            UPDATE tm_series SET numero = nro_documento WHERE id_tipo_doc = _id_tipo_doc AND idemp = _idemp AND idsede = _idsede;
			
			/* DIVIDIR CUENTA 1 = FALSE, 2 = TRUE */
			IF _dividir_cuenta = 1 THEN
			
				IF _tipo_pedido = 1 THEN	
					SELECT id_mesa INTO @idMesa FROM tm_pedido_mesa WHERE id_pedido = _id_pedido;
					UPDATE tm_mesa SET estado = 'a' WHERE id_mesa = @idMesa;
					UPDATE tm_pedido SET estado = 'd' WHERE id_pedido = _id_pedido;
				elseIF _tipo_pedido = 2 then
					UPDATE tm_pedido SET estado = 'b' WHERE id_pedido = _id_pedido;
					UPDATE tm_pedido_llevar SET fecha_entrega = _fecha_venta WHERE id_pedido = _id_pedido;
				ELSEIF _tipo_pedido = 3 THEN
				
					UPDATE tm_pedido SET id_apc = _id_apc, id_usu = _id_usu, estado = _tipo_entrega WHERE id_pedido = _id_pedido;
					
					if _tipo_entrega = 'c' then
						UPDATE tm_pedido_delivery SET fecha_envio = _fecha_venta WHERE id_pedido = _id_pedido;
					elseif _tipo_entrega = 'd' then
						UPDATE tm_pedido_delivery SET fecha_entrega = _fecha_venta WHERE id_pedido = _id_pedido;
					end if;
					/*
					UPDATE tm_pedido SET id_apc = _id_apc, id_usu = _id_usu, estado = 'b' WHERE id_pedido = _id_pedido;
					UPDATE tm_pedido_delivery SET fecha_preparacion = _fecha_venta WHERE id_pedido = _id_pedido;
					*/
				END IF;
			END IF;
			SELECT @id AS id_venta;
		 END IF;
	END IF;
	END$$

DROP PROCEDURE IF EXISTS `usp_restEmitirVentaDet`$$
CREATE PROCEDURE `usp_restEmitirVentaDet` (`_flag` INT(11), `_id_venta` INT(11), `_id_pedido` INT(11), `_fecha` DATETIME, `_idemp` INT, `_idsede` INT)   BEGIN
    
	DECLARE _idprod INT; 
	DECLARE _cantidad1 INT;
	DECLARE _precio1 FLOAT;
	DECLARE _receta INT;
	DECLARE _tipopedido INT;
    DECLARE _crt_stock INT;
	DECLARE done INT DEFAULT 0;
	DECLARE primera CURSOR FOR SELECT dv.id_prod, SUM(dv.cantidad) AS cantidad, dv.precio,  if(p.id_tipo = 2,1,pp.receta) AS receta, p.id_tipo, pp.crt_stock FROM tm_detalle_venta AS dv INNER JOIN tm_producto_pres AS pp
	ON dv.id_prod = pp.id_pres LEFT JOIN tm_producto AS p ON pp.id_prod = p.id_prod WHERE dv.id_venta = _id_venta AND dv.idemp = _idemp GROUP BY dv.id_prod;
	DECLARE segunda CURSOR FOR SELECT i.id_tipo_ins,i.id_ins,i.cant,v.ins_cos FROM tm_producto_ingr AS i INNER JOIN v_insprod AS v ON i.id_ins = v.id_ins AND i.id_tipo_ins = v.id_tipo_ins WHERE i.id_pres = _idprod AND i.idemp = _idemp;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
	
	OPEN primera;
	REPEAT
	
	FETCH primera INTO _idprod, _cantidad1, _precio1, _receta, _tipopedido,_crt_stock;
	IF NOT done THEN
			
		UPDATE tm_detalle_pedido SET cantidad = (cantidad - _cantidad1) WHERE id_pedido = _id_pedido AND id_pres = _idprod AND estado <> 'i' LIMIT 1;
	
		IF _receta = 1 THEN
			
			IF _tipopedido = 2 THEN
				IF _crt_stock = 1 THEN
					INSERT INTO tm_inventario (id_tipo_ope,id_ope,id_tipo_ins,id_ins,cos_uni,cant,fecha_r,idemp,idsede) VALUES (2,_id_venta,2,_idprod,_precio1,_cantidad1,_fecha,_idemp,_idsede);
				END IF;
			ELSEIF _tipopedido = 1 THEN
				
				block2: BEGIN
				
						DECLARE donesegunda INT DEFAULT 0;
						DECLARE _tipoinsumo2 INT;
						DECLARE _idinsumo2 INT;
						DECLARE xx FLOAT;
						DECLARE _cantidad2 FLOAT;
						DECLARE _precio2 FLOAT;
						DECLARE tercera CURSOR FOR SELECT i.id_tipo_ins,i.id_ins,i.cant,v.ins_cos FROM tm_producto_ingr AS i INNER JOIN v_insprod AS v ON i.id_ins = v.id_ins AND i.id_tipo_ins = v.id_tipo_ins WHERE i.id_pres = _idinsumo2;
						DECLARE CONTINUE HANDLER FOR NOT FOUND SET donesegunda = 1;
					
					OPEN segunda;
					REPEAT
			
					FETCH segunda INTO _tipoinsumo2,_idinsumo2,_cantidad2, _precio2;
						IF NOT donesegunda THEN
						
							IF _tipoinsumo2 = 1 OR _tipoinsumo2 = 2 THEN
							
								SET xx = _cantidad2 * _cantidad1;
								INSERT INTO tm_inventario (id_tipo_ope,id_ope,id_tipo_ins,id_ins,cos_uni,cant,fecha_r,idemp,idsede) VALUES (2,_id_venta,_tipoinsumo2,_idinsumo2,_precio2,xx,_fecha,_idemp,_idsede);
							
							ELSEIF _tipoinsumo2 = 3 then
								SET xx = _cantidad2 * _cantidad1;
								INSERT INTO tm_inventario (id_tipo_ope,id_ope,id_tipo_ins,id_ins,cos_uni,cant,fecha_r,idemp,idsede) VALUES (2,_id_venta,_tipoinsumo2,_idinsumo2,_precio2,xx,_fecha,_idemp,_idsede);
								block3: BEGIN
										DECLARE donetercera INT DEFAULT 0;
										DECLARE _tipoinsumo3 INT;
										DECLARE _idinsumo3 INT;
										DECLARE yy FLOAT;
										DECLARE _cantidad3 FLOAT;
										DECLARE _precio3 FLOAT;
										DECLARE CONTINUE HANDLER FOR NOT FOUND SET donetercera = 1;
							
									OPEN tercera;
									REPEAT
							
									FETCH tercera INTO _tipoinsumo3,_idinsumo3,_cantidad3,_precio3;
										IF NOT donetercera THEN
											
										SET yy = _cantidad1 * _cantidad2 * _cantidad3;
										INSERT INTO tm_inventario (id_tipo_ope,id_ope,id_tipo_ins,id_ins,cos_uni,cant,fecha_r,idemp,idsede) VALUES (2,_id_venta,_tipoinsumo3,_idinsumo3,_precio3,yy,_fecha,_idemp,_idsede);
									
										END IF;
									UNTIL donetercera END REPEAT;
									CLOSE tercera;
									
								END block3;
								
							end if;
							
						END IF;
							
					UNTIL donesegunda END REPEAT;
					CLOSE segunda;
					
				END block2;
				
			END IF;
		END IF;	
	END IF;
	UNTIL done END REPEAT;
	CLOSE primera;
    END$$

DROP PROCEDURE IF EXISTS `usp_restOpcionesMesa`$$
CREATE PROCEDURE `usp_restOpcionesMesa` (IN `_flag` INT(11), IN `_cod_mesa_origen` INT(11), IN `_cod_mesa_destino` INT(11), IN `_idemp` INT, IN `_idsede` INT)   BEGIN
	DECLARE _filtro INT DEFAULT 0;
	if _flag = 1 then
			
			SELECT COUNT(*) INTO _filtro FROM tm_mesa WHERE id_mesa = _cod_mesa_origen AND estado = 'i' AND idemp = _idemp AND idsede = _idsede;
		
		if _filtro = 1 then 
			SELECT id_pedido INTO @cod FROM v_listar_mesas WHERE id_mesa = _cod_mesa_origen AND idemp = _idemp AND idsede = _idsede;
			UPDATE tm_mesa SET estado = 'a' WHERE id_mesa = _cod_mesa_origen;
			UPDATE tm_mesa SET estado = 'i' WHERE id_mesa = _cod_mesa_destino;
			UPDATE tm_pedido_mesa SET id_mesa = _cod_mesa_destino WHERE id_pedido = @cod;
			
			SELECT _filtro AS cod;
		ELSE
			SELECT _filtro AS cod;
		end if;
	end if;
	
	IF _flag = 2 THEN
			
			SELECT COUNT(*) INTO _filtro FROM tm_mesa WHERE id_mesa = _cod_mesa_origen AND estado = 'i';
		
		IF _filtro = 1 THEN 
			SELECT id_pedido INTO @cod_1 FROM v_listar_mesas WHERE id_mesa = _cod_mesa_origen AND idemp = _idemp AND idsede = _idsede;
			SELECT id_pedido INTO @cod_2 FROM v_listar_mesas WHERE id_mesa = _cod_mesa_destino AND idemp = _idemp AND idsede = _idsede;
			UPDATE tm_detalle_pedido SET id_pedido = @cod_2 WHERE id_pedido = @cod_1;
			
				if _cod_mesa_origen = _cod_mesa_destino then
					UPDATE tm_mesa SET estado = 'i' WHERE id_mesa = _cod_mesa_origen;
				else
					UPDATE tm_mesa SET estado = 'a' WHERE id_mesa = _cod_mesa_origen;
					UPDATE tm_pedido SET estado = 'z' WHERE id_pedido = @cod_1;
				end if;
			
			SELECT _filtro AS cod;
		ELSE
			SELECT _filtro AS cod;
		END IF;
	END IF;
    END$$

DROP PROCEDURE IF EXISTS `usp_restRegCliente`$$
CREATE PROCEDURE `usp_restRegCliente` (IN `_flag` INT(11), IN `_id_cliente` INT(11), IN `_tipo_cliente` INT(11), IN `_dni` VARCHAR(10), IN `_ruc` VARCHAR(13), IN `_nombres` VARCHAR(200), IN `_razon_social` VARCHAR(100), IN `_telefono` INT(11), IN `_fecha_nac` DATE, IN `_correo` VARCHAR(100), IN `_direccion` VARCHAR(300), IN `_referencia` VARCHAR(100), IN `_idemp` INT, IN `_idsede` INT)   BEGIN
	DECLARE _filtro INT DEFAULT 1;
	DECLARE _numero_documento INT DEFAULT 0;
	
	IF _flag = 1 THEN
	
		IF _tipo_cliente = 1 THEN
			SELECT COUNT(*) INTO _filtro FROM tm_cliente WHERE dni = _dni AND idemp = _idemp;
			SET _numero_documento = _dni;
		ELSEIF _tipo_cliente = 2 THEN
			SELECT COUNT(*) INTO _filtro FROM tm_cliente WHERE ruc = _ruc AND idemp = _idemp;
			SET _numero_documento = '2';
		END IF;
	
		IF _filtro = 0 OR _numero_documento = '00000000' THEN
		
			INSERT INTO tm_cliente (tipo_cliente,dni,ruc,nombres,razon_social,telefono,fecha_nac,correo,direccion,referencia,idemp,idsede) 
			VALUES (_tipo_cliente, _dni, _ruc, _nombres, _razon_social, _telefono, _fecha_nac, _correo, _direccion, _referencia, _idemp, _idsede);
			
			SELECT @@IDENTITY INTO @id;
			
			SELECT _filtro AS cod,@id AS id_cliente;
		ELSE
			SELECT _filtro AS cod;
		END IF;
	END IF;
	
	IF _flag = 2 THEN
	
		UPDATE tm_cliente SET tipo_cliente = _tipo_cliente, dni = _dni, ruc = _ruc, nombres = _nombres, 
		razon_social = _razon_social, telefono = _telefono, fecha_nac = _fecha_nac, correo = _correo, direccion = _direccion, referencia = _referencia
		WHERE id_cliente = _id_cliente AND idemp = _idemp;
		
		SELECT _id_cliente AS id_cliente;
		
	END IF;
END$$

DROP PROCEDURE IF EXISTS `usp_restRegDelivery`$$
CREATE PROCEDURE `usp_restRegDelivery` (IN `_flag` INT(11), IN `_tipo_canal` INT(11), IN `_id_tipo_pedido` INT(11), IN `_id_apc` INT(11), IN `_id_usu` INT(11), IN `_fecha_pedido` DATETIME, IN `_id_cliente` INT(11), IN `_id_repartidor` INT(11), IN `_tipo_entrega` INT(11), IN `_tipo_pago` INT(11), IN `_pedido_programado` INT(11), IN `_hora_entrega` TIME, IN `_nombre_cliente` VARCHAR(100), IN `_telefono_cliente` VARCHAR(20), IN `_direccion_cliente` VARCHAR(100), IN `_referencia_cliente` VARCHAR(100), IN `_email_cliente` VARCHAR(200), IN `_idemp` INT, IN `_idsede` INT)   BEGIN
	DECLARE _filtro INT DEFAULT 1;
	
	IF _flag = 1 THEN
		
		INSERT INTO tm_pedido (id_tipo_pedido,id_apc,id_usu,fecha_pedido,idemp,idsede) VALUES (_id_tipo_pedido, _id_apc, _id_usu, _fecha_pedido, _idemp, _idsede);
		
		SELECT @@IDENTITY INTO @id;
		SELECT CONCAT(LPAD(COUNT(t.nro_pedido)+1,5,'0')) AS codigo INTO @nro_pedido FROM tm_pedido_delivery AS t INNER JOIN tm_pedido AS p ON t.id_pedido = p.id_pedido WHERE p.id_tipo_pedido = 3  and p.estado <> 'z' AND t.idemp = _idemp AND t.idsede = _idsede order by t.nro_pedido DESC LIMIT 1; 		
			
            IF _id_cliente = 1 THEN
				INSERT INTO tm_cliente (tipo_cliente,nombres,telefono,direccion,referencia,idemp,idsede) VALUES (1,_nombre_cliente,_telefono_cliente,_direccion_cliente,_referencia_cliente,_idemp,_idsede);
				SELECT @@IDENTITY INTO @id_cliente;
				INSERT INTO tm_pedido_delivery (id_pedido,tipo_canal,id_cliente,id_repartidor,tipo_entrega,tipo_pago,pedido_programado,hora_entrega,nro_pedido,nombre_cliente,telefono_cliente,direccion_cliente,referencia_cliente,email_cliente,idemp,idsede) VALUES (@id, _tipo_canal, @id_cliente, _id_repartidor, _tipo_entrega, _tipo_pago, _pedido_programado, _hora_entrega, @nro_pedido, _nombre_cliente, _telefono_cliente, _direccion_cliente, _referencia_cliente, _email_cliente, _idemp, _idsede);
			ELSE
				UPDATE tm_cliente SET nombres = _nombre_cliente, telefono = _telefono_cliente, direccion = _direccion_cliente, referencia = _referencia_cliente WHERE id_cliente = _id_cliente; 		
				INSERT INTO tm_pedido_delivery (id_pedido,tipo_canal,id_cliente,id_repartidor,tipo_entrega,tipo_pago,pedido_programado,hora_entrega,nro_pedido,nombre_cliente,telefono_cliente,direccion_cliente,referencia_cliente,email_cliente,idemp,idsede) VALUES (@id, _tipo_canal, _id_cliente, _id_repartidor, _tipo_entrega, _tipo_pago, _pedido_programado, _hora_entrega, @nro_pedido, _nombre_cliente, _telefono_cliente, _direccion_cliente, _referencia_cliente, _email_cliente, _idemp, _idsede);
			END IF;
			
		SELECT _filtro AS fil, @id AS id_pedido;
	
	END IF;
    END$$

DROP PROCEDURE IF EXISTS `usp_restRegDeliveryWeb`$$
CREATE PROCEDURE `usp_restRegDeliveryWeb` (IN `_flag` INT(11), IN `_tipo_canal` INT, IN `_id_tipo_pedido` INT, IN `_id_apc` INT, IN `_id_usu` INT, IN `_fecha_pedido` DATETIME, IN `_paga_con` DECIMAL(10,2), IN `_id_cliente` INT, IN `_tipo_entrega` INT, IN `_tipo_pago` INT, IN `_pedido_programado` INT, IN `_hora_entrega` TIME, IN `_nombre_cliente` VARCHAR(100), IN `_telefono_cliente` VARCHAR(20), IN `_direccion_cliente` VARCHAR(100), IN `_referencia_cliente` VARCHAR(100), IN `_email_cliente` VARCHAR(200), IN `_comentarios` VARCHAR(160), IN `_empresa` INT, IN `_sedeEmp` INT)   BEGIN

	DECLARE _filtro INT DEFAULT 1;
	
	IF _flag = 1 THEN
		
        UPDATE tm_cliente SET direccion = _direccion_cliente, referencia = _referencia_cliente WHERE id_cliente = _id_cliente;
		
		INSERT INTO tm_pedido (id_tipo_pedido,id_apc,id_usu,fecha_pedido,idemp,idsede) VALUES (_id_tipo_pedido,_id_apc,_id_usu,_fecha_pedido,_empresa,_sedeEmp);
		SELECT @@IDENTITY INTO @id;
		SELECT CONCAT(LPAD(COUNT(t.nro_pedido)+1,5,'0')) AS codigo INTO @nro_pedido FROM tm_pedido_delivery AS t INNER JOIN tm_pedido AS p ON t.id_pedido = p.id_pedido WHERE p.id_tipo_pedido = 3  and p.estado <> 'z' AND t.idemp = _empresa AND t.idsede = _sedeEmp order by t.nro_pedido DESC LIMIT 1; 
	
		INSERT INTO tm_pedido_delivery(id_pedido,tipo_canal,id_cliente,tipo_entrega,tipo_pago,pedido_programado,hora_entrega,paga_con,nro_pedido,nombre_cliente,telefono_cliente,direccion_cliente,referencia_cliente,email_cliente,comentarios,idemp,idsede) VALUES (@id,_tipo_canal,_id_cliente,_tipo_entrega,_tipo_pago,_pedido_programado,_hora_entrega,_paga_con,@nro_pedido,_nombre_cliente,_telefono_cliente,_direccion_cliente,_referencia_cliente,_email_cliente,_comentarios,_empresa,_sedeEmp);

		SELECT @id AS id_pedido;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `usp_restRegDetaPedidoWeb`$$
CREATE PROCEDURE `usp_restRegDetaPedidoWeb` (IN `_flag` INT, IN `_id_pedido` INT, IN `_id_usu` INT, IN `_id_pres` INT, IN `_cantidad` INT, IN `_precio` DECIMAL(10,1), IN `_comentario` VARCHAR(100), IN `_fecha_pedido` DATETIME, IN `_estado` VARCHAR(5), IN `_precioTopico` DECIMAL(10,2), IN `_detatopico` VARCHAR(60), IN `_idemp` INT, IN `_idsede` INT)   BEGIN

	INSERT INTO tm_detalle_pedido(id_pedido,id_usu,id_pres,cantidad,cant,precio,comentario,fecha_pedido,fecha_envio,estado,precioTopico,detatopico,idemp,idsede) VALUES (_id_pedido,_id_usu,_id_pres,_cantidad,_cantidad,_precio,_comentario,_fecha_pedido,'1000-01-01 00:00:00',_estado,_precioTopico,_detatopico,_idemp,_idsede);

END$$

DROP PROCEDURE IF EXISTS `usp_restRegMesa`$$
CREATE PROCEDURE `usp_restRegMesa` (IN `_flag` INT(11), IN `_id_tipo_pedido` INT(11), IN `_id_apc` INT(11), IN `_id_usu` INT(11), IN `_fecha_pedido` DATETIME, IN `_id_mesa` INT(11), IN `_id_mozo` INT(11), IN `_nomb_cliente` VARCHAR(45), IN `_nro_personas` INT(11), IN `_idemp` INT, IN `_idsede` INT)   BEGIN
	DECLARE _filtro INT DEFAULT 0;
	
		IF _flag = 1 THEN
		
			SELECT COUNT(*) INTO _filtro FROM tm_mesa WHERE id_mesa = _id_mesa AND estado = 'a';
			
			if _filtro = 1 THEN
				
				INSERT INTO tm_pedido (id_tipo_pedido,id_apc,id_usu,fecha_pedido,idemp,idsede) VALUES (_id_tipo_pedido,_id_apc,_id_usu,_fecha_pedido,_idemp,_idsede);
				
				SELECT @@IDENTITY INTO @id;
				
				INSERT INTO tm_pedido_mesa (id_pedido,id_mesa,id_mozo,nomb_cliente,nro_personas,idemp,idsede) VALUES (@id,_id_mesa,_id_mozo,_nomb_cliente,_nro_personas,_idemp,_idsede);
				
				SELECT _filtro AS fil, @id AS id_pedido;
				
				UPDATE tm_mesa SET estado = 'i' WHERE id_mesa = _id_mesa;
			ELSE
				SELECT _filtro AS fil;
			END IF;
		END IF;
	END$$

DROP PROCEDURE IF EXISTS `usp_restRegMostrador`$$
CREATE PROCEDURE `usp_restRegMostrador` (IN `_flag` INT(11), IN `_id_tipo_pedido` INT(11), IN `_id_apc` INT(11), IN `_id_usu` INT(11), IN `_fecha_pedido` DATETIME, IN `_nomb_cliente` VARCHAR(45), IN `_idemp` INT, IN `_idsede` INT)   BEGIN
	DECLARE _filtro INT DEFAULT 1;
	
	IF _flag = 1 THEN
		
		INSERT INTO tm_pedido (id_tipo_pedido,id_apc,id_usu,fecha_pedido,idemp,idsede) VALUES (_id_tipo_pedido,_id_apc,_id_usu,_fecha_pedido,_idemp,_idsede);
		
		SELECT @@IDENTITY INTO @id;
		
		SELECT CONCAT(LPAD(count(t.nro_pedido)+1,5,'0')) AS codigo INTO @nro_pedido FROM tm_pedido_llevar AS t INNER JOIN tm_pedido AS p ON t.id_pedido = p.id_pedido WHERE p.id_tipo_pedido = 2 and p.estado <> 'z' AND p.idemp = _idemp AND p.idsede = _idsede; 
		
		INSERT INTO tm_pedido_llevar (id_pedido,nro_pedido,nomb_cliente,idemp,idsede) VALUES (@id, @nro_pedido, _nomb_cliente,_idemp,_idsede);
		
		SELECT _filtro AS fil, @id AS id_pedido;
	
	END IF;
	END$$

DROP PROCEDURE IF EXISTS `usp_sedeempresaconfi`$$
CREATE PROCEDURE `usp_sedeempresaconfi` (IN `_id_empresa` INT, IN `_nombre` VARCHAR(150), IN `_direccion` VARCHAR(150), IN `_departamento` VARCHAR(50), IN `_provincia` VARCHAR(50), IN `_distrito` VARCHAR(50), IN `_estado` VARCHAR(10), IN `_telefono` VARCHAR(15))   BEGIN
	DECLARE _filtr INT DEFAULT 1;
    
	INSERT INTO tm_sedes(id_empresa, nombre, direccion, departamento, provincia, distrito, estado,telefono) VALUES (_id_empresa,_nombre,_direccion,_departamento,_provincia,_distrito,_estado,_telefono);
	SELECT @@IDENTITY INTO @id;   

	INSERT INTO tm_configuracion(pc_name, pc_ip, print_com, print_pre, print_cpe, opc_01, opc_02, opc_03, bloqueo, cod_seg, idemp, idsede, principal) 
    VALUES ('ADMIN-PC' , '126.1.1.1', 0, 0, 0, 0, 0, 0, 0, '123456',_id_empresa, @id, 0);
	SELECT _filtr AS cod;
END$$

DROP PROCEDURE IF EXISTS `usp_tableroControl`$$
CREATE PROCEDURE `usp_tableroControl` (IN `_flag` INT(11), IN `_codDia` INT(11), IN `_fecha` DATE, IN `_feSei` DATE, IN `_feCin` DATE, IN `_feCua` DATE, IN `_feTre` DATE, IN `_feDos` DATE, IN `_feUno` DATE)   BEGIN
	if _flag = 1 then
				SELECT dia,margen into @dia,@margen FROM tm_margen_venta WHERE cod_dia = _codDia;
				SELECT IFNULL(SUM(total-descuento),0) into @siete FROM tm_venta WHERE DATE(fecha_venta) = _fecha;
				SELECT IFNULL(SUM(total-descuento),0) into @seis FROM tm_venta WHERE DATE(fecha_venta) = _feSei;
				SELECT IFNULL(SUM(total-descuento),0) into @cinco FROM tm_venta WHERE DATE(fecha_venta) = _feCin;
				SELECT IFNULL(SUM(total-descuento),0) into @cuatro FROM tm_venta WHERE DATE(fecha_venta) = _feCua;
				SELECT IFNULL(SUM(total-descuento),0) into @tres FROM tm_venta WHERE DATE(fecha_venta) = _feTre;
				SELECT IFNULL(SUM(total-descuento),0) into @dos FROM tm_venta WHERE DATE(fecha_venta) = _feDos;
				SELECT IFNULL(SUM(total-descuento),0) into @uno FROM tm_venta WHERE DATE(fecha_venta) = _feUno;
		
		select @dia as dia,@margen as margen,@siete as siete,@seis as seis,@cinco as cinco,@cuatro as cuatro,@tres as tres,@dos as dos,@uno as uno;	
	end if;
    END$$

DROP PROCEDURE IF EXISTS `usp_updateClienteEmp`$$
CREATE PROCEDURE `usp_updateClienteEmp` (IN `_idemp` INT, IN `_idusu` INT, IN `_ruc` VARCHAR(20), IN `_razon_social` VARCHAR(200), IN `_nombre_comercial` VARCHAR(200), IN `_direccion_fiscal` VARCHAR(200), IN `_ubigeo` VARCHAR(8), IN `_departamento` VARCHAR(50), IN `_provincia` VARCHAR(50), IN `_distrito` VARCHAR(50), IN `_logo` VARCHAR(45), IN `_celular` VARCHAR(50), IN `_email` VARCHAR(120), IN `_namesubdominio` VARCHAR(50), IN `_urlapi` VARCHAR(100), IN `_passentorno` VARCHAR(200), IN `_usuario` VARCHAR(50), IN `_passusu` VARCHAR(50), IN `_crt_plan` INT, IN `_crt_sede` INT)   BEGIN
	DECLARE _filtro INT DEFAULT 1;
    DECLARE _filtr INT DEFAULT 1;
	DECLARE _resp INT DEFAULT 2;
    
    UPDATE tm_empresa SET ruc=_ruc,razon_social=_razon_social,nombre_comercial=_nombre_comercial,
            direccion_fiscal=_direccion_fiscal,ubigeo=_ubigeo,departamento=_departamento,provincia=_provincia,distrito=_distrito,
            logo=_logo,celular=_celular,email=_email,namesubdominio=_namesubdominio,urlapi=_urlapi,
            passentorno=_passentorno,crt_plan = _crt_plan,crt_sede = _crt_sede WHERE id_de=_idemp;
            
	UPDATE tm_usuario SET email=_email,usuario=_usuario,contrasena=_passusu WHERE id_usu=_idusu and idEmpresa=_idemp;
	SELECT _resp AS cod;

    /*SELECT count(*) INTO _filtr FROM tm_usuario WHERE contrasena = _passusu;
		IF _filtr = 1 THEN
			
            UPDATE tm_empresa SET ruc=_ruc,razon_social=_razon_social,nombre_comercial=_nombre_comercial,
            direccion_fiscal=_direccion_fiscal,ubigeo=_ubigeo,departamento=_departamento,provincia=_provincia,distrito=_distrito,
            logo=_logo,celular=_celular,email=_email,namesubdominio=_namesubdominio,urlapi=_urlapi,
            passentorno=_passentorno WHERE id_de=_idemp;
            
            UPDATE tm_usuario SET email=_email,usuario=_usuario,contrasena=_passusu WHERE id_usu=_idusu and idEmpresa=_idemp;

            SELECT _resp AS cod;
		ELSE
			UPDATE tm_empresa SET ruc=_ruc,razon_social=_razon_social,nombre_comercial=_nombre_comercial,
            direccion_fiscal=_direccion_fiscal,ubigeo=_ubigeo,departamento=_departamento,provincia=_provincia,distrito=_distrito,
            logo=_logo,celular=_celular,email=_email,namesubdominio=_namesubdominio,urlapi=_urlapi,
            passentorno=_passentorno WHERE id_de=_idemp;
            
            UPDATE tm_usuario SET email=_email,usuario=_usuario WHERE id_usu=_idusu and idEmpresa=_idemp;
            
			SELECT _resp AS cod;
		END IF;*/
    
END$$

DROP PROCEDURE IF EXISTS `ventaActualizaInventario`$$
CREATE PROCEDURE `ventaActualizaInventario` (IN `_idProdu` INT(11), IN `_id_venta` INT(11), IN `cantidad` INT(11), `precio` DECIMAL(10,2), `_fecha` DATETIME, `_idemp` INT, `_idsede` INT)   BEGIN
	
    /*set @crtStock =(select crt_stock from tm_producto_pres where id_pres = _idProdu AND idemp = _idemp);*/
    SET @crtStock =(select crt_stock from tm_producto as tp
			inner join tm_producto_pres as tpp on tp.id_prod = tpp.id_prod
			where tpp.id_pres = _idProdu AND tp.id_tipo = 1 AND tpp.idemp = _idemp);
	IF @crtStock = 1 THEN
		INSERT INTO tm_inventario (id_tipo_ope,id_ope,id_tipo_ins,id_ins,cos_uni,cant,fecha_r,idemp,idsede) VALUES (2,_id_venta,3,_idProdu,precio,cantidad,_fecha,_idemp,_idsede);
	END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comunicacion_baja`
--

DROP TABLE IF EXISTS `comunicacion_baja`;
CREATE TABLE IF NOT EXISTS `comunicacion_baja` (
  `id_comunicacion` int NOT NULL AUTO_INCREMENT,
  `fecha_registro` datetime DEFAULT NULL,
  `fecha_baja` date DEFAULT NULL,
  `fecha_referencia` date DEFAULT NULL,
  `tipo_doc` char(2) DEFAULT NULL,
  `serie_doc` char(4) DEFAULT NULL,
  `num_doc` varchar(8) DEFAULT NULL,
  `nombre_baja` varchar(200) DEFAULT NULL,
  `correlativo` varchar(5) DEFAULT NULL,
  `enviado_sunat` char(1) DEFAULT NULL,
  `hash_cpe` varchar(100) DEFAULT NULL,
  `hash_cdr` varchar(100) DEFAULT NULL,
  `code_respuesta_sunat` varchar(5) DEFAULT NULL,
  `descripcion_sunat_cdr` varchar(300) DEFAULT NULL,
  `name_file_sunat` varchar(80) DEFAULT NULL,
  `estado` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`id_comunicacion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `horarioatencion`
--

DROP TABLE IF EXISTS `horarioatencion`;
CREATE TABLE IF NOT EXISTS `horarioatencion` (
  `idhorario` int NOT NULL AUTO_INCREMENT,
  `id_landing` int DEFAULT NULL,
  `nombredia` varchar(25) DEFAULT NULL,
  `apertura` varchar(45) DEFAULT NULL,
  `cierre` varchar(45) DEFAULT NULL,
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`idhorario`),
  KEY `fk_landing_horaten` (`id_landing`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `horarioatencion`
--

INSERT INTO `horarioatencion` (`idhorario`, `id_landing`, `nombredia`, `apertura`, `cierre`, `idemp`, `idsede`) VALUES
(1, 1, 'Domingo', '9:00 AM', '10:00 PM', 1, 1),
(2, 1, 'Lunes', '10:00 AM', '11:00 PM', 1, 1),
(3, 1, 'Martes', '10:00 AM', '11:00 PM', 1, 1),
(4, 1, 'Miercoles', '10:00 AM', '8:00 PM', 1, 1),
(5, 1, 'Jueves', '8:00 AM', '4:00 PM', 1, 1),
(6, 1, 'Viernes', '10:00 AM', '11:00 PM', 1, 1),
(7, 1, 'Sabado', '10:00 AM', '11:00 PM', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedido_autoservicio`
--

DROP TABLE IF EXISTS `pedido_autoservicio`;
CREATE TABLE IF NOT EXISTS `pedido_autoservicio` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nro_pedido` varchar(80) DEFAULT NULL,
  `id_tipo_pedido` int DEFAULT NULL,
  `fecha_pedido` datetime DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  `idemp` int DEFAULT NULL,
  `nombrecliente` varchar(150) DEFAULT NULL,
  `opcionsede` int DEFAULT NULL,
  `opcionsalon` int DEFAULT NULL,
  `opcionmesa` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedido_detalle_autoservicio`
--

DROP TABLE IF EXISTS `pedido_detalle_autoservicio`;
CREATE TABLE IF NOT EXISTS `pedido_detalle_autoservicio` (
  `id` int DEFAULT NULL,
  `id_pres` int DEFAULT NULL,
  `cantidad` int DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `fecha_pedido` datetime DEFAULT NULL,
  `estado` varchar(5) DEFAULT NULL,
  `precioTopico` decimal(10,2) DEFAULT NULL,
  `detatopico` varchar(300) DEFAULT NULL,
  `nota` varchar(255) DEFAULT NULL,
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  `motivo_anulacion` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `resumen_diario`
--

DROP TABLE IF EXISTS `resumen_diario`;
CREATE TABLE IF NOT EXISTS `resumen_diario` (
  `id_resumen` int NOT NULL AUTO_INCREMENT,
  `fecha_registro` datetime DEFAULT NULL,
  `fecha_resumen` date DEFAULT NULL,
  `fecha_referencia` date DEFAULT NULL,
  `correlativo` varchar(5) DEFAULT NULL,
  `enviado_sunat` char(1) DEFAULT NULL,
  `hash_cpe` varchar(100) DEFAULT NULL,
  `hash_cdr` varchar(100) DEFAULT NULL,
  `code_respuesta_sunat` varchar(5) DEFAULT NULL,
  `descripcion_sunat_cdr` varchar(300) DEFAULT NULL,
  `name_file_sunat` varchar(80) DEFAULT NULL,
  `estado` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`id_resumen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `resumen_diario_detalle`
--

DROP TABLE IF EXISTS `resumen_diario_detalle`;
CREATE TABLE IF NOT EXISTS `resumen_diario_detalle` (
  `id_detalle` int NOT NULL AUTO_INCREMENT,
  `id_resumen` int DEFAULT NULL,
  `id_venta` int DEFAULT NULL,
  `status_code` int DEFAULT NULL,
  PRIMARY KEY (`id_detalle`),
  KEY `FK_RDD_RES` (`id_resumen`),
  KEY `FK_RDD_VEN` (`id_venta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_almacen`
--

DROP TABLE IF EXISTS `tm_almacen`;
CREATE TABLE IF NOT EXISTS `tm_almacen` (
  `id_alm` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  `estado` varchar(5) DEFAULT 'a',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_alm`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_almacen`
--

INSERT INTO `tm_almacen` (`id_alm`, `nombre`, `estado`, `idemp`, `idsede`) VALUES
(1, 'ABARROTES E INSUMOS', 'a', 1, 1),
(2, 'BEBIDAS, GASEOSAS Y CERVEZAS', 'a', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_aper_cierre`
--

DROP TABLE IF EXISTS `tm_aper_cierre`;
CREATE TABLE IF NOT EXISTS `tm_aper_cierre` (
  `id_apc` int NOT NULL AUTO_INCREMENT,
  `id_usu` int NOT NULL,
  `id_caja` int NOT NULL,
  `id_turno` int NOT NULL,
  `fecha_aper` datetime DEFAULT NULL,
  `monto_aper` decimal(10,2) DEFAULT '0.00',
  `fecha_cierre` datetime DEFAULT NULL,
  `monto_cierre` decimal(10,2) DEFAULT '0.00',
  `monto_sistema` decimal(10,2) DEFAULT '0.00',
  `stock_pollo` varchar(11) NOT NULL DEFAULT '0',
  `estado` varchar(5) DEFAULT 'a',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_apc`),
  KEY `FK_ac_caja` (`id_caja`),
  KEY `FK_ac_turno` (`id_turno`),
  KEY `FK_ac_usu` (`id_usu`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_aper_cierre`
--

INSERT INTO `tm_aper_cierre` (`id_apc`, `id_usu`, `id_caja`, `id_turno`, `fecha_aper`, `monto_aper`, `fecha_cierre`, `monto_cierre`, `monto_sistema`, `stock_pollo`, `estado`, `idemp`, `idsede`) VALUES
(1, 1, 1, 1, '2023-08-26 20:28:47', 100.00, '2023-08-26 23:28:47', 0.00, 0.00, '0', 'a', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_apis`
--

DROP TABLE IF EXISTS `tm_apis`;
CREATE TABLE IF NOT EXISTS `tm_apis` (
  `id_api` int NOT NULL AUTO_INCREMENT,
  `nombreAPI` varchar(50) DEFAULT NULL,
  `rutaApi` varchar(150) DEFAULT NULL,
  `token` varchar(300) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_api`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_apis`
--

INSERT INTO `tm_apis` (`id_api`, `nombreAPI`, `rutaApi`, `token`, `estado`, `idemp`, `idsede`) VALUES
(1, 'LANDING', 'https://tusistema.pe/crear_cuenta.php?', '', 'a', 1, 1),
(2, 'DNI', 'https://apiperu.dev/api/dni/$?api_token=#', 'a45cf685ac30c69184e2d29e6ce7aba8489e0fd3ad142bfa2b385fea232cf53e', 'a', 1, 1),
(3, 'RUC', 'https://apiperu.dev/api/ruc/$?api_token=#', 'a45cf685ac30c69184e2d29e6ce7aba8489e0fd3ad142bfa2b385fea232cf53e', 'a', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_area_prod`
--

DROP TABLE IF EXISTS `tm_area_prod`;
CREATE TABLE IF NOT EXISTS `tm_area_prod` (
  `id_areap` int NOT NULL AUTO_INCREMENT,
  `id_imp` int NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `estado` varchar(5) NOT NULL DEFAULT 'a',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_areap`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_area_prod`
--

INSERT INTO `tm_area_prod` (`id_areap`, `id_imp`, `nombre`, `estado`, `idemp`, `idsede`) VALUES
(1, 1, 'COCINA', 'a', 1, 1),
(2, 1, 'BAR', 'a', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_caja`
--

DROP TABLE IF EXISTS `tm_caja`;
CREATE TABLE IF NOT EXISTS `tm_caja` (
  `id_caja` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  `estado` varchar(5) DEFAULT 'a',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_caja`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_caja`
--

INSERT INTO `tm_caja` (`id_caja`, `descripcion`, `estado`, `idemp`, `idsede`) VALUES
(1, 'CAJA PRINCIPAL', 'c', 1, 1),
(2, 'CAJA 1', 'c', 1, 1),
(3, 'CAJA 2', 'c', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_cliente`
--

DROP TABLE IF EXISTS `tm_cliente`;
CREATE TABLE IF NOT EXISTS `tm_cliente` (
  `id_cliente` int NOT NULL AUTO_INCREMENT,
  `tipo_cliente` int NOT NULL,
  `dni` varchar(10) NOT NULL DEFAULT '00000000',
  `ruc` varchar(13) NOT NULL DEFAULT '0000000000',
  `nombres` varchar(100) NOT NULL,
  `razon_social` varchar(100) DEFAULT NULL,
  `telefono` int NOT NULL,
  `fecha_nac` date NOT NULL DEFAULT '1000-01-01',
  `correo` varchar(100) NOT NULL,
  `direccion` varchar(300) DEFAULT NULL,
  `referencia` varchar(100) NOT NULL DEFAULT 'NA  ',
  `estado` varchar(5) NOT NULL DEFAULT 'a',
  `contrasena` varchar(100) DEFAULT NULL,
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_cliente`
--

INSERT INTO `tm_cliente` (`id_cliente`, `tipo_cliente`, `dni`, `ruc`, `nombres`, `razon_social`, `telefono`, `fecha_nac`, `correo`, `direccion`, `referencia`, `estado`, `contrasena`, `idemp`, `idsede`) VALUES
(1, 1, '00000000', '', 'PUBLICO EN GENERAL', '', 0, '1970-01-01', '', '-', '', 'a', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_compra`
--

DROP TABLE IF EXISTS `tm_compra`;
CREATE TABLE IF NOT EXISTS `tm_compra` (
  `id_compra` int NOT NULL AUTO_INCREMENT,
  `id_prov` int NOT NULL,
  `id_tipo_compra` int NOT NULL,
  `id_tipo_doc` int NOT NULL,
  `id_usu` int DEFAULT NULL,
  `fecha_c` date DEFAULT NULL,
  `hora_c` varchar(45) DEFAULT NULL,
  `serie_doc` varchar(45) DEFAULT NULL,
  `num_doc` varchar(45) DEFAULT NULL,
  `igv` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `descuento` decimal(10,2) DEFAULT NULL,
  `estado` varchar(1) DEFAULT 'a',
  `observaciones` varchar(100) DEFAULT NULL,
  `fecha_reg` datetime DEFAULT NULL,
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_compra`),
  KEY `FK_comp_prov` (`id_prov`),
  KEY `FK_comp_tipoc` (`id_tipo_compra`),
  KEY `FK_comp_tipod` (`id_tipo_doc`),
  KEY `FK_comp_usu` (`id_usu`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_compra_credito`
--

DROP TABLE IF EXISTS `tm_compra_credito`;
CREATE TABLE IF NOT EXISTS `tm_compra_credito` (
  `id_credito` int NOT NULL AUTO_INCREMENT,
  `id_compra` int NOT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `interes` decimal(10,2) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `estado` varchar(5) DEFAULT 'p',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_credito`),
  KEY `FK_CC_ID_COMPRA_idx` (`id_compra`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_compra_detalle`
--

DROP TABLE IF EXISTS `tm_compra_detalle`;
CREATE TABLE IF NOT EXISTS `tm_compra_detalle` (
  `id_compra` int NOT NULL,
  `id_tp` int NOT NULL,
  `id_pres` int NOT NULL,
  `cant` decimal(10,2) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  KEY `FK_CDET_COM` (`id_compra`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_configuracion`
--

DROP TABLE IF EXISTS `tm_configuracion`;
CREATE TABLE IF NOT EXISTS `tm_configuracion` (
  `id_cfg` int NOT NULL AUTO_INCREMENT,
  `zona_hora` varchar(100) DEFAULT NULL,
  `trib_acr` varchar(20) DEFAULT NULL,
  `trib_car` int DEFAULT NULL,
  `di_acr` varchar(20) DEFAULT NULL,
  `di_car` int DEFAULT NULL,
  `imp_acr` varchar(20) DEFAULT NULL,
  `imp_val` decimal(10,2) DEFAULT NULL,
  `mon_acr` varchar(20) DEFAULT NULL,
  `mon_val` varchar(5) DEFAULT NULL,
  `pc_name` varchar(50) DEFAULT NULL,
  `pc_ip` varchar(20) DEFAULT NULL,
  `print_com` int DEFAULT NULL,
  `print_pre` int DEFAULT NULL,
  `print_cpe` int DEFAULT NULL,
  `opc_01` int DEFAULT NULL,
  `opc_02` int DEFAULT NULL,
  `opc_03` int DEFAULT NULL,
  `bloqueo` int DEFAULT NULL,
  `cod_seg` varchar(45) NOT NULL DEFAULT '123456',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  `principal` int DEFAULT NULL,
  `enlace_qr` varchar(250) DEFAULT NULL,
  `msg_impre` varchar(250) DEFAULT NULL,
  `icbper` decimal(10,2) NOT NULL DEFAULT '0.00',
  `img_promocion` varchar(100) DEFAULT 'default.png',
  `print_com_2` int DEFAULT '0',
  PRIMARY KEY (`id_cfg`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_configuracion`
--

INSERT INTO `tm_configuracion` (`id_cfg`, `zona_hora`, `trib_acr`, `trib_car`, `di_acr`, `di_car`, `imp_acr`, `imp_val`, `mon_acr`, `mon_val`, `pc_name`, `pc_ip`, `print_com`, `print_pre`, `print_cpe`, `opc_01`, `opc_02`, `opc_03`, `bloqueo`, `cod_seg`, `idemp`, `idsede`, `principal`, `enlace_qr`, `msg_impre`, `icbper`, `img_promocion`, `print_com_2`) VALUES
(1, 'America/Lima', 'RUC', 11, 'DNI', 8, 'IGV', 18.00, 'Soles', 'S/', 'ADMIN-PC', '', 0, 0, 0, 0, 0, 1, 0, '123456', 1, 1, 1, NULL, NULL, 0.00, 'default.png', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_credito_detalle`
--

DROP TABLE IF EXISTS `tm_credito_detalle`;
CREATE TABLE IF NOT EXISTS `tm_credito_detalle` (
  `id_credito` int DEFAULT NULL,
  `id_usu` int DEFAULT NULL,
  `importe` decimal(10,2) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `egreso` int DEFAULT '0',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  KEY `FK_cred_usu` (`id_usu`),
  KEY `FK_CRED_CRED` (`id_credito`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_detalle_pedido`
--

DROP TABLE IF EXISTS `tm_detalle_pedido`;
CREATE TABLE IF NOT EXISTS `tm_detalle_pedido` (
  `id_pedido` int NOT NULL,
  `id_usu` int NOT NULL,
  `id_pres` int NOT NULL,
  `cantidad` int NOT NULL,
  `cant` int NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `comentario` varchar(100) DEFAULT NULL,
  `fecha_pedido` datetime NOT NULL,
  `fecha_envio` datetime NOT NULL,
  `estado` varchar(5) NOT NULL DEFAULT 'a',
  `precioTopico` decimal(10,2) DEFAULT NULL,
  `detatopico` varchar(60) DEFAULT NULL,
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  `nom_prod_pres` varchar(300) DEFAULT NULL,
  `crt_mod_prod` int DEFAULT '0',
  `motivo_anulacion` varchar(300) DEFAULT NULL,
  KEY `FK_DPED_PRES` (`id_pres`),
  KEY `FK_DPED_PED` (`id_pedido`),
  KEY `FK_DPED_USU` (`id_usu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_detalle_venta`
--

DROP TABLE IF EXISTS `tm_detalle_venta`;
CREATE TABLE IF NOT EXISTS `tm_detalle_venta` (
  `id_venta` int NOT NULL,
  `id_prod` int NOT NULL,
  `cantidad` int NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  `nom_prod_pres` varchar(300) DEFAULT NULL,
  `crt_mod_prod` int DEFAULT '0',
  `costo` float DEFAULT '0',
  `fecha_venta` datetime DEFAULT NULL,
  KEY `FK_DVEN_VEN` (`id_venta`),
  KEY `FK_DVEN_PRES` (`id_prod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_empresa`
--

DROP TABLE IF EXISTS `tm_empresa`;
CREATE TABLE IF NOT EXISTS `tm_empresa` (
  `id_de` int NOT NULL AUTO_INCREMENT,
  `ruc` varchar(20) DEFAULT NULL,
  `razon_social` varchar(200) DEFAULT NULL,
  `nombre_comercial` varchar(200) DEFAULT NULL,
  `direccion_comercial` varchar(200) DEFAULT NULL,
  `direccion_fiscal` varchar(200) DEFAULT NULL,
  `ubigeo` varchar(8) DEFAULT NULL,
  `departamento` varchar(50) DEFAULT NULL,
  `provincia` varchar(50) DEFAULT NULL,
  `distrito` varchar(50) DEFAULT NULL,
  `sunat` int NOT NULL,
  `modo` int DEFAULT NULL,
  `usuariosol` varchar(50) DEFAULT NULL,
  `clavesol` varchar(50) DEFAULT NULL,
  `clavecertificado` varchar(50) DEFAULT NULL,
  `client_id` varchar(45) DEFAULT NULL,
  `client_secret` varchar(45) DEFAULT NULL,
  `logo` varchar(45) DEFAULT NULL,
  `celular` varchar(50) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `namesubdominio` varchar(80) DEFAULT NULL,
  `urlapi` varchar(100) DEFAULT NULL,
  `passentorno` varchar(200) DEFAULT NULL,
  `optimiproceso` varchar(10) DEFAULT NULL,
  `crt_plan` int DEFAULT NULL,
  `crt_sede` int DEFAULT '0',
  `estado_landing` varchar(8) DEFAULT NULL,
  `crt_carta_digital` int DEFAULT '0',
  `crt_auto_servicio` int DEFAULT '0',
  `crt_usuarios` int DEFAULT '0',
  PRIMARY KEY (`id_de`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_empresa`
--

INSERT INTO `tm_empresa` (`id_de`, `ruc`, `razon_social`, `nombre_comercial`, `direccion_comercial`, `direccion_fiscal`, `ubigeo`, `departamento`, `provincia`, `distrito`, `sunat`, `modo`, `usuariosol`, `clavesol`, `clavecertificado`, `client_id`, `client_secret`, `logo`, `celular`, `email`, `namesubdominio`, `urlapi`, `passentorno`, `optimiproceso`, `crt_plan`, `crt_sede`, `estado_landing`, `crt_carta_digital`, `crt_auto_servicio`, `crt_usuarios`) VALUES
(1, '20601714753', 'EMPRESA DE ALIMENTOS GERCU SOCIEDAD ANONIMA CERRADA - EMPRESA DE ALIMENTOS GERCU S.A.C.', 'GERCU', 'AV. GREGORIO ESCOBEDO NRO. 426 RES. SAN FELIPE DPTO. 606, LIMA - LIMA - JESUS MARIA', 'AV. GREGORIO ESCOBEDO NRO. 426 RES. SAN FELIPE DPTO. 606, LIMA - LIMA - JESUS MARIA', '15118', 'LIMA', 'LIMA', 'LIMA', 0, 3, '', '', '', '', '', 'default.png', '985000221', 'gercu@gmail.com', 'gercu', '', '', '3', 1, 1, '1', 1, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_gastos_adm`
--

DROP TABLE IF EXISTS `tm_gastos_adm`;
CREATE TABLE IF NOT EXISTS `tm_gastos_adm` (
  `id_ga` int NOT NULL AUTO_INCREMENT,
  `id_tipo_gasto` int NOT NULL,
  `id_usu` int NOT NULL,
  `id_apc` int NOT NULL,
  `id_per` int DEFAULT NULL,
  `importe` decimal(10,2) DEFAULT NULL,
  `responsable` varchar(100) DEFAULT NULL,
  `motivo` varchar(100) DEFAULT NULL,
  `fecha_registro` datetime DEFAULT NULL,
  `estado` varchar(5) DEFAULT 'a',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_ga`),
  KEY `FK_gasto_tg` (`id_tipo_gasto`),
  KEY `FK_EADM_APC` (`id_apc`),
  KEY `FK_EADM_USU` (`id_usu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_impresora`
--

DROP TABLE IF EXISTS `tm_impresora`;
CREATE TABLE IF NOT EXISTS `tm_impresora` (
  `id_imp` int NOT NULL AUTO_INCREMENT,
  `id_areap` int NOT NULL DEFAULT '0',
  `nombre` varchar(50) NOT NULL,
  `estado` varchar(5) NOT NULL DEFAULT 'a',
  `impr_caja` varchar(8) DEFAULT NULL,
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_imp`),
  KEY `fk_imp_arepro` (`id_areap`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tm_impresora`
--

INSERT INTO `tm_impresora` (`id_imp`, `id_areap`, `nombre`, `estado`, `impr_caja`, `idemp`, `idsede`) VALUES
(1, 1, 'COCINA', 'a', 'i', 1, 1),
(2, 2, 'BAR', 'a', 'i', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_ingresos_adm`
--

DROP TABLE IF EXISTS `tm_ingresos_adm`;
CREATE TABLE IF NOT EXISTS `tm_ingresos_adm` (
  `id_ing` int NOT NULL AUTO_INCREMENT,
  `id_usu` int NOT NULL,
  `id_apc` int NOT NULL,
  `importe` decimal(10,2) DEFAULT NULL,
  `responsable` varchar(100) DEFAULT NULL,
  `motivo` varchar(200) DEFAULT NULL,
  `fecha_reg` datetime DEFAULT NULL,
  `estado` varchar(5) DEFAULT 'a',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_ing`),
  KEY `FK_IADM_USU` (`id_usu`),
  KEY `FK_IADM_APC` (`id_apc`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_ingresos_adm`
--

INSERT INTO `tm_ingresos_adm` (`id_ing`, `id_usu`, `id_apc`, `importe`, `responsable`, `motivo`, `fecha_reg`, `estado`, `idemp`, `idsede`) VALUES
(1, 1, 1, 100.00, 'PAGO SAC', 'deuda de pedido', '2023-03-15 19:17:52', 'a', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_insumo`
--

DROP TABLE IF EXISTS `tm_insumo`;
CREATE TABLE IF NOT EXISTS `tm_insumo` (
  `id_ins` int NOT NULL AUTO_INCREMENT,
  `id_catg` int NOT NULL,
  `id_med` int NOT NULL,
  `cod_ins` varchar(10) DEFAULT NULL,
  `nomb_ins` varchar(45) DEFAULT NULL,
  `stock_min` int DEFAULT NULL,
  `cos_uni` decimal(10,2) DEFAULT NULL,
  `estado` varchar(5) DEFAULT 'a',
  `stockInsumo` int DEFAULT NULL,
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_ins`),
  KEY `FK_ins_catg` (`id_catg`),
  KEY `FK_ins_med` (`id_med`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_insumo_catg`
--

DROP TABLE IF EXISTS `tm_insumo_catg`;
CREATE TABLE IF NOT EXISTS `tm_insumo_catg` (
  `id_catg` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  `estado` varchar(5) DEFAULT 'a',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_catg`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_inventario`
--

DROP TABLE IF EXISTS `tm_inventario`;
CREATE TABLE IF NOT EXISTS `tm_inventario` (
  `id_inv` int NOT NULL AUTO_INCREMENT,
  `id_tipo_ope` int NOT NULL,
  `id_ope` int NOT NULL,
  `id_tipo_ins` int NOT NULL,
  `id_ins` int NOT NULL,
  `cos_uni` decimal(10,2) NOT NULL,
  `cant` float NOT NULL,
  `fecha_r` datetime NOT NULL,
  `estado` varchar(5) NOT NULL DEFAULT 'a',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_inv`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_inventario_entsal`
--

DROP TABLE IF EXISTS `tm_inventario_entsal`;
CREATE TABLE IF NOT EXISTS `tm_inventario_entsal` (
  `id_es` int NOT NULL AUTO_INCREMENT,
  `id_usu` int NOT NULL,
  `id_tipo` int NOT NULL,
  `id_responsable` int NOT NULL,
  `motivo` varchar(200) NOT NULL,
  `fecha` datetime NOT NULL,
  `estado` varchar(5) NOT NULL DEFAULT 'a',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  `responsable` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id_es`),
  KEY `FK_INVES_USU` (`id_usu`),
  KEY `FK_INVES_RESP` (`id_responsable`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_landing`
--

DROP TABLE IF EXISTS `tm_landing`;
CREATE TABLE IF NOT EXISTS `tm_landing` (
  `id_landing` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  `pedidominimo` decimal(10,2) DEFAULT NULL,
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_landing`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_landing`
--

INSERT INTO `tm_landing` (`id_landing`, `descripcion`, `estado`, `pedidominimo`, `idemp`, `idsede`) VALUES
(1, 'gercu', 'a', 15.00, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_margen_venta`
--

DROP TABLE IF EXISTS `tm_margen_venta`;
CREATE TABLE IF NOT EXISTS `tm_margen_venta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cod_dia` int NOT NULL,
  `dia` varchar(45) NOT NULL,
  `margen` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_margen_venta`
--

INSERT INTO `tm_margen_venta` (`id`, `cod_dia`, `dia`, `margen`) VALUES
(1, 1, 'Lunes', 150.00),
(2, 2, 'Martes', 750.00),
(3, 3, 'Miércoles', 750.00),
(4, 4, 'Jueves', 850.00),
(5, 5, 'Viernes', 1200.00),
(6, 6, 'Sábado', 1800.00),
(7, 0, 'Domingo', 2500.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_mesa`
--

DROP TABLE IF EXISTS `tm_mesa`;
CREATE TABLE IF NOT EXISTS `tm_mesa` (
  `id_mesa` int NOT NULL AUTO_INCREMENT,
  `id_salon` int NOT NULL,
  `nro_mesa` varchar(5) NOT NULL,
  `estado` varchar(45) NOT NULL DEFAULT 'a',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_mesa`),
  KEY `FKM_IDCATG_idx` (`id_salon`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_mesa`
--

INSERT INTO `tm_mesa` (`id_mesa`, `id_salon`, `nro_mesa`, `estado`, `idemp`, `idsede`) VALUES
(1, 1, 'M01', 'a', 1, 1),
(2, 1, 'M02', 'a', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_modulos`
--

DROP TABLE IF EXISTS `tm_modulos`;
CREATE TABLE IF NOT EXISTS `tm_modulos` (
  `id_modulo` int NOT NULL AUTO_INCREMENT,
  `id_plan` int NOT NULL,
  `descripcion` varchar(50) NOT NULL,
  `estado` varchar(5) NOT NULL,
  PRIMARY KEY (`id_modulo`),
  KEY `fk_modulo_plan` (`id_plan`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_modulos`
--

INSERT INTO `tm_modulos` (`id_modulo`, `id_plan`, `descripcion`, `estado`) VALUES
(1, 1, 'Informes', 'a'),
(2, 1, 'Landing', 'a'),
(3, 1, 'Inventario', 'a'),
(4, 1, 'Tablero', 'a'),
(5, 1, 'Caja', 'a'),
(6, 1, 'Compras', 'a'),
(7, 1, 'Clientes', 'a'),
(8, 1, 'Creditos', 'a'),
(9, 1, 'Ajustes', 'a'),
(10, 1, 'Punto de venta', 'a'),
(11, 2, 'Tablero', 'a'),
(12, 2, 'Punto de venta', 'a'),
(13, 2, 'Informes', 'a'),
(14, 2, 'Caja', 'a'),
(15, 2, 'Creditos', 'a'),
(16, 2, 'Landing', 'a'),
(17, 3, 'Punto de venta', 'a');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_pago`
--

DROP TABLE IF EXISTS `tm_pago`;
CREATE TABLE IF NOT EXISTS `tm_pago` (
  `id_pago` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) NOT NULL,
  `estado` varchar(10) DEFAULT 'a',
  PRIMARY KEY (`id_pago`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_pago`
--

INSERT INTO `tm_pago` (`id_pago`, `descripcion`, `estado`) VALUES
(1, 'EFECTIVO', 'a'),
(2, 'TARJETAS', 'a'),
(3, 'MIXTO', 'a'),
(4, 'EN LINEA', 'a'),
(5, 'TRANSFERENCIAS', 'a'),
(6, 'VALES', 'a');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_pedido`
--

DROP TABLE IF EXISTS `tm_pedido`;
CREATE TABLE IF NOT EXISTS `tm_pedido` (
  `id_pedido` int NOT NULL AUTO_INCREMENT,
  `id_tipo_pedido` int NOT NULL,
  `id_apc` int DEFAULT NULL,
  `id_usu` int NOT NULL,
  `fecha_pedido` datetime NOT NULL,
  `estado` varchar(5) NOT NULL DEFAULT 'a',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_pedido`),
  KEY `FK_ped_tp` (`id_tipo_pedido`),
  KEY `FK_ped_usu` (`id_usu`),
  KEY `FK_ped_apc` (`id_apc`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_pedido`
--

INSERT INTO `tm_pedido` (`id_pedido`, `id_tipo_pedido`, `id_apc`, `id_usu`, `fecha_pedido`, `estado`, `idemp`, `idsede`) VALUES
(1, 2, 1, 1, '2025-04-08 19:33:06', 'a', 1, 1),
(2, 1, NULL, 1, '2025-04-08 21:01:08', 'z', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_pedido_delivery`
--

DROP TABLE IF EXISTS `tm_pedido_delivery`;
CREATE TABLE IF NOT EXISTS `tm_pedido_delivery` (
  `id_pedido` int NOT NULL,
  `tipo_canal` int NOT NULL,
  `id_cliente` int NOT NULL,
  `id_repartidor` int DEFAULT '0',
  `tipo_pago` int NOT NULL,
  `tipo_entrega` int NOT NULL,
  `pedido_programado` int DEFAULT '0',
  `hora_entrega` time DEFAULT '00:00:00',
  `paga_con` decimal(10,2) NOT NULL DEFAULT '0.00',
  `comision_delivery` decimal(10,2) NOT NULL DEFAULT '0.00',
  `amortizacion` decimal(10,2) NOT NULL DEFAULT '0.00',
  `nro_pedido` varchar(10) NOT NULL,
  `nombre_cliente` varchar(100) NOT NULL,
  `telefono_cliente` varchar(20) NOT NULL,
  `direccion_cliente` varchar(100) NOT NULL,
  `referencia_cliente` varchar(100) NOT NULL,
  `email_cliente` varchar(200) NOT NULL,
  `fecha_preparacion` datetime NOT NULL DEFAULT '1000-01-01 00:00:00',
  `fecha_envio` datetime NOT NULL DEFAULT '1000-01-01 00:00:00',
  `fecha_entrega` datetime NOT NULL DEFAULT '1000-01-01 00:00:00',
  `comentarios` varchar(160) DEFAULT NULL,
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  KEY `FK_peddel_ped` (`id_pedido`),
  KEY `FK_peddel_cli` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_pedido_llevar`
--

DROP TABLE IF EXISTS `tm_pedido_llevar`;
CREATE TABLE IF NOT EXISTS `tm_pedido_llevar` (
  `id_pedido` int NOT NULL,
  `nro_pedido` varchar(10) NOT NULL,
  `nomb_cliente` varchar(100) NOT NULL,
  `fecha_entrega` datetime NOT NULL DEFAULT '1000-01-01 00:00:00',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  KEY `FK_pedlle_ped` (`id_pedido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_pedido_llevar`
--

INSERT INTO `tm_pedido_llevar` (`id_pedido`, `nro_pedido`, `nomb_cliente`, `fecha_entrega`, `idemp`, `idsede`) VALUES
(1, '00001', 'VENTA RAPIDA - ADMIN', '1000-01-01 00:00:00', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_pedido_mesa`
--

DROP TABLE IF EXISTS `tm_pedido_mesa`;
CREATE TABLE IF NOT EXISTS `tm_pedido_mesa` (
  `id_pedido` int NOT NULL,
  `id_mesa` int NOT NULL,
  `id_mozo` int NOT NULL,
  `nomb_cliente` varchar(45) NOT NULL,
  `nro_personas` int NOT NULL,
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  KEY `FK_pedme_ped` (`id_pedido`),
  KEY `FK_pedme_mesa` (`id_mesa`),
  KEY `FK_pedme_mozo` (`id_mozo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_pedido_mesa`
--

INSERT INTO `tm_pedido_mesa` (`id_pedido`, `id_mesa`, `id_mozo`, `nomb_cliente`, `nro_personas`, `idemp`, `idsede`) VALUES
(2, 1, 1, 'Mesa: M01', 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_plan`
--

DROP TABLE IF EXISTS `tm_plan`;
CREATE TABLE IF NOT EXISTS `tm_plan` (
  `id_plan` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) NOT NULL,
  `estado` varchar(5) NOT NULL,
  PRIMARY KEY (`id_plan`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_plan`
--

INSERT INTO `tm_plan` (`id_plan`, `descripcion`, `estado`) VALUES
(1, 'PLAN 1', 'a'),
(2, 'PLAN 2', 'a'),
(3, 'PLAN 3', 'a');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_producto`
--

DROP TABLE IF EXISTS `tm_producto`;
CREATE TABLE IF NOT EXISTS `tm_producto` (
  `id_prod` int NOT NULL AUTO_INCREMENT,
  `id_tipo` int NOT NULL,
  `id_catg` int NOT NULL DEFAULT '0',
  `id_areap` int NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `notas` varchar(200) DEFAULT NULL,
  `descripcion` varchar(200) DEFAULT NULL,
  `delivery` int DEFAULT '0',
  `estado` varchar(1) DEFAULT 'a',
  `cod_pro` varchar(45) DEFAULT NULL,
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_prod`),
  KEY `FK_prod_catg` (`id_catg`),
  KEY `FK_prod_area` (`id_areap`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_producto_catg`
--

DROP TABLE IF EXISTS `tm_producto_catg`;
CREATE TABLE IF NOT EXISTS `tm_producto_catg` (
  `id_catg` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  `delivery` int NOT NULL DEFAULT '0',
  `orden` int NOT NULL DEFAULT '100',
  `imagen` varchar(200) NOT NULL DEFAULT 'default.png',
  `estado` varchar(1) NOT NULL DEFAULT 'a',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_catg`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_producto_catg`
--

INSERT INTO `tm_producto_catg` (`id_catg`, `descripcion`, `delivery`, `orden`, `imagen`, `estado`, `idemp`, `idsede`) VALUES
(1, 'COMBOS', 0, 0, 'default.png', 'a', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_producto_ingr`
--

DROP TABLE IF EXISTS `tm_producto_ingr`;
CREATE TABLE IF NOT EXISTS `tm_producto_ingr` (
  `id_pi` int NOT NULL AUTO_INCREMENT,
  `id_pres` int NOT NULL,
  `id_tipo_ins` int NOT NULL,
  `id_ins` int NOT NULL,
  `id_med` int NOT NULL,
  `cant` float(10,6) NOT NULL,
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  `costo` float DEFAULT '0',
  `id_areap` int DEFAULT '0',
  PRIMARY KEY (`id_pi`),
  KEY `FK_PING_PRES` (`id_pres`),
  KEY `FK_PING_INS` (`id_ins`),
  KEY `FK_PING_MED` (`id_med`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_producto_pres`
--

DROP TABLE IF EXISTS `tm_producto_pres`;
CREATE TABLE IF NOT EXISTS `tm_producto_pres` (
  `id_pres` int NOT NULL AUTO_INCREMENT,
  `id_prod` int NOT NULL,
  `cod_prod` varchar(45) NOT NULL,
  `presentacion` varchar(45) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `precio_delivery` decimal(10,2) NOT NULL DEFAULT '0.00',
  `receta` int NOT NULL,
  `stock_min` int NOT NULL,
  `crt_stock` int NOT NULL DEFAULT '0',
  `impuesto` int NOT NULL,
  `delivery` int NOT NULL DEFAULT '0',
  `margen` int NOT NULL DEFAULT '0',
  `igv` decimal(10,2) NOT NULL,
  `imagen` varchar(200) NOT NULL DEFAULT 'default.png',
  `estado` varchar(1) NOT NULL DEFAULT 'a',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  `crt_icbper` int DEFAULT '0',
  PRIMARY KEY (`id_pres`),
  KEY `FK_PROP_PROD` (`id_prod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_produc_topicos`
--

DROP TABLE IF EXISTS `tm_produc_topicos`;
CREATE TABLE IF NOT EXISTS `tm_produc_topicos` (
  `id_producto` int DEFAULT NULL,
  `id_topicos` int DEFAULT NULL,
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  KEY `id_producto` (`id_producto`),
  KEY `id_topicos` (`id_topicos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_proveedor`
--

DROP TABLE IF EXISTS `tm_proveedor`;
CREATE TABLE IF NOT EXISTS `tm_proveedor` (
  `id_prov` int NOT NULL AUTO_INCREMENT,
  `ruc` varchar(13) NOT NULL,
  `razon_social` varchar(100) NOT NULL,
  `direccion` varchar(300) DEFAULT NULL,
  `telefono` int DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `contacto` varchar(45) DEFAULT NULL,
  `estado` varchar(1) DEFAULT 'a',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_prov`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_repartidor`
--

DROP TABLE IF EXISTS `tm_repartidor`;
CREATE TABLE IF NOT EXISTS `tm_repartidor` (
  `id_repartidor` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(100) NOT NULL,
  `estado` varchar(5) NOT NULL DEFAULT 'a',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_repartidor`)
) ENGINE=InnoDB AUTO_INCREMENT=4445 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_repartidor`
--

INSERT INTO `tm_repartidor` (`id_repartidor`, `descripcion`, `estado`, `idemp`, `idsede`) VALUES
(1, 'INTERNO', 'a', NULL, NULL),
(2222, 'RAPPI', 'a', NULL, NULL),
(3333, 'UBER', 'a', NULL, NULL),
(4444, 'GLOVO', 'a', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_rol`
--

DROP TABLE IF EXISTS `tm_rol`;
CREATE TABLE IF NOT EXISTS `tm_rol` (
  `id_rol` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_rol`
--

INSERT INTO `tm_rol` (`id_rol`, `descripcion`) VALUES
(1, 'ADMINISTRATOR'),
(2, 'ADMINISTRADOR'),
(3, 'CAJERO'),
(4, 'PRODUCCION'),
(5, 'MOZO'),
(6, 'REPARTIDOR');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_salon`
--

DROP TABLE IF EXISTS `tm_salon`;
CREATE TABLE IF NOT EXISTS `tm_salon` (
  `id_salon` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  `estado` varchar(5) NOT NULL DEFAULT 'a',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_salon`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_salon`
--

INSERT INTO `tm_salon` (`id_salon`, `descripcion`, `estado`, `idemp`, `idsede`) VALUES
(1, 'SALON 1', 'a', 1, 1),
(2, 'SALON 2', 'a', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_sedes`
--

DROP TABLE IF EXISTS `tm_sedes`;
CREATE TABLE IF NOT EXISTS `tm_sedes` (
  `id_sede` int NOT NULL AUTO_INCREMENT,
  `id_empresa` int DEFAULT NULL,
  `nombre` varchar(150) DEFAULT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `departamento` varchar(50) DEFAULT NULL,
  `provincia` varchar(50) DEFAULT NULL,
  `distrito` varchar(50) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id_sede`),
  KEY `fk_sedes_empres` (`id_empresa`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_sedes`
--

INSERT INTO `tm_sedes` (`id_sede`, `id_empresa`, `nombre`, `direccion`, `departamento`, `provincia`, `distrito`, `estado`, `telefono`) VALUES
(1, 1, 'principal GERCU', 'CAL. MICAELA BASTIDAS NRO. 636 URB. SANTA VERONICA BA. 4, LA LIBERTAD - TRUJILLO - LA ESPERANZA', 'LIMA', 'LIMA', 'PUENTE PIEDRA', 'a', ''),
(2, 1, 'sucursal GERCU', 'AV. GREGORIO ESCOBEDO NRO. 426 RES. SAN FELIPE DPTO. 606, LIMA - LIMA - JESUS MARIA', 'LIMA', 'LIMA', 'LIMA', 'a', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_sede_usuario`
--

DROP TABLE IF EXISTS `tm_sede_usuario`;
CREATE TABLE IF NOT EXISTS `tm_sede_usuario` (
  `id_sede` int DEFAULT NULL,
  `id_usu` int DEFAULT NULL,
  KEY `fk_sedes_sede` (`id_sede`),
  KEY `fk_sedes_usu` (`id_usu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_sede_usuario`
--

INSERT INTO `tm_sede_usuario` (`id_sede`, `id_usu`) VALUES
(1, 1),
(2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_series`
--

DROP TABLE IF EXISTS `tm_series`;
CREATE TABLE IF NOT EXISTS `tm_series` (
  `idserie` int NOT NULL AUTO_INCREMENT,
  `id_tipo_doc` int DEFAULT NULL,
  `serie` varchar(25) DEFAULT NULL,
  `numero` varchar(8) DEFAULT NULL,
  `estado` varchar(5) DEFAULT NULL,
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`idserie`),
  KEY `fk_tipodoc_serie` (`id_tipo_doc`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_series`
--

INSERT INTO `tm_series` (`idserie`, `id_tipo_doc`, `serie`, `numero`, `estado`, `idemp`, `idsede`) VALUES
(1, 1, 'B001', '00000001', 'a', 1, 1),
(2, 2, 'F001', '00000001', 'a', 1, 1),
(3, 3, 'NV01', '00000001', 'a', 1, 1),
(4, 4, 'NC01', '00000001', 'a', 1, 1),
(5, 5, 'ND01', '00000001', 'a', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_tipo_compra`
--

DROP TABLE IF EXISTS `tm_tipo_compra`;
CREATE TABLE IF NOT EXISTS `tm_tipo_compra` (
  `id_tipo_compra` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id_tipo_compra`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_tipo_compra`
--

INSERT INTO `tm_tipo_compra` (`id_tipo_compra`, `descripcion`) VALUES
(1, 'CONTADO'),
(2, 'CREDITO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_tipo_doc`
--

DROP TABLE IF EXISTS `tm_tipo_doc`;
CREATE TABLE IF NOT EXISTS `tm_tipo_doc` (
  `id_tipo_doc` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  `estado` varchar(5) NOT NULL DEFAULT 'a',
  PRIMARY KEY (`id_tipo_doc`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_tipo_doc`
--

INSERT INTO `tm_tipo_doc` (`id_tipo_doc`, `descripcion`, `estado`) VALUES
(1, 'BOLETA DE VENTA', 'a'),
(2, 'FACTURA', 'a'),
(3, 'NOTA DE VENTA', 'a'),
(4, 'NOTA DE CREDITO', 'a'),
(5, 'NOTA DE DEBITO', 'a');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_tipo_gasto`
--

DROP TABLE IF EXISTS `tm_tipo_gasto`;
CREATE TABLE IF NOT EXISTS `tm_tipo_gasto` (
  `id_tipo_gasto` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id_tipo_gasto`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_tipo_gasto`
--

INSERT INTO `tm_tipo_gasto` (`id_tipo_gasto`, `descripcion`) VALUES
(1, 'POR COMPRAS'),
(2, 'POR SERVICIOS'),
(3, 'POR REMUNERACION'),
(4, 'POR CREDITO DE COMPRAS');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_tipo_medida`
--

DROP TABLE IF EXISTS `tm_tipo_medida`;
CREATE TABLE IF NOT EXISTS `tm_tipo_medida` (
  `id_med` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  `grupo` int NOT NULL,
  PRIMARY KEY (`id_med`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_tipo_medida`
--

INSERT INTO `tm_tipo_medida` (`id_med`, `descripcion`, `grupo`) VALUES
(1, 'UNIDAD', 1),
(2, 'KILOS', 2),
(3, 'GRAMOS', 2),
(4, 'MILIGRAMOS', 2),
(5, 'LITRO', 3),
(6, 'MILILITRO', 3),
(7, 'LIBRAS', 2),
(8, 'ONZAS', 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_tipo_pago`
--

DROP TABLE IF EXISTS `tm_tipo_pago`;
CREATE TABLE IF NOT EXISTS `tm_tipo_pago` (
  `id_tipo_pago` int NOT NULL AUTO_INCREMENT,
  `id_pago` int NOT NULL,
  `descripcion` varchar(45) NOT NULL,
  `estado` varchar(5) NOT NULL DEFAULT 'a',
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_tipo_pago`),
  KEY `FK_TIPODEPAGO` (`id_pago`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_tipo_pago`
--

INSERT INTO `tm_tipo_pago` (`id_tipo_pago`, `id_pago`, `descripcion`, `estado`, `idemp`, `idsede`) VALUES
(1, 1, 'EFECTIVO', 'a', 1, 1),
(2, 2, 'TARJETA', 'a', 1, 1),
(3, 3, 'PAGO MIXTO', 'a', 1, 1),
(4, 4, 'YAPE', 'a', 1, 1),
(5, 4, 'PLIN', 'a', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_tipo_pedido`
--

DROP TABLE IF EXISTS `tm_tipo_pedido`;
CREATE TABLE IF NOT EXISTS `tm_tipo_pedido` (
  `id_tipo_pedido` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id_tipo_pedido`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_tipo_pedido`
--

INSERT INTO `tm_tipo_pedido` (`id_tipo_pedido`, `descripcion`) VALUES
(1, 'MESA'),
(2, 'PARA LLEVAR'),
(3, 'DELIVERY'),
(4, 'WEB');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_tipo_venta`
--

DROP TABLE IF EXISTS `tm_tipo_venta`;
CREATE TABLE IF NOT EXISTS `tm_tipo_venta` (
  `id_tipo_venta` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id_tipo_venta`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_tipo_venta`
--

INSERT INTO `tm_tipo_venta` (`id_tipo_venta`, `descripcion`) VALUES
(1, 'CONTADO'),
(2, 'CREDITO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_topicos`
--

DROP TABLE IF EXISTS `tm_topicos`;
CREATE TABLE IF NOT EXISTS `tm_topicos` (
  `id_topicos` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `estado` varchar(5) DEFAULT NULL,
  `idemp` int DEFAULT NULL,
  `idsede` int DEFAULT NULL,
  PRIMARY KEY (`id_topicos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_turno`
--

DROP TABLE IF EXISTS `tm_turno`;
CREATE TABLE IF NOT EXISTS `tm_turno` (
  `id_turno` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id_turno`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_turno`
--

INSERT INTO `tm_turno` (`id_turno`, `descripcion`) VALUES
(1, 'PRIMER TURNO'),
(2, 'SEGUNDO TURNO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_usuario`
--

DROP TABLE IF EXISTS `tm_usuario`;
CREATE TABLE IF NOT EXISTS `tm_usuario` (
  `id_usu` int NOT NULL AUTO_INCREMENT,
  `id_rol` int NOT NULL,
  `id_areap` int NOT NULL,
  `dni` varchar(10) NOT NULL,
  `ape_paterno` varchar(45) DEFAULT NULL,
  `ape_materno` varchar(45) DEFAULT NULL,
  `nombres` varchar(45) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `usuario` varchar(45) DEFAULT NULL,
  `contrasena` varchar(45) DEFAULT 'cmVzdHBl',
  `estado` varchar(5) DEFAULT 'a',
  `imagen` varchar(45) DEFAULT NULL,
  `idEmpresa` int DEFAULT NULL,
  PRIMARY KEY (`id_usu`),
  KEY `FKU_IDROL_idx` (`id_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `tm_usuario`
--

INSERT INTO `tm_usuario` (`id_usu`, `id_rol`, `id_areap`, `dni`, `ape_paterno`, `ape_materno`, `nombres`, `email`, `usuario`, `contrasena`, `estado`, `imagen`, `idEmpresa`) VALUES
(1, 2, 1, '44827499', 'ADMINISTRADOR', 'ADMINISTRADOR', 'SUPER ADMINISTRADOR', 'administrador@gmail.com', 'administrador', 'c29wb3J0ZTI=', 'a', '161117020710-avatar5.png', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_venta`
--

DROP TABLE IF EXISTS `tm_venta`;
CREATE TABLE IF NOT EXISTS `tm_venta` (
  `id_venta` int NOT NULL AUTO_INCREMENT,
  `id_pedido` int NOT NULL,
  `id_tipo_pedido` int NOT NULL,
  `id_cliente` int NOT NULL,
  `id_tipo_doc` int NOT NULL,
  `id_pago` int DEFAULT NULL,
  `id_usu` int NOT NULL,
  `id_apc` int NOT NULL,
  `serie_doc` char(5) DEFAULT NULL,
  `nro_doc` varchar(8) DEFAULT NULL,
  `pago_efe_none` decimal(10,2) DEFAULT '0.00',
  `descuento_tipo` char(1) NOT NULL DEFAULT '1',
  `descuento_personal` int DEFAULT NULL,
  `descuento_monto` decimal(10,2) DEFAULT '0.00',
  `descuento_motivo` varchar(200) DEFAULT NULL,
  `comision_tarjeta` decimal(10,2) DEFAULT '0.00',
  `comision_delivery` decimal(10,2) DEFAULT '0.00',
  `igv` decimal(10,2) DEFAULT '0.00',
  `total` decimal(10,2) DEFAULT '0.00',
  `codigo_operacion` varchar(20) DEFAULT NULL,
  `fecha_venta` datetime DEFAULT NULL,
  `idemp` int NOT NULL,
  `idsede` int NOT NULL,
  `crt_fac_cons` int DEFAULT '0',
  `estado` varchar(15) DEFAULT 'a',
  `enviado_sunat` char(1) DEFAULT NULL,
  `code_respuesta_sunat` varchar(5) NOT NULL DEFAULT '0',
  `descripcion_sunat_cdr` varchar(300) NOT NULL DEFAULT '0',
  `name_file_sunat` varchar(80) NOT NULL DEFAULT '0',
  `hash_cdr` varchar(200) NOT NULL DEFAULT '0',
  `hash_cpe` varchar(200) NOT NULL DEFAULT '0',
  `fecha_vencimiento` date NOT NULL DEFAULT '1000-01-01',
  `external_id` varchar(60) DEFAULT NULL,
  `msg_fact` varchar(350) DEFAULT NULL,
  PRIMARY KEY (`id_venta`),
  KEY `FK_venta_cli` (`id_cliente`),
  KEY `FK_venta_td` (`id_tipo_doc`),
  KEY `FK_venta_tp` (`id_pago`),
  KEY `FK_venta_usu` (`id_usu`),
  KEY `FK_venta_apc` (`id_apc`),
  KEY `FK_venta_tpe` (`id_tipo_pedido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_venta_pago`
--

DROP TABLE IF EXISTS `tm_venta_pago`;
CREATE TABLE IF NOT EXISTS `tm_venta_pago` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_venta` int NOT NULL,
  `id_tipo_pago` int NOT NULL,
  `cant_pago` decimal(10,2) NOT NULL,
  `estado` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_compras`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `v_compras`;
CREATE TABLE IF NOT EXISTS `v_compras` (
`id_compra` int
,`id_prov` int
,`id_tipo_compra` int
,`id_tipo_doc` int
,`fecha_c` date
,`fecha_r` datetime
,`hora_c` varchar(45)
,`serie_doc` varchar(45)
,`num_doc` varchar(45)
,`igv` decimal(10,2)
,`total` decimal(10,2)
,`estado` varchar(1)
,`idemp` int
,`idsede` int
,`desc_tc` varchar(45)
,`desc_td` varchar(45)
,`desc_prov` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_det_delivery`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `v_det_delivery`;
CREATE TABLE IF NOT EXISTS `v_det_delivery` (
`id_pedido` int
,`id_pres` int
,`detatopico` varchar(60)
,`comentario` varchar(100)
,`cantidad` bigint
,`precio` decimal(10,2)
,`estado` varchar(5)
,`preciotopico` decimal(10,2)
,`nombre_prod` varchar(45)
,`pres_prod` varchar(45)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_insprod`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `v_insprod`;
CREATE TABLE IF NOT EXISTS `v_insprod` (
`id_tipo_ins` bigint
,`id_ins` int
,`id_med` varchar(11)
,`id_gru` varchar(11)
,`ins_cod` varchar(45)
,`ins_nom` varchar(91)
,`ins_cat` varchar(45)
,`ins_med` varchar(45)
,`ins_rec` bigint
,`ins_cos` decimal(10,2)
,`ins_sto` int
,`est_a` varchar(5)
,`est_b` varchar(1)
,`est_c` varchar(1)
,`crt_stock` varchar(11)
,`idemp` int
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_insumos`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `v_insumos`;
CREATE TABLE IF NOT EXISTS `v_insumos` (
`id_ins` int
,`id_catg` int
,`id_med` int
,`id_gru` int
,`ins_cod` varchar(10)
,`ins_nom` varchar(45)
,`ins_sto` int
,`ins_cos` decimal(10,2)
,`ins_est` varchar(5)
,`idemp` int
,`idsede` int
,`ins_cat` varchar(45)
,`ins_med` varchar(45)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_listapedido_cliente`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `v_listapedido_cliente`;
CREATE TABLE IF NOT EXISTS `v_listapedido_cliente` (
`id_pedido` int
,`fecha_pedido` datetime
,`id_cliente` int
,`nro_pedido` varchar(10)
,`idemp` int
,`idsede` int
,`tipopago` varchar(45)
,`estadopedido` varchar(22)
,`precioTotal` decimal(43,2)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_listar_mesas`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `v_listar_mesas`;
CREATE TABLE IF NOT EXISTS `v_listar_mesas` (
`id_mesa` int
,`id_salon` int
,`nro_mesa` varchar(5)
,`estado` varchar(45)
,`desc_salon` varchar(45)
,`idemp` int
,`idsede` int
,`id_pedido` int
,`fecha_pedido` datetime
,`nro_personas` int
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_mesas`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `v_mesas`;
CREATE TABLE IF NOT EXISTS `v_mesas` (
`id_mesa` int
,`id_salon` int
,`nro_mesa` varchar(5)
,`estado` varchar(45)
,`idemp` int
,`idsede` int
,`desc_salon` varchar(45)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_pedido_mesa`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `v_pedido_mesa`;
CREATE TABLE IF NOT EXISTS `v_pedido_mesa` (
`id_pedido` int
,`id_tipo_pedido` int
,`id_usu` int
,`id_mesa` int
,`fecha_pedido` datetime
,`estado_pedido` varchar(5)
,`idemp` int
,`idsede` int
,`nombre_cliente` varchar(45)
,`nro_personas` int
,`nro_mesa` varchar(5)
,`desc_salon` varchar(45)
,`estado_mesa` varchar(45)
,`nombre_mozo` varchar(91)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_productos`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `v_productos`;
CREATE TABLE IF NOT EXISTS `v_productos` (
`id_pres` int
,`id_prod` int
,`id_tipo` int
,`id_catg` int
,`id_areap` int
,`pro_cat` varchar(45)
,`pro_cod` varchar(45)
,`pro_nom` varchar(45)
,`notas` varchar(200)
,`pro_pre` varchar(45)
,`pro_des` varchar(200)
,`pro_cos` decimal(10,2)
,`pro_cos_del` decimal(10,2)
,`pro_rec` int
,`pro_sto` int
,`pro_imp` int
,`pro_mar` int
,`pro_igv` decimal(10,2)
,`pro_img` varchar(200)
,`del_a` int
,`del_b` int
,`del_c` int
,`est_a` varchar(1)
,`est_b` varchar(1)
,`est_c` varchar(1)
,`crt_stock` int
,`idemp` int
,`idsede` int
,`crt_icbper` int
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_repartidores`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `v_repartidores`;
CREATE TABLE IF NOT EXISTS `v_repartidores` (
`id_repartidor` int
,`desc_repartidor` varchar(137)
);

-- --------------------------------------------------------

--
-- Estructura para la vista `v_compras`
--
DROP TABLE IF EXISTS `v_compras`;

DROP VIEW IF EXISTS `v_compras`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_compras`  AS SELECT `c`.`id_compra` AS `id_compra`, `c`.`id_prov` AS `id_prov`, `c`.`id_tipo_compra` AS `id_tipo_compra`, `c`.`id_tipo_doc` AS `id_tipo_doc`, `c`.`fecha_c` AS `fecha_c`, `c`.`fecha_reg` AS `fecha_r`, `c`.`hora_c` AS `hora_c`, `c`.`serie_doc` AS `serie_doc`, `c`.`num_doc` AS `num_doc`, `c`.`igv` AS `igv`, `c`.`total` AS `total`, `c`.`estado` AS `estado`, `c`.`idemp` AS `idemp`, `c`.`idsede` AS `idsede`, `tc`.`descripcion` AS `desc_tc`, `td`.`descripcion` AS `desc_td`, `tp`.`razon_social` AS `desc_prov` FROM (((`tm_compra` `c` join `tm_tipo_compra` `tc` on((`c`.`id_tipo_compra` = `tc`.`id_tipo_compra`))) join `tm_tipo_doc` `td` on((`c`.`id_tipo_doc` = `td`.`id_tipo_doc`))) join `tm_proveedor` `tp` on((`c`.`id_prov` = `tp`.`id_prov`))) WHERE (`c`.`id_compra` <> 0) ORDER BY `c`.`id_compra` DESC ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_det_delivery`
--
DROP TABLE IF EXISTS `v_det_delivery`;

DROP VIEW IF EXISTS `v_det_delivery`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_det_delivery`  AS SELECT `dp`.`id_pedido` AS `id_pedido`, `dp`.`id_pres` AS `id_pres`, `dp`.`detatopico` AS `detatopico`, `dp`.`comentario` AS `comentario`, if((`dp`.`cantidad` < `dp`.`cant`),`dp`.`cant`,`dp`.`cantidad`) AS `cantidad`, `dp`.`precio` AS `precio`, `dp`.`estado` AS `estado`, `dp`.`precioTopico` AS `preciotopico`, `vp`.`pro_nom` AS `nombre_prod`, `vp`.`pro_pre` AS `pres_prod` FROM (((`tm_detalle_pedido` `dp` join `tm_pedido_delivery` `pd` on((`dp`.`id_pedido` = `pd`.`id_pedido`))) join `tm_pedido` `tp` on((`dp`.`id_pedido` = `tp`.`id_pedido`))) join `v_productos` `vp` on((`dp`.`id_pres` = `vp`.`id_pres`))) WHERE (`dp`.`estado` <> 'z') ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_insprod`
--
DROP TABLE IF EXISTS `v_insprod`;

DROP VIEW IF EXISTS `v_insprod`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_insprod`  AS SELECT 1 AS `id_tipo_ins`, `i`.`id_ins` AS `id_ins`, `i`.`id_med` AS `id_med`, `i`.`id_gru` AS `id_gru`, `i`.`ins_cod` AS `ins_cod`, `i`.`ins_nom` AS `ins_nom`, `i`.`ins_cat` AS `ins_cat`, `i`.`ins_med` AS `ins_med`, 1 AS `ins_rec`, `i`.`ins_cos` AS `ins_cos`, `i`.`ins_sto` AS `ins_sto`, `i`.`ins_est` AS `est_a`, 'a' AS `est_b`, 'a' AS `est_c`, '' AS `crt_stock`, `i`.`idemp` AS `idemp` FROM `v_insumos` AS `i`union select 2 AS `id_tipo_ins`,`p`.`id_pres` AS `id_pres`,'1' AS `1`,'1' AS `1`,`p`.`pro_cod` AS `pro_cod`,concat(`p`.`pro_nom`,' ',`p`.`pro_pre`) AS `pro_nom`,`p`.`pro_cat` AS `pro_cat`,'UNIDAD' AS `UNIDAD`,`p`.`pro_rec` AS `pro_rec`,`p`.`pro_cos` AS `pro_cos`,`p`.`pro_sto` AS `pro_sto`,`p`.`est_a` AS `est_a`,`p`.`est_b` AS `est_b`,`p`.`est_c` AS `est_c`,`p`.`crt_stock` AS `crt_stock`,`p`.`idemp` AS `idemp` from `v_productos` `p` where ((`p`.`id_tipo` = 2) and (`p`.`id_catg` <> 1)) union select 3 AS `id_tipo_ins`,`p`.`id_pres` AS `id_pres`,'1' AS `1`,'1' AS `1`,`p`.`pro_cod` AS `pro_cod`,concat(`p`.`pro_nom`,' ',`p`.`pro_pre`) AS `pro_nom`,`p`.`pro_cat` AS `pro_cat`,'UNIDAD' AS `UNIDAD`,`p`.`pro_rec` AS `pro_rec`,`p`.`pro_cos` AS `pro_cos`,`p`.`pro_sto` AS `pro_sto`,`p`.`est_a` AS `est_a`,`p`.`est_b` AS `est_b`,`p`.`est_c` AS `est_c`,`p`.`crt_stock` AS `crt_stock`,`p`.`idemp` AS `idemp` from `v_productos` `p` where ((`p`.`id_tipo` = 1) and (`p`.`id_catg` <> 1))  ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_insumos`
--
DROP TABLE IF EXISTS `v_insumos`;

DROP VIEW IF EXISTS `v_insumos`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_insumos`  AS SELECT `i`.`id_ins` AS `id_ins`, `i`.`id_catg` AS `id_catg`, `i`.`id_med` AS `id_med`, `m`.`grupo` AS `id_gru`, `i`.`cod_ins` AS `ins_cod`, `i`.`nomb_ins` AS `ins_nom`, `i`.`stock_min` AS `ins_sto`, `i`.`cos_uni` AS `ins_cos`, `i`.`estado` AS `ins_est`, `i`.`idemp` AS `idemp`, `i`.`idsede` AS `idsede`, `ic`.`descripcion` AS `ins_cat`, `m`.`descripcion` AS `ins_med` FROM ((`tm_insumo` `i` join `tm_insumo_catg` `ic` on((`i`.`id_catg` = `ic`.`id_catg`))) join `tm_tipo_medida` `m` on((`i`.`id_med` = `m`.`id_med`))) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_listapedido_cliente`
--
DROP TABLE IF EXISTS `v_listapedido_cliente`;

DROP VIEW IF EXISTS `v_listapedido_cliente`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_listapedido_cliente`  AS SELECT `tp`.`id_pedido` AS `id_pedido`, `tp`.`fecha_pedido` AS `fecha_pedido`, `tpd`.`id_cliente` AS `id_cliente`, `tpd`.`nro_pedido` AS `nro_pedido`, `tpd`.`idemp` AS `idemp`, `tpd`.`idsede` AS `idsede`, `ttp`.`descripcion` AS `tipopago`, (case when (`tp`.`estado` = 'a') then 'Esperando confirmación' when (`tp`.`estado` = 'b') then 'Pedido en preparación' when (`tp`.`estado` = 'c') then 'Pedido en camino' when (`tp`.`estado` = 'd') then 'Pedido entregado' end) AS `estadopedido`, ifnull((sum((`vdetd`.`precio` * `vdetd`.`cantidad`)) + sum(`vdetd`.`precioTopico`)),0) AS `precioTotal` FROM (((`tm_pedido` `tp` join `tm_pedido_delivery` `tpd` on((`tp`.`id_pedido` = `tpd`.`id_pedido`))) join `tm_tipo_pago` `ttp` on((`tpd`.`tipo_pago` = `ttp`.`id_tipo_pago`))) join `tm_detalle_pedido` `vdetd` on((`tp`.`id_pedido` = `vdetd`.`id_pedido`))) WHERE ((`tp`.`id_tipo_pedido` = 3) AND (`tpd`.`tipo_canal` = 2)) GROUP BY `tp`.`id_pedido` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_listar_mesas`
--
DROP TABLE IF EXISTS `v_listar_mesas`;

DROP VIEW IF EXISTS `v_listar_mesas`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_listar_mesas`  AS SELECT `vm`.`id_mesa` AS `id_mesa`, `vm`.`id_salon` AS `id_salon`, `vm`.`nro_mesa` AS `nro_mesa`, `vm`.`estado` AS `estado`, `vm`.`desc_salon` AS `desc_salon`, `vm`.`idemp` AS `idemp`, `vm`.`idsede` AS `idsede`, `vo`.`id_pedido` AS `id_pedido`, `vo`.`fecha_pedido` AS `fecha_pedido`, `vo`.`nro_personas` AS `nro_personas` FROM (`v_mesas` `vm` left join `v_pedido_mesa` `vo` on((`vm`.`id_mesa` = `vo`.`id_mesa`))) ORDER BY `vm`.`nro_mesa` ASC ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_mesas`
--
DROP TABLE IF EXISTS `v_mesas`;

DROP VIEW IF EXISTS `v_mesas`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_mesas`  AS SELECT `m`.`id_mesa` AS `id_mesa`, `m`.`id_salon` AS `id_salon`, `m`.`nro_mesa` AS `nro_mesa`, `m`.`estado` AS `estado`, `m`.`idemp` AS `idemp`, `m`.`idsede` AS `idsede`, `cm`.`descripcion` AS `desc_salon` FROM (`tm_mesa` `m` join `tm_salon` `cm` on((`m`.`id_salon` = `cm`.`id_salon`))) WHERE ((`m`.`id_mesa` <> 0) AND (`cm`.`estado` <> 'i')) ORDER BY `m`.`id_mesa` ASC ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_pedido_mesa`
--
DROP TABLE IF EXISTS `v_pedido_mesa`;

DROP VIEW IF EXISTS `v_pedido_mesa`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_pedido_mesa`  AS SELECT `p`.`id_pedido` AS `id_pedido`, `p`.`id_tipo_pedido` AS `id_tipo_pedido`, `p`.`id_usu` AS `id_usu`, `pm`.`id_mesa` AS `id_mesa`, `p`.`fecha_pedido` AS `fecha_pedido`, `p`.`estado` AS `estado_pedido`, `p`.`idemp` AS `idemp`, `p`.`idsede` AS `idsede`, `pm`.`nomb_cliente` AS `nombre_cliente`, `pm`.`nro_personas` AS `nro_personas`, `vm`.`nro_mesa` AS `nro_mesa`, `vm`.`desc_salon` AS `desc_salon`, `vm`.`estado` AS `estado_mesa`, concat(`u`.`nombres`,' ',`u`.`ape_paterno`) AS `nombre_mozo` FROM (((`tm_pedido` `p` join `tm_pedido_mesa` `pm` on((`p`.`id_pedido` = `pm`.`id_pedido`))) join `v_mesas` `vm` on((`pm`.`id_mesa` = `vm`.`id_mesa`))) join `tm_usuario` `u` on((`pm`.`id_mozo` = `u`.`id_usu`))) WHERE ((`p`.`id_pedido` <> 0) AND (`p`.`estado` = 'a')) ORDER BY `p`.`id_pedido` DESC ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_productos`
--
DROP TABLE IF EXISTS `v_productos`;

DROP VIEW IF EXISTS `v_productos`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_productos`  AS SELECT `pp`.`id_pres` AS `id_pres`, `pp`.`id_prod` AS `id_prod`, `p`.`id_tipo` AS `id_tipo`, `p`.`id_catg` AS `id_catg`, `p`.`id_areap` AS `id_areap`, `cp`.`descripcion` AS `pro_cat`, `pp`.`cod_prod` AS `pro_cod`, `p`.`nombre` AS `pro_nom`, `p`.`notas` AS `notas`, `pp`.`presentacion` AS `pro_pre`, ifnull(`pp`.`descripcion`,'') AS `pro_des`, `pp`.`precio` AS `pro_cos`, `pp`.`precio_delivery` AS `pro_cos_del`, `pp`.`receta` AS `pro_rec`, `pp`.`stock_min` AS `pro_sto`, `pp`.`impuesto` AS `pro_imp`, `pp`.`margen` AS `pro_mar`, `pp`.`igv` AS `pro_igv`, `pp`.`imagen` AS `pro_img`, `cp`.`delivery` AS `del_a`, `p`.`delivery` AS `del_b`, `pp`.`delivery` AS `del_c`, `cp`.`estado` AS `est_a`, `p`.`estado` AS `est_b`, `pp`.`estado` AS `est_c`, `pp`.`crt_stock` AS `crt_stock`, `pp`.`idemp` AS `idemp`, `pp`.`idsede` AS `idsede`, `pp`.`crt_icbper` AS `crt_icbper` FROM ((`tm_producto_pres` `pp` join `tm_producto` `p` on((`pp`.`id_prod` = `p`.`id_prod`))) join `tm_producto_catg` `cp` on((`p`.`id_catg` = `cp`.`id_catg`))) WHERE (`pp`.`id_pres` <> 0) ORDER BY `pp`.`id_pres` DESC ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_repartidores`
--
DROP TABLE IF EXISTS `v_repartidores`;

DROP VIEW IF EXISTS `v_repartidores`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_repartidores`  AS SELECT `tm_usuario`.`id_usu` AS `id_repartidor`, concat(`tm_usuario`.`nombres`,' ',`tm_usuario`.`ape_paterno`,' ',`tm_usuario`.`ape_materno`) AS `desc_repartidor` FROM `tm_usuario` WHERE (`tm_usuario`.`id_rol` = 6)union select `tm_repartidor`.`id_repartidor` AS `id_repartidor`,`tm_repartidor`.`descripcion` AS `desc_repartidor` from `tm_repartidor`  ;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `horarioatencion`
--
ALTER TABLE `horarioatencion`
  ADD CONSTRAINT `fk_landing_horaten` FOREIGN KEY (`id_landing`) REFERENCES `tm_landing` (`id_landing`);

--
-- Filtros para la tabla `resumen_diario_detalle`
--
ALTER TABLE `resumen_diario_detalle`
  ADD CONSTRAINT `FK_RDD_RES` FOREIGN KEY (`id_resumen`) REFERENCES `resumen_diario` (`id_resumen`),
  ADD CONSTRAINT `FK_RDD_VEN` FOREIGN KEY (`id_venta`) REFERENCES `tm_venta` (`id_venta`);

--
-- Filtros para la tabla `tm_aper_cierre`
--
ALTER TABLE `tm_aper_cierre`
  ADD CONSTRAINT `FK_ac_caja` FOREIGN KEY (`id_caja`) REFERENCES `tm_caja` (`id_caja`),
  ADD CONSTRAINT `FK_ac_turno` FOREIGN KEY (`id_turno`) REFERENCES `tm_turno` (`id_turno`),
  ADD CONSTRAINT `FK_ac_usu` FOREIGN KEY (`id_usu`) REFERENCES `tm_usuario` (`id_usu`);

--
-- Filtros para la tabla `tm_compra`
--
ALTER TABLE `tm_compra`
  ADD CONSTRAINT `FK_comp_prov` FOREIGN KEY (`id_prov`) REFERENCES `tm_proveedor` (`id_prov`),
  ADD CONSTRAINT `FK_comp_tipoc` FOREIGN KEY (`id_tipo_compra`) REFERENCES `tm_tipo_compra` (`id_tipo_compra`),
  ADD CONSTRAINT `FK_comp_tipod` FOREIGN KEY (`id_tipo_doc`) REFERENCES `tm_tipo_doc` (`id_tipo_doc`),
  ADD CONSTRAINT `FK_comp_usu` FOREIGN KEY (`id_usu`) REFERENCES `tm_usuario` (`id_usu`);

--
-- Filtros para la tabla `tm_compra_credito`
--
ALTER TABLE `tm_compra_credito`
  ADD CONSTRAINT `FK_compcre_idcomp` FOREIGN KEY (`id_compra`) REFERENCES `tm_compra` (`id_compra`);

--
-- Filtros para la tabla `tm_compra_detalle`
--
ALTER TABLE `tm_compra_detalle`
  ADD CONSTRAINT `FK_CDET_COM` FOREIGN KEY (`id_compra`) REFERENCES `tm_compra` (`id_compra`);

--
-- Filtros para la tabla `tm_credito_detalle`
--
ALTER TABLE `tm_credito_detalle`
  ADD CONSTRAINT `FK_CRED_CRED` FOREIGN KEY (`id_credito`) REFERENCES `tm_compra_credito` (`id_credito`),
  ADD CONSTRAINT `FK_cred_usu` FOREIGN KEY (`id_usu`) REFERENCES `tm_usuario` (`id_usu`);

--
-- Filtros para la tabla `tm_detalle_pedido`
--
ALTER TABLE `tm_detalle_pedido`
  ADD CONSTRAINT `FK_DPED_PED` FOREIGN KEY (`id_pedido`) REFERENCES `tm_pedido` (`id_pedido`),
  ADD CONSTRAINT `FK_DPED_PRES` FOREIGN KEY (`id_pres`) REFERENCES `tm_producto_pres` (`id_pres`),
  ADD CONSTRAINT `FK_DPED_USU` FOREIGN KEY (`id_usu`) REFERENCES `tm_usuario` (`id_usu`);

--
-- Filtros para la tabla `tm_detalle_venta`
--
ALTER TABLE `tm_detalle_venta`
  ADD CONSTRAINT `FK_DVEN_VEN` FOREIGN KEY (`id_venta`) REFERENCES `tm_venta` (`id_venta`);

--
-- Filtros para la tabla `tm_gastos_adm`
--
ALTER TABLE `tm_gastos_adm`
  ADD CONSTRAINT `FK_EADM_APC` FOREIGN KEY (`id_apc`) REFERENCES `tm_aper_cierre` (`id_apc`),
  ADD CONSTRAINT `FK_EADM_TGAS` FOREIGN KEY (`id_tipo_gasto`) REFERENCES `tm_tipo_gasto` (`id_tipo_gasto`),
  ADD CONSTRAINT `FK_EADM_USU` FOREIGN KEY (`id_usu`) REFERENCES `tm_usuario` (`id_usu`);

--
-- Filtros para la tabla `tm_impresora`
--
ALTER TABLE `tm_impresora`
  ADD CONSTRAINT `fk_imp_arepro` FOREIGN KEY (`id_areap`) REFERENCES `tm_area_prod` (`id_areap`);

--
-- Filtros para la tabla `tm_ingresos_adm`
--
ALTER TABLE `tm_ingresos_adm`
  ADD CONSTRAINT `FK_IADM_APC` FOREIGN KEY (`id_apc`) REFERENCES `tm_aper_cierre` (`id_apc`),
  ADD CONSTRAINT `FK_IADM_USU` FOREIGN KEY (`id_usu`) REFERENCES `tm_usuario` (`id_usu`);

--
-- Filtros para la tabla `tm_insumo`
--
ALTER TABLE `tm_insumo`
  ADD CONSTRAINT `FK_ins_catg` FOREIGN KEY (`id_catg`) REFERENCES `tm_insumo_catg` (`id_catg`),
  ADD CONSTRAINT `FK_ins_med` FOREIGN KEY (`id_med`) REFERENCES `tm_tipo_medida` (`id_med`);

--
-- Filtros para la tabla `tm_inventario_entsal`
--
ALTER TABLE `tm_inventario_entsal`
  ADD CONSTRAINT `FK_INVES_RESP` FOREIGN KEY (`id_responsable`) REFERENCES `tm_usuario` (`id_usu`),
  ADD CONSTRAINT `FK_INVES_USU` FOREIGN KEY (`id_usu`) REFERENCES `tm_usuario` (`id_usu`);

--
-- Filtros para la tabla `tm_mesa`
--
ALTER TABLE `tm_mesa`
  ADD CONSTRAINT `fk_mesa_salon` FOREIGN KEY (`id_salon`) REFERENCES `tm_salon` (`id_salon`);

--
-- Filtros para la tabla `tm_modulos`
--
ALTER TABLE `tm_modulos`
  ADD CONSTRAINT `fk_modulo_plan` FOREIGN KEY (`id_plan`) REFERENCES `tm_plan` (`id_plan`);

--
-- Filtros para la tabla `tm_pedido`
--
ALTER TABLE `tm_pedido`
  ADD CONSTRAINT `FK_ped_tp` FOREIGN KEY (`id_tipo_pedido`) REFERENCES `tm_tipo_pedido` (`id_tipo_pedido`),
  ADD CONSTRAINT `FK_ped_usu` FOREIGN KEY (`id_usu`) REFERENCES `tm_usuario` (`id_usu`);

--
-- Filtros para la tabla `tm_pedido_delivery`
--
ALTER TABLE `tm_pedido_delivery`
  ADD CONSTRAINT `FK_peddel_cli` FOREIGN KEY (`id_cliente`) REFERENCES `tm_cliente` (`id_cliente`),
  ADD CONSTRAINT `FK_peddel_ped` FOREIGN KEY (`id_pedido`) REFERENCES `tm_pedido` (`id_pedido`);

--
-- Filtros para la tabla `tm_pedido_llevar`
--
ALTER TABLE `tm_pedido_llevar`
  ADD CONSTRAINT `FK_pedlle_ped` FOREIGN KEY (`id_pedido`) REFERENCES `tm_pedido` (`id_pedido`);

--
-- Filtros para la tabla `tm_pedido_mesa`
--
ALTER TABLE `tm_pedido_mesa`
  ADD CONSTRAINT `FK_pedme_mesa` FOREIGN KEY (`id_mesa`) REFERENCES `tm_mesa` (`id_mesa`),
  ADD CONSTRAINT `FK_pedme_mozo` FOREIGN KEY (`id_mozo`) REFERENCES `tm_usuario` (`id_usu`),
  ADD CONSTRAINT `FK_pedme_ped` FOREIGN KEY (`id_pedido`) REFERENCES `tm_pedido` (`id_pedido`);

--
-- Filtros para la tabla `tm_producto`
--
ALTER TABLE `tm_producto`
  ADD CONSTRAINT `FK_prod_area` FOREIGN KEY (`id_areap`) REFERENCES `tm_area_prod` (`id_areap`),
  ADD CONSTRAINT `FK_prod_catg` FOREIGN KEY (`id_catg`) REFERENCES `tm_producto_catg` (`id_catg`);

--
-- Filtros para la tabla `tm_producto_ingr`
--
ALTER TABLE `tm_producto_ingr`
  ADD CONSTRAINT `FK_PING_MED` FOREIGN KEY (`id_med`) REFERENCES `tm_tipo_medida` (`id_med`),
  ADD CONSTRAINT `FK_PING_PRES` FOREIGN KEY (`id_pres`) REFERENCES `tm_producto_pres` (`id_pres`);

--
-- Filtros para la tabla `tm_producto_pres`
--
ALTER TABLE `tm_producto_pres`
  ADD CONSTRAINT `FK_PROP_PROD` FOREIGN KEY (`id_prod`) REFERENCES `tm_producto` (`id_prod`);

--
-- Filtros para la tabla `tm_produc_topicos`
--
ALTER TABLE `tm_produc_topicos`
  ADD CONSTRAINT `tm_produc_topicos_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `tm_producto` (`id_prod`),
  ADD CONSTRAINT `tm_produc_topicos_ibfk_2` FOREIGN KEY (`id_topicos`) REFERENCES `tm_topicos` (`id_topicos`);

--
-- Filtros para la tabla `tm_sedes`
--
ALTER TABLE `tm_sedes`
  ADD CONSTRAINT `fk_sedes_empres` FOREIGN KEY (`id_empresa`) REFERENCES `tm_empresa` (`id_de`);

--
-- Filtros para la tabla `tm_sede_usuario`
--
ALTER TABLE `tm_sede_usuario`
  ADD CONSTRAINT `fk_sedes_sede` FOREIGN KEY (`id_sede`) REFERENCES `tm_sedes` (`id_sede`),
  ADD CONSTRAINT `fk_sedes_usu` FOREIGN KEY (`id_usu`) REFERENCES `tm_usuario` (`id_usu`);

--
-- Filtros para la tabla `tm_series`
--
ALTER TABLE `tm_series`
  ADD CONSTRAINT `fk_tipodoc_serie` FOREIGN KEY (`id_tipo_doc`) REFERENCES `tm_tipo_doc` (`id_tipo_doc`);

--
-- Filtros para la tabla `tm_tipo_pago`
--
ALTER TABLE `tm_tipo_pago`
  ADD CONSTRAINT `FK_TIPODEPAGO` FOREIGN KEY (`id_pago`) REFERENCES `tm_pago` (`id_pago`);

--
-- Filtros para la tabla `tm_usuario`
--
ALTER TABLE `tm_usuario`
  ADD CONSTRAINT `FK_usu_rol` FOREIGN KEY (`id_rol`) REFERENCES `tm_rol` (`id_rol`);

--
-- Filtros para la tabla `tm_venta`
--
ALTER TABLE `tm_venta`
  ADD CONSTRAINT `FK_venta_apc` FOREIGN KEY (`id_apc`) REFERENCES `tm_aper_cierre` (`id_apc`),
  ADD CONSTRAINT `FK_venta_cli` FOREIGN KEY (`id_cliente`) REFERENCES `tm_cliente` (`id_cliente`),
  ADD CONSTRAINT `FK_venta_td` FOREIGN KEY (`id_tipo_doc`) REFERENCES `tm_tipo_doc` (`id_tipo_doc`),
  ADD CONSTRAINT `FK_venta_tp` FOREIGN KEY (`id_pago`) REFERENCES `tm_tipo_pago` (`id_tipo_pago`),
  ADD CONSTRAINT `FK_venta_tpe` FOREIGN KEY (`id_tipo_pedido`) REFERENCES `tm_tipo_pedido` (`id_tipo_pedido`),
  ADD CONSTRAINT `FK_venta_usu` FOREIGN KEY (`id_usu`) REFERENCES `tm_usuario` (`id_usu`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
