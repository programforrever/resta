<?php
class Api_Model
{

    public function __construct() {
        $this->db = new Database(DB_TYPE, DB_HOST, DB_NAME, DB_USER, DB_PASS, DB_CHARSET);

    }


    public function getEmpresa()
    {
        try
        {
            $idemp=Session::get('idemp');
            $idsede=Session::get('sede_id');
            
            $stm = $this->db->prepare("SELECT id_de,ruc,razon_social,ubigeo,direccion_fiscal,email,celular,urlapi,passentorno FROM tm_empresa WHERE id_de = $idemp");
            $stm->execute();
            $c = $stm->fetch(PDO::FETCH_OBJ);
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function getCabecera($cod_ven)
    {
        try
        {
            $igv=Session::get('igv');      
            $stm = $this->db->prepare("SELECT
            tm_venta.enviado_sunat,
            tm_venta.id_tipo_doc AS tipo_documento, /**Factura 1, Boleta 3 */
            IF(tm_cliente.tipo_cliente=1,tm_cliente.dni,tm_cliente.ruc) AS numero_documento,
            IF(tm_cliente.tipo_cliente=1,CONCAT(tm_cliente.nombres),tm_cliente.razon_social) AS razon_social,
            tm_cliente.tipo_cliente AS tipo_cliente,
            tm_cliente.direccion AS direccion,
            tm_cliente.telefono AS telefono,
            tm_cliente.correo AS correo,
            DATE(tm_venta.fecha_venta) AS fecha,
            (tm_venta.fecha_venta) AS fecha_imp,
            TIME(tm_venta.fecha_venta) as hora_emision,
            IF(tm_venta.id_tipo_doc='1','03','01') AS tipo_comprobante, /**Agreegar tipo cliente */
            (tm_venta.total) AS total,
            (tm_venta.igv * 100) AS impuesto,
            tm_venta.serie_doc,
            tm_venta.nro_doc,
            tm_venta.descuento_monto,
            tm_venta.comision_delivery,
            tm_venta.crt_fac_cons
            FROM
            tm_venta
            INNER JOIN tm_cliente ON tm_venta.id_cliente = tm_cliente.id_cliente
            INNER JOIN tm_series ON tm_venta.id_tipo_doc = tm_series.id_tipo_doc
            INNER JOIN tm_usuario ON tm_venta.id_usu = tm_usuario.id_usu
            WHERE tm_venta.id_tipo_doc IN (1,2) AND tm_venta.id_venta = ?");
            $stm->execute(array($cod_ven));
            $c = $stm->fetch(PDO::FETCH_OBJ);

            $c->{'Detalle'} = $this->db->query("SELECT tdv.id_prod,if(tdv.crt_mod_prod = 1, CONCAT(pp.cod_prod,'M'),pp.cod_prod) AS codigo_producto, 
            CONCAT(p.nombre,' ',if(tdv.crt_mod_prod = 1, tdv.nom_prod_pres,pp.presentacion)) AS nombre_producto,
            tdv.crt_mod_prod AS crt_mod_prod, 
            IF(pp.impuesto='1','10','20') AS codigo_afectacion, 
            CAST(tdv.cantidad AS DECIMAL(7,2)) AS cantidad, 
            IF(pp.impuesto='1',ROUND((tdv.precio/(1 + $igv)),6),tdv.precio) AS valor_unitario,
            tdv.precio AS precio_unitario,
            IF(pp.impuesto='1',ROUND((tdv.precio/(1 + $igv))*tdv.cantidad,2),
            ROUND(tdv.precio*tdv.cantidad,2)) AS valor_venta,
            IF(pp.impuesto='1',ROUND((tdv.precio/(1 + $igv)*tdv.cantidad) * $igv,2),0) AS total_igv,
            pp.crt_icbper AS crt_icbper
            FROM tm_detalle_venta AS tdv 
            JOIN tm_venta AS v ON tdv.id_venta = v.id_venta
            JOIN tm_producto_pres AS pp ON tdv.id_prod = pp.id_pres
            JOIN tm_producto AS p ON pp.id_prod = p.id_prod
            WHERE v.id_tipo_doc  IN ('1','2') AND tdv.precio > 0 AND tdv.id_venta =".$cod_ven)
                ->fetchAll(PDO::FETCH_OBJ);
            return $c;
        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    public function get_topicos($cod_ven,$id_pres,$crt_mod_prod){

        try{

            $stm = $this->db->prepare("SELECT tdp.id_pres, sum(tdp.precioTopico) as precioTopico FROM tm_venta AS vvc
            INNER JOIN tm_detalle_pedido AS tdp ON vvc.id_pedido = tdp.id_pedido
            WHERE vvc.id_venta = ? AND tdp.id_pres = ? AND tdp.crt_mod_prod = ?;");
            $stm->execute(array($cod_ven,$id_pres,$crt_mod_prod));
            $c = $stm->fetch(PDO::FETCH_OBJ);
            return $c;

        } catch(Exception $e)
        {
            die($e->getMessage());
        }

    }

    public function get_crt_imp_bol($cod_ven){
        try{

            $stm = $this->db->prepare("SELECT count(tpp.crt_icbper) AS crt_icbper FROM tm_venta tv
            JOIN tm_detalle_pedido tdp ON tv.id_pedido = tdp.id_pedido
            JOIN tm_producto_pres tpp ON tdp.id_pres = tpp.id_pres
            WHERE tv.id_venta = " .$cod_ven. " AND  tpp.crt_icbper = 1");
            $stm->execute();
            $c = $stm->fetch(PDO::FETCH_OBJ);
            return $c;

        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }

    
    public function get_venta($cod_ven){
        try{

            $stm = $this->db->prepare("SELECT tv.id_tipo_doc, DATE(tv.fecha_venta) AS fecha_venta, tv.external_id FROM tm_venta tv
            WHERE tv.id_venta = ?; ");
            $stm->execute(array($cod_ven));
            $c = $stm->fetch(PDO::FETCH_OBJ);
            return $c;

        }
        catch(Exception $e)
        {
            die($e->getMessage());
        }
    }
}

?>