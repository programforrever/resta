<?php Session::init(); $ver = (Session::get('rol') == 1 OR Session::get('rol') == 2 OR Session::get('rol') == 3) ? '' :  header('location: ' . URL . 'err/danger'); ?>
<?php
//require_once 'api_fact/config/config.php';
require_once 'facturador/model/api_model.php';

class ApiFacturador
{
    public function __construct() {
        $this->db = new Database(DB_TYPE, DB_HOST, DB_NAME, DB_USER, DB_PASS, DB_CHARSET);
    }
    //Facturacion gravada-inafecta-> se emplea cuando el porcentaje del igv es 0

    //Facturacion gravada-gratuita-> se aplica en cortesia

    //Facturacion gravada-Impuesto a la bolsa plastica-> aplica en delivery y para llevar

    public function facturador($cod_ven,$num) {
        $api = new Api_Model();
        $documento = $api->getCabecera($cod_ven);
        $empresa = $api->getEmpresa();
        $crt_imp_bol = $api->get_crt_imp_bol($cod_ven);
        
        $total_ope_gravadas = 0;
        $total_igv_producto = 0;

        $total_valor_item = 0;
        $precio_unitario = 0;
        $valor_unitario = 0;
        $total_item = 0;
        $total_imp_bol=0;
        $imp_bol = 0;
        $crt_top =  0;
        $codigo_tipo_afectacion_igv = 0;

        $tipoDoc = 0;
        $tipoCliente = 0;
        $numero_documento_ident = 0;
        $name_cliente = 0;

        $productos = array();
        $cargos = array();
        
        $resultado_detalle = array();
        $resultado_detalle = json_decode(json_encode($documento->Detalle), true);//obteniendo el detalle de los productos
        
        /**VARIABLE PARA ENVIO POR FACTURA POR CONSUMO */
        $sum_total_igv_producto = 0;
        $sum_total_item = 0;
        /**FIN PARA ENVIO POR FACTURA POR CONSUMO */

        foreach ($resultado_detalle as $detalle ){
            $get_topicos = $api->get_topicos($cod_ven,$detalle['id_prod'],$detalle['crt_mod_prod']);

            if($get_topicos->precioTopico > 0){
                $crt_top = 1;
            }

            $total_item = number_format(($detalle['precio_unitario'] * $detalle['cantidad']) + $get_topicos->precioTopico,3,'.', '');            
            $precio_unitario = number_format((($detalle['precio_unitario'] * $detalle['cantidad']) + $get_topicos->precioTopico)/$detalle['cantidad'],3,'.', '');
            
            if($detalle['codigo_afectacion'] == '10' && Session::get('igv') != 0){
                $codigo_tipo_afectacion_igv = 10;
                $total_ope_gravadas = $total_ope_gravadas + $detalle['valor_venta'];
                $total_igv_producto = number_format(($total_item) - ($total_item / (1+Session::get('igv'))),3,'.', '');
                $valor_unitario = number_format(($total_item-$total_igv_producto)/$detalle['cantidad'],3,'.', '');

                $sum_total_igv_producto = $total_igv_producto + $sum_total_igv_producto;
            } else{
                $codigo_tipo_afectacion_igv = 20;
                $total_ope_gravadas = $total_ope_gravadas + 0;
                $valor_unitario = number_format(($total_item)/$detalle['cantidad'],3,'.', '');
                $sum_total_igv_producto = 0.00;

            }
            $total_valor_item = number_format($valor_unitario * $detalle['cantidad'], 3, '.', '');////////////
            
            $sum_total_item  = $total_item  + $sum_total_item;

            if($detalle['crt_icbper'] == "1"){
                $total_imp_bol = ($detalle['cantidad'] * Session::get('imp_icbper'))+ $total_imp_bol;
                $imp_bol = ($detalle['cantidad'] * Session::get('imp_icbper'));
            }else{
                $imp_bol = 0.00;
            }

            if($documento->crt_fac_cons == 0){
                //Detalle ITEMS
                $productos[] = [ //el topico se suma al producto
                    "codigo_interno"=> $detalle['codigo_producto'],
                    "descripcion"=>$detalle['nombre_producto'],
                    //"codigo_producto_sunat"=> "51121703",
                    "unidad_de_medida"=> "NIU", #dejarlo en NIU la Unidad de Medida
                    "cantidad"=> $detalle['cantidad'],
                    "valor_unitario"=> number_format($valor_unitario, 3, '.', ''),
                    "codigo_tipo_precio"=> "01",//????
                    "precio_unitario"=> number_format($precio_unitario , 3, '.', ''),
                    "codigo_tipo_afectacion_igv"=> $codigo_tipo_afectacion_igv,
                    "total_base_igv"=> number_format($total_valor_item, 3, '.', ''),
                    "porcentaje_igv"=>  Session::get('igv')*100,
                    "total_igv"=> number_format($total_igv_producto, 3, '.', ''),
                    "total_impuestos_bolsa_plastica"=> $imp_bol,
                    "total_impuestos"=> number_format($total_igv_producto, 3, '.', ''),
                    "total_valor_item"=> number_format($total_valor_item, 3, '.', ''),
                    "total_item"=> number_format($total_item, 3, '.', ''),
                ];
            }
        }

        //number_format(((($documento->total)) / (1+Session::get('igv'))), 2, '.', '');

        if($documento->crt_fac_cons == 1){
            $productos[] = [ //el topico se suma al producto
                "codigo_interno"=> "FC001",
                "descripcion"=>"POR CONSUMO",
                "unidad_de_medida"=> "NIU", #dejarlo en NIU la Unidad de Medida
                "cantidad"=> 1,
                "valor_unitario"=> number_format(($sum_total_item)/(1+Session::get('igv')), 3, '.', ''),
                "codigo_tipo_precio"=> "01",
                "precio_unitario"=> number_format($sum_total_item, 2, '.', ''),
                "codigo_tipo_afectacion_igv"=> $codigo_tipo_afectacion_igv,
                "total_base_igv"=> number_format(($sum_total_item)/(1+Session::get('igv')), 3, '.', ''),
                "porcentaje_igv"=>  Session::get('igv')*100,
                "total_igv"=> number_format($sum_total_igv_producto, 2, '.', ''),
                "total_impuestos_bolsa_plastica"=> $total_imp_bol,
                "total_impuestos"=> number_format($sum_total_igv_producto, 2, '.', ''),
                "total_valor_item"=> number_format(($sum_total_item)/(1+Session::get('igv')), 3, '.', ''),
                "total_item"=> number_format($sum_total_item, 3, '.', ''),
            ];
        }

        if($documento->tipo_documento == "1"){
            $tipoDoc = "03";//Boleta
        }elseif($documento->tipo_documento == "2"){
            $tipoDoc = "01";//Factura
        }

        if($documento->tipo_cliente == "1"){
            $tipoCliente = "1";//DNI
        }elseif($documento->tipo_cliente == "2"){
            $tipoCliente = "6"; //RUC
        }

        if($documento->comision_delivery > 0){
            $cargos[] = [
                "codigo"=> "46",
                "descripcion"=> "Regargo por servicios",
                "factor"=> number_format($documento->comision_delivery / $documento->total,6, '.', ''),
                "monto"=> number_format($documento->comision_delivery, 2, '.', ''),
                "base"=> number_format($documento->total, 2, '.', '')
            ];
        }


        //si control impuesto a la bolsa es > 0, (FACTURA GRAVADA - IMPUESTO BOLSA PLASTICA)
        if($crt_imp_bol->crt_icbper > 0 && $documento->descuento_monto == 0){
            $totalope =  0;
            $documentoTotal = 0;
            if($crt_top == 1){
                $totalope = ($documento->total - $total_imp_bol);
                $documentoTotal = ($documento->total - $total_imp_bol);
            }else{
                $totalope = $documento->total;
                $documentoTotal = ($documento->total - $total_imp_bol);
            }
            
            if($total_ope_gravadas > 0 && Session::get('igv') != 0){

                $total_gravadas = (($totalope) - $documento->descuento_monto) / (1 + Session::get('igv'));
                 // 83.50 / 1.18 = 70.76
                $total_exoneradas = "0";
    
                $sub_tot = number_format(((($totalope) - $documento->descuento_monto) - ((($totalope) - $documento->descuento_monto) / (1+Session::get('igv')))), 3, '.', '');
    
                $sub_tot1 = number_format(((($totalope) - $documento->descuento_monto) / (1 + Session::get('igv'))), 3, '.', '');
                $totales = number_format((($documentoTotal + $documento->comision_delivery) - $documento->descuento_monto), 3, '.', '');
                $totales_2 = $totales;
            }else {
    
                $sub_tot = number_format(0, 3, '.', '');
                $sub_tot1 = number_format((($documento->total)- $documento->descuento_monto), 3, '.', '');
                $totales_2 = $sub_tot1 - $total_imp_bol;
                $total_gravadas = "0";
                $total_exoneradas = $sub_tot1;
            }
    
            $data = [
                "serie_documento"       => $documento->serie_doc,
                "numero_documento"      => ltrim($documento->nro_doc,"0"),
                "fecha_de_emision"      => $documento->fecha,
                "hora_de_emision"       => $documento->hora_emision,
                "codigo_tipo_operacion" => "0101",
                "codigo_tipo_documento" => $tipoDoc, /**Factura ->1, Boleta 3*/
                "codigo_tipo_moneda"    => "PEN",
                "fecha_de_vencimiento"  => $documento->fecha,
                "numero_orden_de_compra"=> "",
                "datos_del_cliente_o_receptor" => [
                "codigo_tipo_documento_identidad"=> $tipoCliente,
                    "numero_documento" => $documento->numero_documento,
                    "apellidos_y_nombres_o_razon_social" => $documento->razon_social,
                    "codigo_pais" => "PE",
                    "ubigeo" => "",
                    "direccion" => $documento->direccion,
                    "correo_electronico"=> $documento->correo,
                    "telefono"=> $documento->telefono
                ],
                "cargos"  => $cargos,
                "totales" => [
                    "total_cargos"=> number_format($documento->comision_delivery, 3, '.', ''),
                    "total_exportacion" => 0.00,
                    "total_operaciones_gravadas"=> number_format($total_gravadas, 3, '.', ''), #subtotal
                    "total_operaciones_inafectas"=> 0.00,
                    "total_operaciones_exoneradas"=> number_format($total_exoneradas, 3, '.', ''),
                    "total_operaciones_gratuitas"=> 0.00,
                    "total_impuestos_bolsa_plastica"=> $total_imp_bol,
                    "total_igv"=> $sub_tot,
                    "total_impuestos"=> $sub_tot,
                    "total_valor"=> $sub_tot1,
                    "total_venta"=> $totales_2 + $total_imp_bol
                ],
                "items"  => $productos
            
            ];

        }elseif ($documento->descuento_monto > 0){ //factura con descuento
            
            
            if($total_ope_gravadas > 0 && Session::get('igv') != 0){

                $total_gravadas = (($documento->total) ) / (1+Session::get('igv'));
                 // 83.50 / 1.18 = 70.76
                $total_exoneradas = "0";
    
                $sub_tot = number_format(((($documento->total)) - ((($documento->total)) / (1+Session::get('igv')))), 3, '.', '');
    
                $sub_tot1 = number_format(((($documento->total)) / (1+Session::get('igv'))), 3, '.', '');
                $totales = number_format((($documento->total) - $documento->descuento_monto), 3, '.', '');
                $totales_2 = $totales;

                /*$ope_descto_factor = $documento->total / $documento->descuento_monto;
                $descto_factor = 100/$ope_descto_factor;*/
            }else {
    
                $sub_tot = number_format(0, 3, '.', '');
                $sub_tot1 = number_format((($documento->total)- $documento->descuento_monto), 3, '.', '');
                $totales_2 = $sub_tot1 - $total_imp_bol;
                $total_gravadas = "0";
                $total_exoneradas = number_format((($documento->total)), 3, '.', '');
            }
    
            $descuentos[] = [
                "codigo"=> "03",
                "descripcion"=> "Descuentos globales que no afectan la base imponible del IGV/IVAP",
                "factor"=> number_format($documento->descuento_monto / $documento->total,4, '.', ''),//$descto_factor / 100,
                "monto"=> $documento->descuento_monto,/*18.00*/
                "base"=> number_format($documento->total, 3, '.', ''),
            ];
            $data = [
                "serie_documento"       => $documento->serie_doc,
                "numero_documento"      => ltrim($documento->nro_doc,"0"),
                "fecha_de_emision"      => $documento->fecha,
                "hora_de_emision"       => $documento->hora_emision,
                "codigo_tipo_operacion" => "0101",
                "codigo_tipo_documento" => $tipoDoc, /**Factura ->1, Boleta 3*/
                "codigo_tipo_moneda"    => "PEN",
                "fecha_de_vencimiento"  => $documento->fecha,
                "numero_orden_de_compra"=> "",
                "datos_del_cliente_o_receptor" => [
                    "codigo_tipo_documento_identidad"=> $tipoCliente,
                    "numero_documento" => $documento->numero_documento,
                    "apellidos_y_nombres_o_razon_social" => $documento->razon_social,
                    "codigo_pais" => "PE",
                    "ubigeo" => "",
                    "direccion" => $documento->direccion,
                    "correo_electronico"=> $documento->correo,
                    "telefono"=> $documento->telefono
                ],
                "descuentos" => $descuentos,
                "totales" => [
                    "total_descuentos"=> number_format($documento->descuento_monto, 3, '.', ''),
                    "total_exportacion"=> 0.00,
                    "total_operaciones_gravadas"=> number_format($total_gravadas, 3, '.', ''),
                    "total_operaciones_inafectas"=> 0.00,
                    "total_operaciones_exoneradas"=> number_format($total_exoneradas, 3, '.', ''),
                    "total_operaciones_gratuitas"=> 0.00,
                    "total_igv"=> $sub_tot,
                    "total_impuestos"=> $sub_tot,
                    "total_valor"=> $sub_tot1,
                    "subtotal_venta"=> $documento->total,
                    "total_venta"=> $totales_2
                ],
                "items"  => $productos
            ];


        }else{//Factura gravada o Boleta gravada
           
            if($total_ope_gravadas > 0 && Session::get('igv') != 0){

                $total_gravadas = (($documento->total)) / (1+Session::get('igv'));
                 // 83.50 / 1.18 = 70.76
                $total_exoneradas = "0";
    
                $sub_tot = number_format(((($documento->total)) - ((($documento->total)) / (1+Session::get('igv')))), 3, '.', '');
    
                $sub_tot1 = number_format(((($documento->total)) / (1+Session::get('igv'))), 3, '.', '');
                $totales = number_format((($documento->total + $documento->comision_delivery)), 3, '.', '');
                $totales_2 = $totales;
            }else {
    
                $sub_tot = number_format(0, 2, '.', '');
                $sub_tot1 = number_format((($documento->total)- $documento->descuento_monto), 3, '.', '');
                $totales_2 = number_format($sub_tot1 + $documento->comision_delivery, 3, '.', '');
                $total_gravadas = "0";
                $total_exoneradas = $sub_tot1;
            }
    
            $data = [
                "serie_documento"       => $documento->serie_doc,
                "numero_documento"      => ltrim($documento->nro_doc,"0"),
                "fecha_de_emision"      => $documento->fecha,
                "hora_de_emision"       => $documento->hora_emision,
                "codigo_tipo_operacion" => "0101",
                "codigo_tipo_documento" => $tipoDoc, /**Factura ->1, Boleta 3*/
                "codigo_tipo_moneda"    => "PEN",
                "fecha_de_vencimiento"  => $documento->fecha,
                "numero_orden_de_compra"=> "",
                "datos_del_cliente_o_receptor" => [
                "codigo_tipo_documento_identidad"=> $tipoCliente,
                    "numero_documento" => $documento->numero_documento,
                    "apellidos_y_nombres_o_razon_social" => $documento->razon_social,
                    "codigo_pais" => "PE",
                    "ubigeo" => "",
                    "direccion" => $documento->direccion,
                    "correo_electronico"=> $documento->correo,
                    "telefono"=> $documento->telefono
                ],
                "cargos"  => $cargos,
                "totales" => [
                    "total_cargos"=> number_format($documento->comision_delivery, 3, '.', ''),
                    "total_exportacion" => 0.00,
                    "total_operaciones_gravadas"=> number_format($total_gravadas, 3, '.', ''), #subtotal
                    "total_operaciones_inafectas"=> 0.00,
                    "total_operaciones_exoneradas"=> number_format($total_exoneradas, 3, '.', ''),
                    "total_operaciones_gratuitas"=> 0.00,
                    "total_igv"=> $sub_tot,
                    "total_impuestos"=> $sub_tot,
                    "total_valor"=> $sub_tot1,
                    "total_venta"=> $totales_2
                ],
                "items"  => $productos
            ];
        }
         //Invocamos el servicio
         $token = utf8_decode($empresa->passentorno); //en caso quieras utilizar algún token generado desde tu sistema
         $ruta = utf8_decode($empresa->urlapi);
         //codificamos la data

         $data_json = json_encode($data);

         $ch = curl_init();
         curl_setopt($ch, CURLOPT_URL, $ruta.'documents');
         curl_setopt(
                 $ch, CURLOPT_HTTPHEADER, array(
                    'Content-Type: application/json',
                    'Authorization: ' . $token));
         curl_setopt($ch, CURLOPT_POST, 1);
         curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
         curl_setopt($ch, CURLOPT_POSTFIELDS, $data_json);
         curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
         $rs = json_decode(curl_exec($ch));
         curl_close($ch);

        if($rs == null){
            $msg = "Verifique la URL del facturador. (Comuniquese con el administrador)";
            $external_id = "0";
        }else if($rs->success == false) {
            $msg = $rs->message;
            $external_id = "0";

        }else if($rs->success == true){
            if($rs->data->state_type_description == "Rechazado"){
                $external_id = "0";
                $msg = $rs->response->description;
            }else{
                $external_id = $rs->data->external_id;
                $msg = "--";
            }
        }

        $stm = $this->db->prepare("UPDATE tm_venta SET external_id =  '".$external_id."',msg_fact = '$msg' WHERE id_venta = ?");
        $stm->execute(array($cod_ven));
        echo $msg;
        
    }

    public function anular_venta_fact($cod_ven) {
        $api = new Api_Model();
        $empresa = $api->getEmpresa();
        $get_venta = $api->get_venta($cod_ven);
        $rutaapi = $empresa->urlapi;
        if($get_venta->id_tipo_doc == 1){
            $ruta = $rutaapi.'summaries';
            $documentos[] = [
                "external_id" => $get_venta->external_id,//probar con serie o número de comprobante
                "motivo_anulacion"=> "Anulación de operación"//->anulación de operación,
            ];
    
            $data = [
                "fecha_de_emision_de_documentos"=> $get_venta->fecha_venta,
                "codigo_tipo_proceso"           => "3",
                "documentos" => $documentos
    
            ];
        }elseif($get_venta->id_tipo_doc == 2){

            $ruta = $rutaapi.'voided';
            $documentos[] = [
                "external_id" => $get_venta->external_id,//probar con serie o número de comprobante
                "motivo_anulacion"=> "Anulación de operación"//->anulación de operación,
            ];
    
            $data = [
                "fecha_de_emision_de_documentos"=> $get_venta->fecha_venta,
                "documentos" => $documentos
    
            ];
        }
        

        //Invocamos el servicio
        $token = $empresa->passentorno; //en caso quieras utilizar algún token generado desde tu sistema
        
        //$ruta = $empresa->urlapi;
        //codificamos la data

        $data_json = json_encode($data);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $ruta);
        curl_setopt(
                $ch, CURLOPT_HTTPHEADER, array(
                   'Content-Type: application/json',
                   'Authorization: ' . $token));
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_json);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $rs = json_decode(curl_exec($ch));
        curl_close($ch);

        $enviado_facturador = (@$rs->success == 'true') ? '1' : '0';

        $respuesta = array('enviado_facturador' => $enviado_facturador);

    }

}


?>