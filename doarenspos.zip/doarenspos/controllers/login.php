<?php 
    Session::init(); 
    // $ver = (Session::get('rol') == 1) OR Session::get('rol') == 2 ? '' :  header('location: ' . URL . 'err/danger'); 
    // $ver = (Session::get('bloqueo') == 0 OR Session::get('bloqueo') == null) ? '' :  header('location: ' . URL . 'err/bloqueo');
?>
<?php

class Login extends Controller {

	function __construct() {
		parent::__construct();	
		// Auth::handleLogin();
	}
	
	function index() 
	{	
		//echo Hash::create('sha256', 'jonathan', HASH_PASSWORD_KEY);
		if(Session::get('loggedIn') <> 1){
			Session::init();
			Session::set('loggedIn', false);
			$this->view->js = array('login/js/login.js');
			$this->view->render('login/index',false);
		}else{

			if(Session::get('rol') == 3 || Session::get('rol') == 5){ // cajero y mozo 
				Session::init();
				header('location: ' . URL . 'venta');
			}elseif(Session::get('rol') == 4){ // produccion
				Session::init();
				header('location: ' . URL . 'produccion');
			}elseif(Session::get('rol') == 6){
				Session::destroy();
				header('location: ' . URL .  'login');
				exit;
			}
			else{ 
				Session::init();
				//header('location: ' . URL . 'tablero');
				header('location: ' . URL . 'login/prevsede');
			}
		}
	}

	
	function run()
	{
		$this->model->run($_POST);
		$this->model->planes_modulo($_POST);

	}

	function tablero(){
		Session::init();
		header('location: ' . URL . 'tablero');
	}

	function produccion(){
		Session::init();
		header('location: ' . URL . 'produccion');
	}

	function venta(){
		Session::init();
		header('location: ' . URL . 'venta');
	}

	function prevsede()
	{
		if(Session::get('loggedIn') <> 1){
			Session::init();
			Session::set('loggedIn', false);
			$this->view->js = array('login/js/login.js');
			$this->view->render('login/index',false);
		}
		if(Session::get('loggedInSede')){
			Session::init();
			header('location: ' . URL . 'tablero');
		}
		else{
			Session::init();
		
			$this->view->js = array('login/js/login.js');
			$this->view->render('login/prevsede',false);
		}

	}

	function emprelistruc(){
		$this->model->emprelistruc($_POST);

	}

	function sede_list(){
		$id=Session::get('idemp');
        $this->model->sede_list($id);
    }

	function select_sede_id(){
        $this->model->select_sede_id($_POST);
    }

	
}