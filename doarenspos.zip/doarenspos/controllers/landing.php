<?php 
    Session::init(); 
    $ver = (Session::get('rol') == 1 OR Session::get('rol') == 2 OR Session::get('rol') == 3) ? '' :  header('location: ' . URL . 'err/danger'); 
    $ver = (Session::get('bloqueo') == 0 OR Session::get('bloqueo') == null) ? '' :  header('location: ' . URL . 'err/bloqueo');
?>
<?php

class Landing extends Controller {

    function __construct() {
		parent::__construct();
	}

    function horarioAtencion() 
	{	
		Auth::handleLogin();
		//$idlanding = 1;
        $this->view->title_page = 'Landing Page';
		//$this->view->Proveedores = $this->model->Proveedores();
        $namelandi=Session::get('namelandi');
        $this->view->js = array('ajuste/js/wizard/jquery.bootstrap.wizard.js','ajuste/js/wizard/wizard.js','ajuste/js/wizard/jquery-ui.min.js','landing/js/landing.js');
        if($namelandi==""){
            //$this->view->js = array('credito/js/func_credito.js');
            $this->view->render('landing/nodisponible', false);
        }else{
            $this->view->landingdata = $this->model->landing_data();
            //$this->view->js = array('credito/js/func_credito.js');
            $this->view->render('landing/horarioAtencion', false);
        }
        
	}

	public function landing_harario_atencion_list(){//
        $this->model->landing_harario_atencion_list($_POST);
    }

	function landingActive()
    {
        print_r(json_encode($this->model->landingActive($_POST)));
    }

	function landingCantMinima()
    {
        print_r(json_encode($this->model->landingCantMinima($_POST)));
    }

    public function landing_horaatenci_list(){
        $this->model->landing_horaatenci_list($_POST);
    }

    function landinghorarioatencionupdate()
    {
        print_r(json_encode($this->model->landinghorarioatencionupdate($_POST)));
    }

    function addlandinghorario()//
    {
        print_r(json_encode($this->model->addlandinghorario($_POST)));
    }

 
	
}