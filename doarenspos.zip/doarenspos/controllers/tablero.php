<?php 
Session::init(); 
$ver = (Session::get('rol') == 1 OR Session::get('rol') == 2) ? '' :  header('location: ' . URL . 'err/danger'); 
$ver = (Session::get('bloq') == 0 OR Session::get('bloq') == null) ? '' :  header('location: ' . URL . 'err/bloqueo');
?>
<?php

class Tablero extends Controller {

	function __construct() {
		parent::__construct();
		Auth::handleLogin();
		$this->view->js = array('tablero/js/func_tablero.js');
	}
	
	function index() 
	{	
		if(Session::get('loggedInSede')){
			if(Session::get('rol') == 2){ // Admin
				$this->view->title_page = 'Inicio';
				$this->view->Caja = $this->model->Caja();
				$this->view->render('tablero/index');
			}elseif(Session::get('rol') == 1){ // Super Admin
				$this->view->title_page = 'Ajuste';
				$this->view->Caja = $this->model->Caja();
				header('location: ' . URL . 'ajusteadmin'); 
			}elseif(Session::get('rol') == 3){ // cajero
				$this->view->title_page = 'Apertura y Cierre';
				$this->view->Caja = $this->model->Caja();
				header('location: ' . URL . 'caja/apercie'); 
			}
			else{
				header('location: ' . URL . 'err/danger'); 
			}
		}else{
			Session::init();
			//header('location: ' . URL . 'tablero');
			header('location: ' . URL . 'login/prevsede');
		}		
	}
	
	function logout()
	{
		Session::destroy();
		header('location: ' . URL .  'login');
		exit;
	}
	
	function tablero_datos()
    {
        $this->model->tablero_datos($_POST);
    }

}