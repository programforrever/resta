<?php 
    Session::init(); 
    $ver = (Session::get('rol') == 1) OR Session::get('rol') == 2 ? '' :  header('location: ' . URL . 'err/danger'); 
    $ver = (Session::get('bloq') == 0 OR Session::get('bloq') == null) ? '' :  header('location: ' . URL . 'err/bloqueo');
?>
<?php 

class AjusteAdmin extends Controller {

	function __construct() {
		parent::__construct();
        Auth::handleLogin();
	}
	
    //Index Ajustes super usuario
	function index() 
	{	
        Session::init();
        Session::set('loggedInSede', true);
        $this->view->title_page = 'Ajustes Admin';
		$this->view->render('ajuste/admin', false);
	}

	/* INICIO MODULO EMPRESA */

    function multiempresa(){
        $this->view->title_page = 'Multiempresa';
        $this->view->js = array('ajuste/js/wizard/jquery.bootstrap.wizard.js','ajuste/js/wizard/wizard.js','ajuste/js/wizard/jquery-ui.min.js','ajuste/js/aju_emp_multi.js');
		$this->view->render('ajuste/all/multiempresa', false);
    }

    public function empresa_list()
    {
        $this->model->empresa_list($_POST);
    }

    function viewaddcliente(){
        $this->view->title_page = 'Cliente';
		$this->view->js = array('ajuste/js/wizard/jquery.bootstrap.wizard.js','ajuste/js/wizard/wizard.js','ajuste/js/wizard/jquery-ui.min.js','ajuste/js/aju_emp_multi.js');
        $this->view->plan = $this->model->plan();
        $this->view->render('ajuste/all/cliente', false);
    }

    function editcliente($id) {
        $this->view->js = array('ajuste/js/wizard/jquery.bootstrap.wizard.js','ajuste/js/wizard/wizard.js','ajuste/js/wizard/jquery-ui.min.js','ajuste/js/aju_emp_multi.js');
        $this->view->empresa = $this->model->empresa_list_data($id);
        $this->view->plan = $this->model->plan();
        $this->view->render('ajuste/all/cliente', false);
    }

    function sede_empresa_crud()
    {
        if($_POST['id_sede']){
           print_r(json_encode($this->model->sedeempresa_crud_update($_POST)));
        } else{
           print_r(json_encode($this->model->sedeempresa_crud_create($_POST)));
        }
    }

    public function empresa_sede_list(){
        $this->model->empresa_sede_list($_POST);
    }

    //datos emrsa
	function datosempresa(){
        $this->view->title_page = 'Datos de la Empresa';
		$this->view->js = array('ajuste/js/aju_emp_datos.js');
		$this->view->render('ajuste/all/empresa', false);
	}

	function datosempresa_data()
    {
        print_r(json_encode($this->model->datosempresa_data($_POST)));
    }

    function usuario_estado_password(){
        $this->model->usuario_estado_password($_POST);
    }

    function datosempresa_crud()
    {
        if($_POST['idempresa'] != ''){
            print_r(json_encode($this->model->datosempresa_crud_update($_POST)));
         } else{
            print_r(json_encode($this->model->datosempresa_crud($_POST)));
            
         }
    }

    function modo_produccion(){
        print_r(json_encode($this->model->modo_produccion($_POST)));
    }
    
    function permiso_proceso(){
        print_r(json_encode($this->model->permiso_proceso($_POST)));
    }

    function crt_usuario_multiples(){
        print_r(json_encode($this->model->crt_usuario_multiples($_POST)));
    }

    function bloq_plataforma(){
        print_r(json_encode($this->model->bloq_plataforma($_POST)));
    }

    function crud_dominio_landing()
    {
        if($_POST['namedomi'] != ''){
            print_r(json_encode($this->model->update_dominio_landing($_POST)));
        } else{
            print_r(json_encode($this->model->create_dominio_landing($_POST)));
            
        }
    }

	function dominio_list_idemp(){
        $this->model->dominio_list_idemp($_POST);
    }





	/* FIN MODULO EMPRESA */

    /*INICIO MODULO PLANES */

    function planes(){
        $this->view->title_page = 'Planes';
        $this->view->js = array('ajuste/js/wizard/jquery.bootstrap.wizard.js','ajuste/js/wizard/wizard.js','ajuste/js/wizard/jquery-ui.min.js','ajuste/js/aju_emp_planes.js');
		$this->view->render('ajuste/all/planes', false);
    }

    function plan_crud()
    {
        if ($_POST['id_plan'] != '') {
            print_r(json_encode($this->model->plan_crud_update($_POST)));
        } else {
            print_r(json_encode($this->model->plan_crud_create($_POST)));
        }
    }

    function plan_list()
    {
        $this->model->plan_list($_POST);
    }

    function plan_delete()
    {
        if ($_POST['id_plan'] != '') {
            print_r(json_encode($this->model->plan_delete($_POST)));
        }
    }

    function modulo_plan_crud()
    {
        if ($_POST['id_modulo'] != '' and $_POST['id_plan'] != '') {
            print_r(json_encode($this->model->modulo_plan_crud_update($_POST)));
        } else {
            print_r(json_encode($this->model->modulo_plan_crud_create($_POST)));
        }
    }

    function modulo_list()
    {
        $this->model->modulo_list($_POST);
    }





    /*FIN MODULO PLANES */

    /* ======================== INCIO OTROS AJUSTES */

    function datosistema_crud()
    {
        print_r(json_encode($this->model->datosistema_crud($_POST)));
    }

    function anularlogo()
    {
        print_r(json_encode($this->model->anularlogo()));
        // print_r(json_encode('1'));
    }


    /********APIS DEL SISTEMA DNI, RUC, LANDING***********/
    function apis_sistema()
    {
        $this->view->title_page = 'Apis sistema';
        $this->view->js = array('ajuste/js/wizard/jquery.bootstrap.wizard.js', 'ajuste/js/wizard/wizard.js', 'ajuste/js/wizard/jquery-ui.min.js', 'ajuste/js/aju_opt_apis.js');
        $this->view->render('ajuste/all/apis', false);
    }

    function apis_list()
    {
        $this->model->apis_list($_POST);
    }

    function api_crud()
    {
        if ($_POST['id_api'] != '') {
            print_r(json_encode($this->model->api_crud_update($_POST)));
        } else {
            print_r(json_encode($this->model->api_crud_create($_POST)));
        }
    }

    /***FORMATEAR SISTEMA***/

    function formatear_sistema()
    {
        print_r(json_encode($this->model->formatear_sistema()));

    }

}