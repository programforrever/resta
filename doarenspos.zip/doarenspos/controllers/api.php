<?php 
Session::init(); 
$ver = (Session::get('rol') == 1 OR Session::get('rol') == 2 OR Session::get('rol') == 3) ? '' :  header('location: ' . URL . 'err/danger'); 
?>
<?php

class Api extends Controller {

	function __construct() {
		parent::__construct();
		Auth::handleLogin();
	}

    function dni() 
	{	
        if(strlen($_POST['dni']) == '8') : 
        print_r(json_encode($this->model->dni($_POST['dni'])));
        else :
            echo 'null';
        endif;
	}

    function ruc() 
	{	
        if(strlen($_POST['ruc']) == '11') : 
        print_r(json_encode($this->model->ruc($_POST['ruc'])));
        else :
            echo 'null';
        endif;
	}

    function apis_list()
    {
        $this->model->apis_list($_POST);
    }

    function liberarbloqueo(){
        // echo 'hola';
        print_r(json_encode($this->model->liberarbloqueo()));
    }
	
}